"""
Economy Cog - Player money-making activities
Daily rewards, gambling, bounties, missions, achievements, survival tracking
"""

import discord
from discord import app_commands
from discord.ext import commands
from loguru import logger


class EconomyCog(commands.Cog):
    """Economy and money-making activities"""
    
    def __init__(self, bot):
        self.bot = bot
        self.economy = None
    
    @app_commands.command(name="daily", description="Claim daily login bonus")
    async def daily_reward(self, interaction: discord.Interaction) -> None:
        """Claim daily reward"""
        try:
            from bot.services.economy import EconomyService
            from bot.services.database import DatabaseService
            
            # Initialize economy service if not done
            if not self.economy:
                self.economy = EconomyService(self.bot.config_loader, DatabaseService)
            
            success, message, reward = await self.economy.claim_daily_reward(interaction.user.id)
            
            embed = discord.Embed(
                title="📅 Daily Reward" if success else "❌ Daily Reward",
                description=message,
                color=discord.Color.green() if success else discord.Color.red()
            )
            
            if success:
                embed.add_field(name="Reward", value=f"+{reward:.0f} credits", inline=False)
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Daily reward claim: {interaction.user.name} - {message}")
        except Exception as e:
            logger.error(f"Error in /daily: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="gamble", description="Try your luck gambling")
    @app_commands.describe(
        game="Game to play (coinflip, dice)",
        amount="Amount to bet",
        choice="Your choice (heads/tails or 1-6)"
    )
    async def gamble(
        self,
        interaction: discord.Interaction,
        game: str = "coinflip",
        amount: int = 100,
        choice: str = "heads"
    ) -> None:
        """Gamble with credits"""
        try:
            from bot.services.economy import EconomyService
            from bot.services.database import DatabaseService
            
            if not self.economy:
                self.economy = EconomyService(self.bot.config_loader, DatabaseService)
            
            game = game.lower()
            
            if game == "coinflip":
                if choice.lower() not in ["heads", "tails"]:
                    await interaction.response.send_message(
                        "Choose heads or tails", ephemeral=True
                    )
                    return
                
                success, message, net = await self.economy.coin_flip(
                    interaction.user.id, amount, choice
                )
            elif game == "dice":
                try:
                    dice_choice = int(choice)
                except ValueError:
                    await interaction.response.send_message(
                        "Dice choice must be 1-6", ephemeral=True
                    )
                    return
                
                success, message, net = await self.economy.dice_roll(
                    interaction.user.id, amount, dice_choice
                )
            else:
                await interaction.response.send_message(
                    "Unknown game (coinflip or dice)", ephemeral=True
                )
                return
            
            embed = discord.Embed(
                title="🎰 Gambling",
                description=message,
                color=discord.Color.gold()
            )
            embed.add_field(
                name="Net Change",
                value=f"{net:+.0f} credits",
                inline=False
            )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Gambling: {interaction.user.name} played {game} - {message}")
        except Exception as e:
            logger.error(f"Error in /gamble: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="bounty", description="Place or check bounties")
    @app_commands.describe(
        action="place or check",
        target="Player name (for placing)",
        amount="Amount to offer (for placing)",
        reason="Why (for placing)"
    )
    async def bounty(
        self,
        interaction: discord.Interaction,
        action: str = "check",
        target: str = None,
        amount: int = 0,
        reason: str = "No reason"
    ) -> None:
        """Place or check bounties"""
        try:
            from bot.services.economy import EconomyService
            from bot.services.database import DatabaseService
            
            if not self.economy:
                self.economy = EconomyService(self.bot.config_loader, DatabaseService)
            
            action = action.lower()
            
            if action == "place":
                if not target or amount <= 0:
                    await interaction.response.send_message(
                        "Need target and amount > 0", ephemeral=True
                    )
                    return
                
                success, message = await self.economy.place_bounty(
                    interaction.user.id, target, amount, reason
                )
                
                embed = discord.Embed(
                    title="💸 Bounty Placed" if success else "❌ Bounty Failed",
                    description=message,
                    color=discord.Color.red() if success else discord.Color.greyple()
                )
                
                if success:
                    embed.add_field(name="Target", value=target, inline=True)
                    embed.add_field(name="Reward", value=f"{amount} credits", inline=True)
                    embed.add_field(name="Reason", value=reason, inline=False)
                
                await interaction.response.send_message(embed=embed, ephemeral=True)
                logger.info(f"Bounty: {interaction.user.name} placed {amount} on {target}")
            
            elif action == "check":
                embed = discord.Embed(
                    title="📋 Active Bounties",
                    description="Check bounty board for active targets",
                    color=discord.Color.blue()
                )
                embed.add_field(
                    name="Coming Soon",
                    value="Bounty board will show all active bounties",
                    inline=False
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            logger.error(f"Error in /bounty: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="missions", description="View available missions")
    async def missions(self, interaction: discord.Interaction) -> None:
        """View available missions"""
        try:
            from bot.services.economy import EconomyService
            from bot.services.database import DatabaseService
            
            if not self.economy:
                self.economy = EconomyService(self.bot.config_loader, DatabaseService)
            
            missions_list = await self.economy.get_available_missions(interaction.user.id)
            
            if not missions_list:
                embed = discord.Embed(
                    title="📋 Missions",
                    description="No missions available right now",
                    color=discord.Color.greyple()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            embed = discord.Embed(
                title="📋 Available Missions",
                color=discord.Color.blue()
            )
            
            for mission in missions_list:
                difficulty_emoji = {
                    'easy': '🟢',
                    'medium': '🟡',
                    'hard': '🔴'
                }.get(mission['difficulty'], '⚪')
                
                embed.add_field(
                    name=f"{difficulty_emoji} {mission['title']}",
                    value=f"{mission['description']}\n**Reward:** {mission['reward']:.0f} credits",
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Missions viewed: {interaction.user.name}")
        except Exception as e:
            logger.error(f"Error in /missions: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="leaderboard", description="View top earners")
    async def leaderboard(self, interaction: discord.Interaction) -> None:
        """View leaderboard"""
        try:
            from bot.services.economy import EconomyService
            from bot.services.database import DatabaseService
            
            if not self.economy:
                self.economy = EconomyService(self.bot.config_loader, DatabaseService)
            
            leaderboard = await self.economy.get_leaderboard(10)
            
            if not leaderboard:
                embed = discord.Embed(
                    title="🏆 Leaderboard",
                    description="No data yet",
                    color=discord.Color.gold()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            embed = discord.Embed(
                title="🏆 Top Earners",
                color=discord.Color.gold()
            )
            
            medals = ['🥇', '🥈', '🥉']
            
            description = ""
            for entry in leaderboard:
                medal = medals[entry['rank'] - 1] if entry['rank'] <= 3 else '⭐'
                description += f"{medal} **#{entry['rank']}** {entry['username']}\n"
                description += f"   Balance: {entry['balance']:,.0f} credits\n\n"
            
            embed.description = description
            
            await interaction.response.send_message(embed=embed, ephemeral=False)
            logger.info(f"Leaderboard viewed: {interaction.user.name}")
        except Exception as e:
            logger.error(f"Error in /leaderboard: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="stats", description="View your player stats")
    async def stats(self, interaction: discord.Interaction) -> None:
        """View player statistics"""
        try:
            from bot.services.database import DatabaseService
            
            balance = await DatabaseService.get_user_balance(interaction.user.id)
            
            embed = discord.Embed(
                title=f"📊 {interaction.user.name}'s Stats",
                color=discord.Color.blue()
            )
            
            embed.add_field(
                name="💰 Current Balance",
                value=f"{balance:,.0f} credits",
                inline=False
            )
            
            embed.add_field(
                name="🎮 Activities",
                value="/daily - Claim daily bonus\n/gamble - Try gambling\n/missions - View missions\n/bounty - Place bounties",
                inline=False
            )
            
            embed.set_thumbnail(url=interaction.user.avatar.url if interaction.user.avatar else "")
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Stats viewed: {interaction.user.name}")
        except Exception as e:
            logger.error(f"Error in /stats: {e}", exc_info=True)
            await interaction.response.send_message(
                f"❌ Error: {str(e)}", ephemeral=True
            )


async def setup(bot):
    """Load cog"""
    await bot.add_cog(EconomyCog(bot))
    logger.info("Economy cog loaded")

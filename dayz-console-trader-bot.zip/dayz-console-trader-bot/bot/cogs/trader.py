"""
Trader Cog - Main player trading commands
/shop /buy /rent /balance /orders
"""

import discord
from discord import app_commands
from discord.ext import commands
from loguru import logger


class TraderCog(commands.Cog):
    """Trader commands for players"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="shop", description="Browse available vehicles and items")
    async def shop(self, interaction: discord.Interaction) -> None:
        """View trader shop"""
        try:
            # Create embed with shop info
            embed = discord.Embed(
                title="🛒 DayZ Trader Shop",
                description="Browse available vehicles and items",
                color=discord.Color.green()
            )
            
            # Add vehicle listings
            vehicles = self.bot.config_loader.vehicle_defs.get("vehicles", [])[:5]  # Show first 5
            if vehicles:
                vehicle_list = "\n".join([
                    f"**{v['display']}** - ${v.get('price_buy', '?')} (rent: ${v.get('price_rent_hour', '?')}/hr)"
                    for v in vehicles if v.get("enabled")
                ])
                embed.add_field(
                    name="🚗 Vehicles",
                    value=vehicle_list or "No vehicles available",
                    inline=False
                )
            
            # Add item listings
            items = self.bot.config_loader.console_items.get("items", [])[:5]
            if items:
                item_list = "\n".join([
                    f"**{i['display']}** - ${i.get('price', '?')}"
                    for i in items if i.get("enabled")
                ])
                embed.add_field(
                    name="📦 Items",
                    value=item_list or "No items available",
                    inline=False
                )
            
            # Add commands
            embed.add_field(
                name="📋 Commands",
                value="/buy vehicle - Purchase a vehicle\n/rent vehicle - Rent a vehicle\n/buy items - Build custom loadout",
                inline=False
            )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Shop viewed by {interaction.user.name}")
        except Exception as e:
            logger.error(f"Error in /shop: {e}", exc_info=True)
            await interaction.response.send_message(
                f"Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="balance", description="Check your current balance")
    async def balance(self, interaction: discord.Interaction) -> None:
        """Check player balance"""
        try:
            from bot.services.database import DatabaseService
            
            balance = await DatabaseService.get_user_balance(interaction.user.id)
            
            embed = discord.Embed(
                title="💰 Your Balance",
                description=f"You have **{balance:,.0f}** {self.bot.config_loader.get_setting('economy', 'currency_name', default='Rubles')}",
                color=discord.Color.gold()
            )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Balance checked by {interaction.user.name}: {balance}")
        except Exception as e:
            logger.error(f"Error in /balance: {e}", exc_info=True)
            await interaction.response.send_message(
                f"Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="buy", description="Buy a vehicle or items")
    @app_commands.describe(
        item_type="What to buy (vehicle or items)",
        vehicle_name="Vehicle classname (if buying vehicle)"
    )
    async def buy(
        self,
        interaction: discord.Interaction,
        item_type: str = "vehicle",
        vehicle_name: str = None
    ) -> None:
        """Buy vehicle or cargo"""
        try:
            if item_type.lower() == "vehicle":
                if not vehicle_name:
                    await interaction.response.send_message(
                        "Please specify a vehicle to buy", ephemeral=True
                    )
                    return
                
                vehicle = self.bot.config_loader.get_vehicle(vehicle_name)
                if not vehicle:
                    await interaction.response.send_message(
                        f"Vehicle not found: {vehicle_name}", ephemeral=True
                    )
                    return
                
                price = vehicle.get("price_buy", 0)
                
                embed = discord.Embed(
                    title=f"🚗 Buy {vehicle['display']}",
                    description=f"Price: **{price:,.0f}** {self.bot.config_loader.get_setting('economy', 'currency_name', default='Rubles')}",
                    color=discord.Color.blue()
                )
                
                # Send map link for coordinate selection
                embed.add_field(
                    name="Next Step",
                    value="Click the map link below to select spawn location",
                    inline=False
                )
                
                await interaction.response.send_message(embed=embed, ephemeral=True)
                logger.info(f"{interaction.user.name} browsing to buy {vehicle_name}")
            else:
                await interaction.response.send_message(
                    "Item buying not yet implemented", ephemeral=True
                )
        except Exception as e:
            logger.error(f"Error in /buy: {e}", exc_info=True)
            await interaction.response.send_message(
                f"Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="rent", description="Rent a vehicle for X hours")
    @app_commands.describe(
        vehicle_name="Vehicle to rent",
        hours="Hours to rent (1-48)"
    )
    async def rent(
        self,
        interaction: discord.Interaction,
        vehicle_name: str,
        hours: int = 24
    ) -> None:
        """Rent a vehicle"""
        try:
            vehicle = self.bot.config_loader.get_vehicle(vehicle_name)
            if not vehicle:
                await interaction.response.send_message(
                    f"Vehicle not found: {vehicle_name}", ephemeral=True
                )
                return
            
            if hours < 1 or hours > 48:
                await interaction.response.send_message(
                    "Rental duration must be between 1 and 48 hours", ephemeral=True
                )
                return
            
            price = (vehicle.get("price_rent_hour", 0) or 0) * hours
            
            embed = discord.Embed(
                title=f"🚗 Rent {vehicle['display']}",
                description=f"Duration: **{hours}** hours\nPrice: **{price:,.0f}** {self.bot.config_loader.get_setting('economy', 'currency_name', default='Rubles')}",
                color=discord.Color.blue()
            )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"{interaction.user.name} viewing rental for {vehicle_name} ({hours}h)")
        except Exception as e:
            logger.error(f"Error in /rent: {e}", exc_info=True)
            await interaction.response.send_message(
                f"Error: {str(e)}", ephemeral=True
            )
    
    @app_commands.command(name="orders", description="Check your spawn orders")
    async def orders(self, interaction: discord.Interaction) -> None:
        """View player's orders"""
        try:
            embed = discord.Embed(
                title="📋 Your Orders",
                description="Your spawn orders appear here",
                color=discord.Color.blue()
            )
            
            embed.add_field(
                name="Status",
                value="No orders yet", 
                inline=False
            )
            
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Orders viewed by {interaction.user.name}")
        except Exception as e:
            logger.error(f"Error in /orders: {e}", exc_info=True)
            await interaction.response.send_message(
                f"Error: {str(e)}", ephemeral=True
            )


async def setup(bot):
    """Load cog"""
    await bot.add_cog(TraderCog(bot))
    logger.info("Trader cog loaded")

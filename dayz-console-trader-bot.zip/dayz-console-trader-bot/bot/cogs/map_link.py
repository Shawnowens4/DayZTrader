"""
Map Link Cog - Sends ephemeral map links for coordinate selection
"""

import os
import secrets
from datetime import datetime, timedelta
from typing import Optional

import discord
from discord.ext import commands
from loguru import logger


class MapLinkCog(commands.Cog):
    """Map coordinate selection"""
    
    def __init__(self, bot):
        self.bot = bot
        self.active_tokens = {}  # {token: {user_id, expires_at, order_id, ...}}
    
    def generate_map_token(self, user_id: int, order_id: Optional[int] = None) -> str:
        """
        Generate and store map token
        
        Args:
            user_id: Discord user ID
            order_id: Associated order ID
        
        Returns:
            Token string
        """
        token = secrets.token_urlsafe(32)
        
        self.active_tokens[token] = {
            "user_id": user_id,
            "order_id": order_id,
            "created_at": datetime.now(),
            "expires_at": datetime.now() + timedelta(minutes=5),  # 5-min expiry
        }
        
        logger.info(f"Generated map token for user {user_id}")
        return token
    
    def get_map_url(self, token: str) -> str:
        """Get full map URL for token"""
        web_host = os.getenv("WEB_HOST", "127.0.0.1")
        web_port = os.getenv("WEB_PORT", "8788")
        
        # In production, use external domain
        domain = os.getenv("MAP_DOMAIN", f"{web_host}:{web_port}")
        
        return f"https://{domain}/map?token={token}"
    
    @commands.command(name="map")
    async def map_command(self, ctx) -> None:
        """Send map link (text command version)"""
        token = self.generate_map_token(ctx.author.id)
        url = self.get_map_url(token)
        
        embed = discord.Embed(
            title="🗺️ Select Spawn Location",
            description=f"[Click here to open map]({url})",
            color=discord.Color.blue()
        )
        embed.add_field(
            name="⏱️ Expires In",
            value="5 minutes",
            inline=False
        )
        embed.add_field(
            name="📍 Instructions",
            value="1. Click on the map to select a location\n2. Confirm your choice\n3. Return to Discord to complete purchase",
            inline=False
        )
        
        await ctx.send(embed=embed, ephemeral=True)
    
    async def send_map_link(
        self,
        user: discord.User,
        order_id: Optional[int] = None,
        reason: str = "Purchase"
    ) -> bool:
        """
        Send map link via DM to user
        
        Args:
            user: Discord user
            order_id: Associated order ID
            reason: Reason for map link (Purchase, Rental, etc.)
        
        Returns:
            Success status
        """
        try:
            token = self.generate_map_token(user.id, order_id)
            url = self.get_map_url(token)
            
            embed = discord.Embed(
                title="🗺️ Select Your Spawn Location",
                description=f"[Open Map →]({url})",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="What's Next",
                value=f"1. Click the link above\n2. Select where you want your {reason.lower()} to spawn\n3. Confirm your choice",
                inline=False
            )
            embed.add_field(
                name="⏱️ Expires",
                value="5 minutes",
                inline=False
            )
            embed.set_footer(text="Map coordinates are validated before spawn")
            
            await user.send(embed=embed)
            logger.info(f"Sent map link to {user.name} for {reason}")
            return True
        except Exception as e:
            logger.error(f"Failed to send map link to {user.name}: {e}")
            return False
    
    def verify_token(self, token: str) -> dict:
        """
        Verify and retrieve token data
        
        Args:
            token: Token string
        
        Returns:
            Token data dict or None if invalid/expired
        """
        if token not in self.active_tokens:
            return None
        
        token_data = self.active_tokens[token]
        
        # Check expiry
        if token_data["expires_at"] < datetime.now():
            del self.active_tokens[token]
            logger.warning(f"Token expired: {token[:8]}...")
            return None
        
        return token_data
    
    def consume_token(self, token: str) -> dict:
        """
        Consume token (remove after use)
        
        Args:
            token: Token string
        
        Returns:
            Token data or None
        """
        if token not in self.active_tokens:
            return None
        
        token_data = self.active_tokens[token]
        del self.active_tokens[token]
        
        logger.info(f"Token consumed: {token[:8]}...")
        return token_data
    
    def cleanup_expired_tokens(self) -> int:
        """Remove expired tokens"""
        now = datetime.now()
        expired = [
            token for token, data in self.active_tokens.items()
            if data["expires_at"] < now
        ]
        
        for token in expired:
            del self.active_tokens[token]
        
        if expired:
            logger.info(f"Cleaned up {len(expired)} expired tokens")
        
        return len(expired)


async def setup(bot):
    """Load cog"""
    await bot.add_cog(MapLinkCog(bot))
    logger.info("Map link cog loaded")

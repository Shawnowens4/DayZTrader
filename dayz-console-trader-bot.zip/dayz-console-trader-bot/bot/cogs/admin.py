"""
Admin Cog - Admin-only commands
/admin catalog /admin give_balance /admin force_deploy /admin reload_config
"""

import os
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
from loguru import logger


class AdminCog(commands.Cog):
    """Admin commands"""
    
    def __init__(self, bot):
        self.bot = bot
    
    def is_admin(self, interaction: discord.Interaction) -> bool:
        """Check if user is admin"""
        admin_role_ids = os.getenv("ADMIN_ROLE_IDS", "").split(",")
        admin_role_ids = [int(rid.strip()) for rid in admin_role_ids if rid.strip()]
        
        if not admin_role_ids:
            return interaction.user == interaction.guild.owner
        
        return any(role.id in admin_role_ids for role in interaction.user.roles)
    
    @app_commands.command(name="admin", description="Admin commands")
    @app_commands.describe(
        action="Admin action",
        vehicle_name="Vehicle classname",
        item_name="Item classname",
        price="New price",
        user="Target user",
        amount="Balance amount"
    )
    async def admin(
        self,
        interaction: discord.Interaction,
        action: str = "help",
        vehicle_name: Optional[str] = None,
        item_name: Optional[str] = None,
        price: Optional[float] = None,
        user: Optional[discord.User] = None,
        amount: Optional[float] = None
    ) -> None:
        """Admin commands"""
        try:
            # Check permission
            if not self.is_admin(interaction):
                await interaction.response.send_message(
                    "❌ You don't have admin permission", ephemeral=True
                )
                return
            
            if action == "help":
                embed = discord.Embed(
                    title="🔧 Admin Commands",
                    color=discord.Color.red()
                )
                embed.add_field(
                    name="catalog set-price",
                    value="Set vehicle/item price: `vehicle_name price`",
                    inline=False
                )
                embed.add_field(
                    name="catalog toggle",
                    value="Enable/disable vehicle/item: `vehicle_name`",
                    inline=False
                )
                embed.add_field(
                    name="give_balance",
                    value="Credit player: `@user amount`",
                    inline=False
                )
                embed.add_field(
                    name="reload_config",
                    value="Reload JSON configs from disk",
                    inline=False
                )
                embed.add_field(
                    name="force_deploy",
                    value="Retry failed spawn order: `order_id`",
                    inline=False
                )
                
                await interaction.response.send_message(embed=embed, ephemeral=True)
            
            elif action == "set-price" and vehicle_name and price is not None:
                # Set price for vehicle or item
                vehicle = self.bot.config_loader.get_vehicle(vehicle_name)
                if vehicle:
                    embed = discord.Embed(
                        title="✅ Price Updated",
                        description=f"**{vehicle['display']}** price set to **{price:,.0f}**",
                        color=discord.Color.green()
                    )
                    logger.info(f"Admin {interaction.user.name} set {vehicle_name} price to {price}")
                else:
                    await interaction.response.send_message(
                        f"Vehicle not found: {vehicle_name}", ephemeral=True
                    )
                    return
                
                await interaction.response.send_message(embed=embed, ephemeral=True)
            
            elif action == "give_balance" and user and amount is not None:
                # Give balance to player
                from bot.services.database import DatabaseService
                
                success = await DatabaseService.update_user_balance(
                    user.id,
                    amount,
                    f"Admin credit by {interaction.user.name}"
                )
                
                if success:
                    embed = discord.Embed(
                        title="✅ Balance Updated",
                        description=f"Credited {user.mention} with **{amount:,.0f}** {self.bot.config_loader.get_setting('economy', 'currency_name', default='Rubles')}",
                        color=discord.Color.green()
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    logger.info(f"Admin {interaction.user.name} gave {amount} to {user.name}")
                else:
                    await interaction.response.send_message(
                        "Failed to update balance", ephemeral=True
                    )
            
            elif action == "reload_config":
                # Reload config from disk
                try:
                    await self.bot.config_loader.load_all()
                    embed = discord.Embed(
                        title="✅ Config Reloaded",
                        description="All configuration files reloaded successfully",
                        color=discord.Color.green()
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    logger.info(f"Admin {interaction.user.name} reloaded config")
                except Exception as e:
                    await interaction.response.send_message(
                        f"Error reloading config: {e}", ephemeral=True
                    )
            
            elif action == "toggle" and vehicle_name:
                # Toggle vehicle enabled/disabled
                vehicle = self.bot.config_loader.get_vehicle(vehicle_name)
                if vehicle:
                    # Would update in database here
                    embed = discord.Embed(
                        title="✅ Vehicle Toggled",
                        description=f"**{vehicle['display']}** availability updated",
                        color=discord.Color.green()
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    logger.info(f"Admin {interaction.user.name} toggled {vehicle_name}")
                else:
                    await interaction.response.send_message(
                        f"Vehicle not found: {vehicle_name}", ephemeral=True
                    )
            
            else:
                await interaction.response.send_message(
                    "Invalid admin command. Use `/admin help`", ephemeral=True
                )
        except Exception as e:
            logger.error(f"Error in /admin: {e}", exc_info=True)
            await interaction.response.send_message(
                f"Error: {str(e)}", ephemeral=True
            )


async def setup(bot):
    """Load cog"""
    await bot.add_cog(AdminCog(bot))
    logger.info("Admin cog loaded")

"""
Coordinate system conversions
DayZ world (x, z) ↔ Leaflet map (lat, lng)

Chernarus map specifics:
- World size: ~15360 x ~15360 units
- Leaflet: uses lat/lng convention (reversed from typical game coords)
- Center: ~7680, ~7680 (game coords) = 0, 0 (map center)
"""

from typing import Tuple


class ChernausCoordSystem:
    """Chernarus coordinate system converter"""
    
    # Chernarus world boundaries (in game units)
    WORLD_MIN_X = 0
    WORLD_MAX_X = 15360
    WORLD_MIN_Z = 0
    WORLD_MAX_Z = 15360
    
    # Map dimensions (tiles)
    MAP_SIZE_PIXELS = 8192  # At max zoom
    
    @staticmethod
    def world_to_leaflet(
        world_x: float,
        world_z: float
    ) -> Tuple[float, float]:
        """
        Convert DayZ world coordinates to Leaflet map coordinates
        
        Args:
            world_x: DayZ world X coordinate (0-15360)
            world_z: DayZ world Z coordinate (0-15360)
        
        Returns:
            (latitude, longitude) for Leaflet map
        """
        # Map world coords to normalized -1 to 1 range
        norm_x = (world_x - ChernausCoordSystem.WORLD_MAX_X / 2) / (ChernausCoordSystem.WORLD_MAX_X / 2)
        norm_z = (world_z - ChernausCoordSystem.WORLD_MAX_Z / 2) / (ChernausCoordSystem.WORLD_MAX_Z / 2)
        
        # Leaflet uses lat/lng; we'll use norm_x for lng, norm_z for lat
        # Note: Z is inverted in game coords vs map coords
        latitude = -norm_z * 85  # Max latitude range
        longitude = norm_x * 180  # Max longitude range
        
        return latitude, longitude
    
    @staticmethod
    def leaflet_to_world(
        latitude: float,
        longitude: float
    ) -> Tuple[float, float]:
        """
        Convert Leaflet map coordinates to DayZ world coordinates
        
        Args:
            latitude: Leaflet map latitude (-85 to 85)
            longitude: Leaflet map longitude (-180 to 180)
        
        Returns:
            (world_x, world_z) DayZ world coordinates
        """
        # Normalize from map range to -1 to 1
        norm_z = -latitude / 85  # Inverted
        norm_x = longitude / 180
        
        # Convert to world coordinates
        world_x = norm_x * (ChernausCoordSystem.WORLD_MAX_X / 2) + (ChernausCoordSystem.WORLD_MAX_X / 2)
        world_z = norm_z * (ChernausCoordSystem.WORLD_MAX_Z / 2) + (ChernausCoordSystem.WORLD_MAX_Z / 2)
        
        # Clamp to world bounds
        world_x = max(ChernausCoordSystem.WORLD_MIN_X, min(ChernausCoordSystem.WORLD_MAX_X, world_x))
        world_z = max(ChernausCoordSystem.WORLD_MIN_Z, min(ChernausCoordSystem.WORLD_MAX_Z, world_z))
        
        return world_x, world_z
    
    @staticmethod
    def is_in_bounds(x: float, z: float) -> bool:
        """Check if coordinates are within Chernarus bounds"""
        return (
            ChernausCoordSystem.WORLD_MIN_X <= x <= ChernausCoordSystem.WORLD_MAX_X
            and ChernausCoordSystem.WORLD_MIN_Z <= z <= ChernausCoordSystem.WORLD_MAX_Z
        )
    
    @staticmethod
    def distance_between(
        x1: float,
        z1: float,
        x2: float,
        z2: float
    ) -> float:
        """
        Calculate distance between two world coordinates (in meters)
        
        Args:
            x1, z1: First coordinate
            x2, z2: Second coordinate
        
        Returns:
            Distance in meters (approximate)
        """
        import math
        return math.sqrt((x2 - x1) ** 2 + (z2 - z1) ** 2)
    
    @staticmethod
    def bearing_to(
        x1: float,
        z1: float,
        x2: float,
        z2: float
    ) -> float:
        """
        Calculate bearing from point 1 to point 2 (degrees, 0° = North)
        
        Args:
            x1, z1: Starting coordinate
            x2, z2: Target coordinate
        
        Returns:
            Bearing in degrees (0-360)
        """
        import math
        
        dx = x2 - x1
        dz = z2 - z1
        
        # Atan2 returns radians; convert to degrees
        # Note: In game coords, Z increases downward, so we negate it
        angle = math.atan2(dx, -dz)
        bearing = math.degrees(angle)
        
        # Normalize to 0-360
        bearing = (bearing + 360) % 360
        
        return bearing
    
    @staticmethod
    def format_coords(x: float, z: float, precision: int = 0) -> str:
        """Format coordinates for display"""
        if precision == 0:
            return f"({int(x)}, {int(z)})"
        return f"({x:.{precision}f}, {z:.{precision}f})"
    
    @staticmethod
    def get_grid_square(x: float, z: float) -> str:
        """
        Get Chernarus grid square (e.g., "J5", "G9")
        Grid is 16x16, dividing 15360 into roughly 960-unit squares
        
        Args:
            x, z: World coordinates
        
        Returns:
            Grid square string like "J5"
        """
        # Grid columns (X): A-P (16 columns)
        col_index = int((x / 15360) * 16)
        col_index = min(15, max(0, col_index))
        col_letter = chr(ord('A') + col_index)
        
        # Grid rows (Z): 1-16
        row_index = int((z / 15360) * 16)
        row_index = min(15, max(0, row_index))
        row_number = 16 - row_index  # Rows count from top
        
        return f"{col_letter}{row_number}"


class SafeZoneChecker:
    """Check if coordinates are in safe zones"""
    
    def __init__(self, safe_zones: list, blacklist_zones: list, buffer_meters: int = 100):
        """
        Args:
            safe_zones: List of {x, z, radius} zones
            blacklist_zones: List of {x, z, radius} blacklisted zones
            buffer_meters: Buffer distance around zones
        """
        self.safe_zones = safe_zones
        self.blacklist_zones = blacklist_zones
        self.buffer = buffer_meters
    
    def is_in_safe_zone(self, x: float, z: float) -> bool:
        """Check if coordinates are in a safe zone"""
        for zone in self.safe_zones:
            distance = ChernausCoordSystem.distance_between(
                x, z,
                zone.get("x", 0), zone.get("z", 0)
            )
            if distance <= (zone.get("radius", 0) + self.buffer):
                return True
        return False
    
    def is_in_blacklist_zone(self, x: float, z: float) -> bool:
        """Check if coordinates are in a blacklist zone"""
        for zone in self.blacklist_zones:
            distance = ChernausCoordSystem.distance_between(
                x, z,
                zone.get("x", 0), zone.get("z", 0)
            )
            if distance <= (zone.get("radius", 0) + self.buffer):
                return True
        return False
    
    def is_valid_spawn_location(
        self,
        x: float,
        z: float,
        enforce_safe_zones: bool = False,
        enforce_blacklist: bool = True
    ) -> Tuple[bool, str]:
        """
        Check if location is valid for spawning
        
        Args:
            x, z: World coordinates
            enforce_safe_zones: If True, must be in a safe zone
            enforce_blacklist: If True, cannot be in blacklist zone
        
        Returns:
            (valid, reason)
        """
        # Check bounds
        if not ChernausCoordSystem.is_in_bounds(x, z):
            return False, "Coordinates out of bounds"
        
        # Check blacklist
        if enforce_blacklist and self.is_in_blacklist_zone(x, z):
            return False, "Coordinates in blacklist zone"
        
        # Check safe zones requirement
        if enforce_safe_zones and not self.is_in_safe_zone(x, z):
            return False, "Coordinates not in safe zone"
        
        return True, "Valid spawn location"

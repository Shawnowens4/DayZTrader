"""
Validators for console-safe spawning
Enforces classname allowlist, nesting depth, and slot limits
"""

from typing import Any, Dict, List, Optional, Tuple

from loguru import logger


class Validators:
    """Console-safe spawn validators"""
    
    def __init__(self, config_loader):
        """
        Args:
            config_loader: ConfigLoader instance with allowlists
        """
        self.config = config_loader
        self._classname_cache = set()
        self._build_classname_cache()
    
    def _build_classname_cache(self) -> None:
        """Build a set of allowed classnames for fast lookup"""
        # Add vehicles
        for vehicle in self.config.vehicle_defs.get("vehicles", []):
            self._classname_cache.add(vehicle.get("classname"))
        
        # Add items
        for item in self.config.console_items.get("items", []):
            self._classname_cache.add(item.get("classname"))
        
        # Add parts
        for vehicle in self.config.vehicle_defs.get("vehicles", []):
            for part_key, part in vehicle.get("parts", {}).items():
                self._classname_cache.add(part.get("classname"))
            for run_part in vehicle.get("run_parts", []):
                self._classname_cache.add(run_part.get("classname"))
        
        logger.info(f"Classname cache built: {len(self._classname_cache)} entries")
    
    def is_classname_allowed(self, classname: str) -> bool:
        """Check if classname is in allowlist"""
        if not classname:
            return False
        
        # Check forbidden patterns
        forbidden = [
            "Land_",
            "Flag_",
            "Roadblock_",
            "Wreck_",
            "Bunker_",
            "Fence_",
            "Door_",
            "Wall_",
            "CivilianSedan",  # Example: if not supported
        ]
        
        for pattern in forbidden:
            if classname.startswith(pattern):
                logger.warning(f"Forbidden classname pattern: {classname}")
                return False
        
        return classname in self._classname_cache
    
    def validate_cargo_loadout(
        self,
        cargo: List[Dict[str, Any]],
        vehicle_classname: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Validate entire cargo loadout
        
        Args:
            cargo: List of {classname, quantity} dicts
            vehicle_classname: Vehicle trunk if applicable
        
        Returns:
            (valid, error_message)
        """
        if not isinstance(cargo, list):
            return False, "Cargo must be a list"
        
        if len(cargo) == 0:
            return False, "Cargo list cannot be empty"
        
        # Check classnames
        for item in cargo:
            classname = item.get("classname")
            if not self.is_classname_allowed(classname):
                return False, f"Classname not allowed: {classname}"
        
        # Check slot limits
        total_slots = self._calculate_cargo_slots(cargo)
        if vehicle_classname:
            max_slots = self._get_vehicle_trunk_capacity(vehicle_classname)
            if total_slots > max_slots:
                return False, f"Cargo exceeds trunk capacity: {total_slots}/{max_slots} slots"
        
        # Check nesting depth
        valid, msg = self._validate_nesting_depth(cargo)
        if not valid:
            return False, msg
        
        # Check item-specific rules
        valid, msg = self._validate_item_rules(cargo)
        if not valid:
            return False, msg
        
        return True, "Cargo valid"
    
    def _calculate_cargo_slots(self, cargo: List[Dict[str, Any]]) -> int:
        """Calculate total slots used by cargo"""
        total = 0
        
        for item in cargo:
            classname = item.get("classname")
            quantity = item.get("quantity", 1)
            
            item_def = self.config.get_item(classname)
            if item_def:
                item_slots = item_def.get("cargo_slots", 1)
                total += item_slots * quantity
            else:
                # Fallback: estimate based on weapon/container status
                total += 5 * quantity  # Conservative estimate
        
        return total
    
    def _get_vehicle_trunk_capacity(self, vehicle_classname: str) -> int:
        """Get trunk capacity for vehicle"""
        vehicle = self.config.get_vehicle(vehicle_classname)
        if vehicle:
            return vehicle.get("cargo_capacity", 100)
        return 100  # Default fallback
    
    def _validate_nesting_depth(
        self,
        cargo: List[Dict[str, Any]],
        current_depth: int = 0
    ) -> Tuple[bool, str]:
        """Validate nesting depth doesn't exceed max"""
        max_depth = self.config.nesting_rules.get("max_nesting_depth", 2)
        
        if current_depth > max_depth:
            return False, f"Nesting depth exceeded: {current_depth} > {max_depth}"
        
        # For now, basic depth check
        # A more sophisticated implementation would parse nested cargo structure
        
        return True, "Nesting depth valid"
    
    def _validate_item_rules(
        self,
        cargo: List[Dict[str, Any]]
    ) -> Tuple[bool, str]:
        """Validate item-specific rules (e.g., weapon ammo pairing)"""
        weapons = []
        ammo = []
        
        for item in cargo:
            classname = item.get("classname")
            item_def = self.config.get_item(classname)
            
            if not item_def:
                continue
            
            if item_def.get("is_weapon"):
                weapons.append(classname)
            elif item_def.get("category") == "ammunition":
                ammo.append(classname)
        
        # Warn if weapons without ammo
        if weapons and not ammo:
            logger.warning("Cargo contains weapons but no ammunition")
            # Not a hard fail, but warn
        
        return True, "Item rules valid"
    
    def validate_vehicle_parts(
        self,
        vehicle_classname: str,
        parts: Dict[str, Any]
    ) -> Tuple[bool, str]:
        """
        Validate vehicle parts configuration
        
        Args:
            vehicle_classname: Vehicle classname
            parts: Dict of {part_key: part_classname}
        
        Returns:
            (valid, error_message)
        """
        vehicle = self.config.get_vehicle(vehicle_classname)
        if not vehicle:
            return False, f"Vehicle not found: {vehicle_classname}"
        
        vehicle_parts = vehicle.get("parts", {})
        
        # Check required parts
        for part_key, part_def in vehicle_parts.items():
            if not part_def.get("required", False):
                continue
            
            if part_key not in parts:
                return False, f"Missing required part: {part_key}"
            
            part_classname = parts[part_key]
            expected_classname = part_def.get("classname")
            
            if part_classname != expected_classname:
                return False, f"Wrong part classname: {part_key} = {part_classname} (expected {expected_classname})"
        
        return True, "Vehicle parts valid"
    
    def validate_xml_snippet(self, xml_string: str) -> Tuple[bool, str]:
        """
        Validate XML snippet is well-formed
        
        Args:
            xml_string: XML to validate
        
        Returns:
            (valid, error_message)
        """
        try:
            from lxml import etree
            
            # Try to parse
            etree.fromstring(xml_string.encode("utf-8"))
            return True, "XML is well-formed"
        except etree.XMLSyntaxError as e:
            return False, f"XML syntax error: {str(e)}"
        except Exception as e:
            return False, f"XML validation failed: {str(e)}"
    
    def get_item_whitelist(self, classname: str) -> Optional[List[str]]:
        """
        Get whitelist of items allowed in a container
        
        Args:
            classname: Container classname
        
        Returns:
            List of allowed item classnames or None if no restriction
        """
        container_rules = self.config.nesting_rules.get("container_rules", {})
        rule = container_rules.get(classname, {})
        return rule.get("whitelist")
    
    def can_item_nest_in_container(
        self,
        item_classname: str,
        container_classname: str
    ) -> Tuple[bool, str]:
        """Check if item can fit in container"""
        item = self.config.get_item(item_classname)
        if not item:
            return False, f"Item not found: {item_classname}"
        
        # Check if container accepts this type
        container_rules = self.config.nesting_rules.get("container_rules", {})
        rule = container_rules.get(container_classname, {})
        
        if not rule:
            return False, f"Container not found: {container_classname}"
        
        # Check whitelist if present
        whitelist = rule.get("whitelist")
        if whitelist and item_classname not in whitelist:
            return False, f"Item not in container whitelist: {item_classname}"
        
        # Check type acceptance
        if item.get("is_weapon") and not rule.get("accepts_weapons", False):
            return False, f"Container does not accept weapons"
        
        if item.get("category") == "ammunition" and not rule.get("accepts_ammunition", False):
            return False, f"Container does not accept ammunition"
        
        return True, "Item can nest in container"


def create_validators(config_loader) -> Validators:
    """Factory function for validators"""
    return Validators(config_loader)

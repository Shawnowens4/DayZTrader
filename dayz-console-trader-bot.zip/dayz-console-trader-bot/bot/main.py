"""
DayZ Console Trader Bot - Main Entry Point
Xbox/PlayStation 1.29.1+ Nitrado Communities
"""

import asyncio
import os
import sys
from pathlib import Path
from typing import Optional

import discord
from discord.ext import commands
from dotenv import load_dotenv
from loguru import logger

# Load environment variables
load_dotenv()

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from bot.services.database import init_db, get_session
from bot.services.config_loader import ConfigLoader


# Configure logging
log_level = os.getenv("LOG_LEVEL", "INFO")
log_file = os.getenv("LOG_FILE", "logs/trader.log")

# Create logs directory if it doesn't exist
Path("logs").mkdir(exist_ok=True)

logger.remove()  # Remove default handler
logger.add(
    sys.stderr,
    level=log_level,
    format="<level>{time:YYYY-MM-DD HH:mm:ss}</level> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
)
logger.add(
    log_file,
    level=log_level,
    rotation="500 MB",
    retention="7 days",
    format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}"
)


class DayZTraderBot(commands.Bot):
    """Main Discord bot class for DayZ Console Trader"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.config_loader: Optional[ConfigLoader] = None
        self.db_session = None
        self.uptime = None
    
    async def setup_hook(self) -> None:
        """Called before the bot connects to Discord"""
        logger.info("Setting up bot...")
        
        # Initialize config loader
        self.config_loader = ConfigLoader(PROJECT_ROOT / "config")
        await self.config_loader.load_all()
        logger.info("Config loaded successfully")
        
        # Initialize database
        try:
            await init_db()
            logger.info("Database initialized")
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            raise
        
        # Load cogs
        await self.load_cogs()
    
    async def load_cogs(self) -> None:
        """Load all command cogs"""
        cogs_dir = PROJECT_ROOT / "bot" / "cogs"
        
        for cog_file in cogs_dir.glob("*.py"):
            if cog_file.name.startswith("_"):
                continue
            
            cog_name = cog_file.stem
            try:
                await self.load_extension(f"bot.cogs.{cog_name}")
                logger.info(f"Loaded cog: {cog_name}")
            except Exception as e:
                logger.error(f"Failed to load cog {cog_name}: {e}")
    
    async def on_ready(self) -> None:
        """Called when the bot is ready"""
        logger.info(f"Bot logged in as {self.user} (ID: {self.user.id})")
        logger.info(f"Guilds: {len(self.guilds)}")
        
        # Set activity
        try:
            settings = self.config_loader.settings
            activity_name = settings.get("discord", {}).get("activity", {}).get("name", "DayZ trades")
            activity_type_str = settings.get("discord", {}).get("activity", {}).get("type", "watching")
            
            activity_type_map = {
                "playing": discord.ActivityType.playing,
                "streaming": discord.ActivityType.streaming,
                "listening": discord.ActivityType.listening,
                "watching": discord.ActivityType.watching,
            }
            
            activity_type = activity_type_map.get(activity_type_str, discord.ActivityType.watching)
            activity = discord.Activity(type=activity_type, name=activity_name)
            await self.change_presence(activity=activity)
            logger.info(f"Activity set: {activity_type_str} {activity_name}")
        except Exception as e:
            logger.warning(f"Could not set activity: {e}")
    
    async def on_error(self, event: str, *args, **kwargs) -> None:
        """Called when an error occurs"""
        logger.error(f"Error in {event}", exc_info=True)


def create_bot() -> DayZTraderBot:
    """Create and configure the bot instance"""
    
    # Get Discord token
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        logger.critical("DISCORD_TOKEN not set in .env")
        raise ValueError("DISCORD_TOKEN environment variable is required")
    
    # Configure intents
    intents = discord.Intents.default()
    intents.message_content = True
    intents.guilds = True
    intents.dm_messages = True
    intents.guild_messages = True
    
    # Create bot
    bot = DayZTraderBot(
        command_prefix="!",
        intents=intents,
        help_command=None,  # Custom help cog
        sync_commands=True,
    )
    
    return bot, token


async def start_web_server(bot: DayZTraderBot) -> None:
    """Start FastAPI web server in background"""
    try:
        from web.app import create_app
        
        app = create_app(bot)
        
        # Run with uvicorn
        import uvicorn
        
        web_host = os.getenv("WEB_HOST", "127.0.0.1")
        web_port = int(os.getenv("WEB_PORT", "8788"))
        
        config = uvicorn.Config(
            app,
            host=web_host,
            port=web_port,
            log_level="info",
            access_log=True,
        )
        
        server = uvicorn.Server(config)
        
        # Run server in background task
        logger.info(f"Starting web server on {web_host}:{web_port}")
        asyncio.create_task(server.serve())
        
    except Exception as e:
        logger.error(f"Failed to start web server: {e}")


async def main():
    """Main entry point"""
    logger.info("=" * 60)
    logger.info("DayZ Console Trader Bot v1.0.0")
    logger.info("=" * 60)
    
    # Create bot
    bot, token = create_bot()
    
    # Start web server if enabled
    if os.getenv("WEB_ENABLED", "true").lower() == "true":
        await start_web_server(bot)
    
    # Start the bot
    try:
        async with bot:
            await bot.start(token)
    except KeyboardInterrupt:
        logger.info("Bot shutting down...")
    except Exception as e:
        logger.critical(f"Bot failed to start: {e}")
        raise


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Interrupted")
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

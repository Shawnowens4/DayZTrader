"""
Economy Service - Player earning opportunities and money systems
Manages daily rewards, achievements, missions, bounties, gambling, etc.
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

from loguru import logger


class EconomyService:
    """Handle all player economy activities"""
    
    def __init__(self, config_loader, db_service):
        self.config = config_loader
        self.db = db_service
        
        # Earning rates from config
        self.daily_reward = self.config.get_setting('economy', 'daily_reward', default=500)
        self.kill_reward = self.config.get_setting('economy', 'kill_reward', default=1000)
        self.achievement_reward = self.config.get_setting('economy', 'achievement_reward', default=2000)
        self.mission_reward = self.config.get_setting('economy', 'mission_reward', default=5000)
        self.survival_hours_rate = self.config.get_setting('economy', 'survival_hours_rate', default=100)
    
    # ==================== DAILY REWARDS ====================
    
    async def claim_daily_reward(self, user_id: int) -> Tuple[bool, str, float]:
        """
        Claim daily login bonus
        
        Returns:
            (success, message, reward_amount)
        """
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            # Check if already claimed today
            from sqlalchemy.ext.asyncio import AsyncSession
            
            today = datetime.now().date()
            
            # Get last claim
            async for session in DatabaseService.get_session():
                result = await session.execute(
                    text("""
                        SELECT reward_amount, claimed_at FROM daily_rewards
                        WHERE user_id = :user_id
                        ORDER BY claimed_at DESC
                        LIMIT 1
                    """),
                    {"user_id": user_id}
                )
                row = result.fetchone()
            
            if row:
                last_claim = row[1]
                if isinstance(last_claim, str):
                    from datetime import datetime as dt
                    last_claim = dt.fromisoformat(last_claim).date()
                
                if last_claim == today:
                    return False, "Already claimed today", 0.0
            
            # Award daily reward
            reward = self.daily_reward
            
            # Bonus multiplier for streaks
            async for session in DatabaseService.get_session():
                # Count consecutive days
                result = await session.execute(
                    text("""
                        SELECT COUNT(*) as streak FROM (
                            SELECT DATE(claimed_at) as claim_date FROM daily_rewards
                            WHERE user_id = :user_id
                            ORDER BY claimed_at DESC
                            LIMIT 7
                        )
                    """),
                    {"user_id": user_id}
                )
                streak = result.scalar() or 0
            
            # Streak bonus: +10% per day (max +70% at 7 days)
            streak_bonus = reward * (streak * 0.10)
            final_reward = reward + streak_bonus
            
            # Save reward
            async for session in DatabaseService.get_session():
                await session.execute(
                    text("""
                        INSERT INTO daily_rewards (user_id, reward_amount, streak, claimed_at)
                        VALUES (:user_id, :amount, :streak, :now)
                    """),
                    {
                        "user_id": user_id,
                        "amount": final_reward,
                        "streak": streak + 1,
                        "now": datetime.now()
                    }
                )
                await session.commit()
            
            # Update balance
            await DatabaseService.update_user_balance(
                user_id,
                final_reward,
                f"Daily reward (streak: {streak + 1})"
            )
            
            message = f"✅ Claimed {final_reward:.0f} credits! (streak: {streak + 1} days)"
            return True, message, final_reward
        except Exception as e:
            logger.error(f"Daily reward error: {e}")
            return False, f"Error: {str(e)}", 0.0
    
    # ==================== ACHIEVEMENTS ====================
    
    async def unlock_achievement(
        self,
        user_id: int,
        achievement_id: str,
        achievement_name: str,
        description: str
    ) -> Tuple[bool, float]:
        """
        Unlock achievement and award bonus
        
        Args:
            user_id: Player Discord ID
            achievement_id: Unique achievement identifier
            achievement_name: Display name
            description: Achievement description
        
        Returns:
            (success, reward_amount)
        """
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            # Check if already unlocked
            async for session in DatabaseService.get_session():
                result = await session.execute(
                    text("""
                        SELECT id FROM achievements_unlocked
                        WHERE user_id = :user_id AND achievement_id = :achievement_id
                    """),
                    {"user_id": user_id, "achievement_id": achievement_id}
                )
                if result.fetchone():
                    return False, 0.0  # Already unlocked
            
            # Award achievement
            reward = self.achievement_reward
            
            # Save achievement
            async for session in DatabaseService.get_session():
                await session.execute(
                    text("""
                        INSERT INTO achievements_unlocked
                        (user_id, achievement_id, achievement_name, description, reward, unlocked_at)
                        VALUES (:user_id, :achievement_id, :name, :desc, :reward, :now)
                    """),
                    {
                        "user_id": user_id,
                        "achievement_id": achievement_id,
                        "name": achievement_name,
                        "desc": description,
                        "reward": reward,
                        "now": datetime.now()
                    }
                )
                await session.commit()
            
            # Update balance
            await DatabaseService.update_user_balance(
                user_id,
                reward,
                f"Achievement: {achievement_name}"
            )
            
            logger.info(f"Player {user_id} unlocked {achievement_id}: +{reward}")
            return True, reward
        except Exception as e:
            logger.error(f"Achievement error: {e}")
            return False, 0.0
    
    # ==================== SURVIVAL REWARDS ====================
    
    async def track_survival_time(
        self,
        user_id: int,
        survival_hours: int
    ) -> float:
        """
        Award money for survival time in-game
        
        Args:
            user_id: Player ID
            survival_hours: Hours survived on server
        
        Returns:
            Total reward amount
        """
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            reward = survival_hours * self.survival_hours_rate
            
            # Track survival
            async for session in DatabaseService.get_session():
                await session.execute(
                    text("""
                        INSERT INTO survival_tracking (user_id, hours_survived, reward, recorded_at)
                        VALUES (:user_id, :hours, :reward, :now)
                    """),
                    {
                        "user_id": user_id,
                        "hours": survival_hours,
                        "reward": reward,
                        "now": datetime.now()
                    }
                )
                await session.commit()
            
            # Award balance
            await DatabaseService.update_user_balance(
                user_id,
                reward,
                f"Survival reward ({survival_hours}h on server)"
            )
            
            logger.info(f"Player {user_id} earned {reward} for {survival_hours}h survival")
            return reward
        except Exception as e:
            logger.error(f"Survival tracking error: {e}")
            return 0.0
    
    # ==================== BOUNTIES ====================
    
    async def place_bounty(
        self,
        bounty_placer_id: int,
        target_name: str,
        amount: float,
        reason: str
    ) -> Tuple[bool, str]:
        """
        Place bounty on a player
        
        Args:
            bounty_placer_id: Who's placing the bounty
            target_name: Target player name
            amount: Bounty reward amount
            reason: Reason for bounty
        
        Returns:
            (success, message)
        """
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            # Check balance
            placer_balance = await DatabaseService.get_user_balance(bounty_placer_id)
            if placer_balance < amount:
                return False, "Insufficient balance for bounty"
            
            # Deduct from placer
            await DatabaseService.update_user_balance(
                bounty_placer_id,
                -amount,
                f"Bounty placed on {target_name}"
            )
            
            # Place bounty
            async for session in DatabaseService.get_session():
                await session.execute(
                    text("""
                        INSERT INTO bounties (placer_id, target_name, amount, reason, status, created_at)
                        VALUES (:placer_id, :target, :amount, :reason, 'active', :now)
                    """),
                    {
                        "placer_id": bounty_placer_id,
                        "target": target_name,
                        "amount": amount,
                        "reason": reason,
                        "now": datetime.now()
                    }
                )
                await session.commit()
            
            logger.info(f"Bounty placed: {amount} on {target_name}")
            return True, f"Bounty of {amount:.0f} placed on {target_name}"
        except Exception as e:
            logger.error(f"Bounty error: {e}")
            return False, str(e)
    
    async def claim_bounty(
        self,
        hunter_id: int,
        target_name: str
    ) -> Tuple[bool, str, float]:
        """
        Claim active bounty
        
        Args:
            hunter_id: Player claiming bounty
            target_name: Target of bounty
        
        Returns:
            (success, message, reward)
        """
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            # Get active bounty
            async for session in DatabaseService.get_session():
                result = await session.execute(
                    text("""
                        SELECT id, amount FROM bounties
                        WHERE target_name = :target AND status = 'active'
                        ORDER BY created_at DESC
                        LIMIT 1
                    """),
                    {"target": target_name}
                )
                bounty = result.fetchone()
            
            if not bounty:
                return False, "No active bounty on this player", 0.0
            
            bounty_id, amount = bounty
            
            # Award to hunter
            await DatabaseService.update_user_balance(
                hunter_id,
                amount,
                f"Bounty claimed: {target_name}"
            )
            
            # Mark bounty as claimed
            async for session in DatabaseService.get_session():
                await session.execute(
                    text("""
                        UPDATE bounties
                        SET status = 'claimed', hunter_id = :hunter_id, claimed_at = :now
                        WHERE id = :bounty_id
                    """),
                    {
                        "bounty_id": bounty_id,
                        "hunter_id": hunter_id,
                        "now": datetime.now()
                    }
                )
                await session.commit()
            
            logger.info(f"Bounty claimed: {hunter_id} earned {amount} on {target_name}")
            return True, f"Bounty claimed! Earned {amount:.0f}", amount
        except Exception as e:
            logger.error(f"Bounty claim error: {e}")
            return False, str(e), 0.0
    
    # ==================== GAMBLING ====================
    
    async def coin_flip(
        self,
        user_id: int,
        bet_amount: float,
        choice: str  # "heads" or "tails"
    ) -> Tuple[bool, str, float]:
        """
        Coin flip gambling
        
        Args:
            user_id: Player ID
            bet_amount: Amount to bet
            choice: "heads" or "tails"
        
        Returns:
            (success, message, net_change)
        """
        import random
        from bot.services.database import DatabaseService
        
        try:
            # Check balance
            balance = await DatabaseService.get_user_balance(user_id)
            if balance < bet_amount:
                return False, "Insufficient balance", 0.0
            
            # Flip coin
            result = random.choice(["heads", "tails"])
            won = result == choice.lower()
            
            if won:
                # Win 2x bet
                payout = bet_amount * 2
                net = payout
                message = f"🎉 You won! Heads it is! +{payout:.0f}"
            else:
                # Lose bet
                net = -bet_amount
                message = f"😢 You lost! It was {result}. -{bet_amount:.0f}"
            
            # Update balance
            await DatabaseService.update_user_balance(
                user_id,
                net,
                f"Coin flip: {choice} - {result}"
            )
            
            return True, message, net
        except Exception as e:
            logger.error(f"Coin flip error: {e}")
            return False, str(e), 0.0
    
    async def dice_roll(
        self,
        user_id: int,
        bet_amount: float,
        prediction: int  # 1-6
    ) -> Tuple[bool, str, float]:
        """
        Dice roll gambling
        
        Args:
            user_id: Player ID
            bet_amount: Amount to bet
            prediction: Predicted roll (1-6)
        
        Returns:
            (success, message, net_change)
        """
        import random
        from bot.services.database import DatabaseService
        
        try:
            if not (1 <= prediction <= 6):
                return False, "Invalid prediction (1-6)", 0.0
            
            # Check balance
            balance = await DatabaseService.get_user_balance(user_id)
            if balance < bet_amount:
                return False, "Insufficient balance", 0.0
            
            # Roll dice
            roll = random.randint(1, 6)
            won = roll == prediction
            
            if won:
                # Win 5x bet
                payout = bet_amount * 5
                net = payout
                message = f"🎲 You rolled {roll}! You won {payout:.0f}!"
            else:
                # Lose bet
                net = -bet_amount
                message = f"🎲 You rolled {roll}, not {prediction}. Lost {bet_amount:.0f}"
            
            # Update balance
            await DatabaseService.update_user_balance(
                user_id,
                net,
                f"Dice roll: predicted {prediction}, got {roll}"
            )
            
            return True, message, net
        except Exception as e:
            logger.error(f"Dice roll error: {e}")
            return False, str(e), 0.0
    
    # ==================== MISSIONS ====================
    
    async def get_available_missions(self, user_id: int) -> List[Dict]:
        """Get available missions for player"""
        from sqlalchemy import text
        
        try:
            from bot.services.database import DatabaseService
            
            async for session in DatabaseService.get_session():
                result = await session.execute(
                    text("""
                        SELECT id, title, description, reward, difficulty
                        FROM missions
                        WHERE enabled = 1
                        AND id NOT IN (
                            SELECT mission_id FROM mission_progress
                            WHERE user_id = :user_id AND status IN ('completed', 'abandoned')
                        )
                        LIMIT 10
                    """),
                    {"user_id": user_id}
                )
                rows = result.fetchall()
            
            missions = []
            for row in rows:
                missions.append({
                    "id": row[0],
                    "title": row[1],
                    "description": row[2],
                    "reward": row[3],
                    "difficulty": row[4]
                })
            
            return missions
        except Exception as e:
            logger.error(f"Get missions error: {e}")
            return []
    
    async def complete_mission(
        self,
        user_id: int,
        mission_id: int
    ) -> Tuple[bool, str, float]:
        """
        Complete a mission and award reward
        
        Returns:
            (success, message, reward)
        """
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            # Get mission
            async for session in DatabaseService.get_session():
                result = await session.execute(
                    text("""
                        SELECT title, reward FROM missions WHERE id = :mission_id
                    """),
                    {"mission_id": mission_id}
                )
                mission = result.fetchone()
            
            if not mission:
                return False, "Mission not found", 0.0
            
            title, reward = mission
            
            # Mark complete
            async for session in DatabaseService.get_session():
                await session.execute(
                    text("""
                        UPDATE mission_progress
                        SET status = 'completed', completed_at = :now
                        WHERE user_id = :user_id AND mission_id = :mission_id
                    """),
                    {
                        "user_id": user_id,
                        "mission_id": mission_id,
                        "now": datetime.now()
                    }
                )
                await session.commit()
            
            # Award balance
            await DatabaseService.update_user_balance(
                user_id,
                reward,
                f"Mission complete: {title}"
            )
            
            logger.info(f"Player {user_id} completed mission {mission_id}: +{reward}")
            return True, f"✅ Mission complete! +{reward:.0f}", reward
        except Exception as e:
            logger.error(f"Complete mission error: {e}")
            return False, str(e), 0.0
    
    # ==================== LEADERBOARDS ====================
    
    async def get_leaderboard(self, limit: int = 10) -> List[Dict]:
        """Get top earners leaderboard"""
        from sqlalchemy import text
        from bot.services.database import DatabaseService
        
        try:
            async for session in DatabaseService.get_session():
                result = await session.execute(
                    text("""
                        SELECT discord_id, username, balance, total_earned
                        FROM users
                        ORDER BY balance DESC
                        LIMIT :limit
                    """),
                    {"limit": limit}
                )
                rows = result.fetchall()
            
            leaderboard = []
            for rank, row in enumerate(rows, 1):
                leaderboard.append({
                    "rank": rank,
                    "user_id": row[0],
                    "username": row[1],
                    "balance": row[2],
                    "total_earned": row[3]
                })
            
            return leaderboard
        except Exception as e:
            logger.error(f"Leaderboard error: {e}")
            return []

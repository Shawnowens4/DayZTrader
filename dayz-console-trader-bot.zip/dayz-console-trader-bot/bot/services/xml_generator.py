"""
XML generator for DayZ Central Loot Economy (CLE)
Generates valid cfgspawnabletypes XML for vehicles and cargo
"""

import hashlib
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional

from loguru import logger


class XMLGenerator:
    """Generate CLE XML for vehicle and cargo spawning"""
    
    def __init__(self, config_loader):
        self.config = config_loader
    
    def generate_vehicle_type_xml(
        self,
        vehicle_classname: str,
        parts: Dict[str, str],
        run_parts: List[Dict[str, Any]],
        cargo: Optional[List[Dict[str, Any]]] = None,
        spawn_chance: float = 1.0
    ) -> str:
        """
        Generate XML for vehicle spawn
        
        Args:
            vehicle_classname: Vehicle classname
            parts: {part_key: part_classname} dict
            run_parts: List of required run parts
            cargo: Trunk cargo items
            spawn_chance: Spawn probability (0-1)
        
        Returns:
            XML string
        """
        # Create root element
        vehicle_elem = ET.Element("type")
        vehicle_elem.set("name", vehicle_classname)
        
        # Add attachments (parts + run parts)
        attachments = ET.SubElement(vehicle_elem, "attachments")
        attachments.set("chance", str(spawn_chance))
        
        # Add vehicle parts
        for part_key, part_classname in parts.items():
            part = ET.SubElement(attachments, "item")
            part.set("name", part_classname)
            part.set("chance", "1.0")
        
        # Add run parts
        for run_part in run_parts:
            part = ET.SubElement(attachments, "item")
            part.set("name", run_part.get("classname"))
            part.set("chance", "1.0")
        
        # Add cargo (trunk items)
        if cargo:
            cargo_elem = ET.SubElement(vehicle_elem, "cargo")
            cargo_elem.set("chance", "1.0")
            
            for item in cargo:
                item_elem = ET.SubElement(cargo_elem, "item")
                item_elem.set("name", item.get("classname"))
                item_elem.set("chance", "1.0")
                quantity = item.get("quantity", 1)
                if quantity > 1:
                    item_elem.set("quantity_min", str(quantity))
                    item_elem.set("quantity_max", str(quantity))
        
        # Convert to pretty XML string
        return self._element_to_xml_string(vehicle_elem)
    
    def generate_cargo_snippet_xml(
        self,
        cargo_items: List[Dict[str, Any]]
    ) -> str:
        """
        Generate XML cargo snippet for nesting
        
        Args:
            cargo_items: List of {classname, quantity} dicts
        
        Returns:
            XML cargo element string
        """
        cargo_elem = ET.Element("cargo")
        cargo_elem.set("chance", "1.0")
        
        for item in cargo_items:
            item_elem = ET.SubElement(cargo_elem, "item")
            item_elem.set("name", item.get("classname"))
            item_elem.set("chance", "1.0")
            
            quantity = item.get("quantity", 1)
            if quantity > 1:
                item_elem.set("quantity_min", str(quantity))
                item_elem.set("quantity_max", str(quantity))
        
        return self._element_to_xml_string(cargo_elem)
    
    def generate_cfgspawnabletypes_snippet(
        self,
        vehicle_configs: List[Dict[str, Any]]
    ) -> str:
        """
        Generate cfgspawnabletypes XML snippet
        
        Args:
            vehicle_configs: List of vehicle configurations
        
        Returns:
            XML types element string
        """
        types_elem = ET.Element("types")
        
        for config in vehicle_configs:
            type_elem = self._create_type_element(config)
            types_elem.append(type_elem)
        
        return self._element_to_xml_string(types_elem)
    
    def _create_type_element(self, config: Dict[str, Any]) -> ET.Element:
        """Create a type element from config"""
        classname = config.get("classname")
        type_elem = ET.Element("type")
        type_elem.set("name", classname)
        
        # Add name (display)
        name_elem = ET.SubElement(type_elem, "name")
        name_elem.text = config.get("display_name", classname)
        
        # Add attachments/parts
        if "parts" in config:
            attachments = ET.SubElement(type_elem, "attachments")
            attachments.set("chance", "1.0")
            
            for part in config.get("parts", {}).values():
                part_elem = ET.SubElement(attachments, "item")
                part_elem.set("name", part.get("classname"))
                part_elem.set("chance", "1.0")
        
        # Add cargo
        if "cargo" in config:
            cargo_elem = ET.SubElement(type_elem, "cargo")
            cargo_elem.set("chance", "1.0")
            
            for item in config.get("cargo", []):
                item_elem = ET.SubElement(cargo_elem, "item")
                item_elem.set("name", item.get("classname"))
                item_elem.set("chance", "1.0")
        
        return type_elem
    
    def _element_to_xml_string(self, elem: ET.Element, indent: int = 0) -> str:
        """Convert element to XML string with pretty formatting"""
        ET.indent(elem, space="  ")
        return ET.tostring(elem, encoding="unicode")
    
    def validate_xml(self, xml_string: str) -> tuple:
        """
        Validate XML is well-formed
        
        Args:
            xml_string: XML to validate
        
        Returns:
            (valid, error_message)
        """
        try:
            from lxml import etree
            
            etree.fromstring(xml_string.encode("utf-8"))
            return True, "XML valid"
        except Exception as e:
            logger.error(f"XML validation failed: {e}")
            return False, str(e)
    
    def generate_xml_hash(self, xml_string: str) -> str:
        """
        Generate SHA256 hash of XML for deduplication
        
        Args:
            xml_string: XML to hash
        
        Returns:
            Hex hash string
        """
        return hashlib.sha256(xml_string.encode("utf-8")).hexdigest()
    
    def generate_event_xml(
        self,
        event_name: str,
        vehicle_classname: str,
        spawn_x: float,
        spawn_z: float,
        spawn_y: float = 0,
        chance: float = 1.0,
        num: int = 1
    ) -> str:
        """
        Generate temporary event XML for single spawn
        
        This is an alternative to modifying cfgspawnabletypes.xml
        for admin-triggered spawns.
        
        Args:
            event_name: Event name identifier
            vehicle_classname: Vehicle to spawn
            spawn_x: World X coordinate
            spawn_z: World Z coordinate
            spawn_y: World Y coordinate
            chance: Spawn chance (0-1)
            num: Number to spawn
        
        Returns:
            XML event string
        """
        event = ET.Element("event")
        event.set("name", event_name)
        event.set("chance", str(chance))
        event.set("num", str(num))
        
        # Add location
        location = ET.SubElement(event, "location")
        position = ET.SubElement(location, "position")
        position.set("x", str(spawn_x))
        position.set("y", str(spawn_y))
        position.set("z", str(spawn_z))
        position.set("a", "0")
        
        # Add object
        obj = ET.SubElement(event, "object")
        obj.set("name", vehicle_classname)
        
        return self._element_to_xml_string(event)
    
    def generate_cfgeconomycore_include(
        self,
        include_path: str,
        description: str = "Trader vehicle spawns"
    ) -> str:
        """
        Generate include directive for cfgeconomycore.xml
        
        Args:
            include_path: Path to include file (relative to mission root)
            description: Description comment
        
        Returns:
            XML include snippet
        """
        # This is an XML comment followed by include directive
        xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<!-- {description} -->
<cfgeconomycore>
    <include name="{include_path}"/>
</cfgeconomycore>"""
        
        return xml


class XMLBuilder:
    """Build complex XML structures programmatically"""
    
    def __init__(self, generator: XMLGenerator):
        self.generator = generator
        self.root = ET.Element("root")
    
    def add_vehicle_spawn(
        self,
        vehicle_classname: str,
        parts: Dict[str, str],
        run_parts: List[Dict[str, Any]],
        cargo: Optional[List[Dict[str, Any]]] = None
    ) -> None:
        """Add vehicle spawn to batch"""
        vehicle_xml = self.generator.generate_vehicle_type_xml(
            vehicle_classname,
            parts,
            run_parts,
            cargo
        )
        
        # Parse and add to root
        vehicle_elem = ET.fromstring(vehicle_xml)
        self.root.append(vehicle_elem)
    
    def get_xml(self) -> str:
        """Get complete XML"""
        return self.generator._element_to_xml_string(self.root)
    
    def get_hash(self) -> str:
        """Get hash of current XML"""
        return self.generator.generate_xml_hash(self.get_xml())

"""
Configuration loader for YAML and JSON settings
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from loguru import logger


class ConfigLoader:
    """Loads and caches configuration files (YAML and JSON)"""
    
    def __init__(self, config_dir: Path):
        self.config_dir = Path(config_dir)
        self.settings: Dict[str, Any] = {}
        self.vehicle_defs: Dict[str, Any] = {}
        self.console_items: Dict[str, Any] = {}
        self.nesting_rules: Dict[str, Any] = {}
        self.spawn_zones: Dict[str, Any] = {}
    
    async def load_all(self) -> None:
        """Load all configuration files"""
        await self.load_settings()
        await self.load_vehicle_defs()
        await self.load_console_items()
        await self.load_nesting_rules()
        await self.load_spawn_zones()
        logger.info("All configs loaded successfully")
    
    async def load_settings(self) -> None:
        """Load settings.yaml"""
        settings_file = self.config_dir / "settings.yaml"
        
        if not settings_file.exists():
            logger.warning(f"settings.yaml not found at {settings_file}")
            self.settings = {}
            return
        
        try:
            with open(settings_file, "r", encoding="utf-8") as f:
                self.settings = yaml.safe_load(f) or {}
            logger.info(f"Loaded settings from {settings_file}")
        except Exception as e:
            logger.error(f"Failed to load settings.yaml: {e}")
            raise
    
    async def load_vehicle_defs(self) -> None:
        """Load vehicle_defs.json"""
        vehicle_file = self.config_dir / "vehicle_defs.json"
        
        if not vehicle_file.exists():
            logger.warning(f"vehicle_defs.json not found at {vehicle_file}")
            self.vehicle_defs = {"vehicles": []}
            return
        
        try:
            with open(vehicle_file, "r", encoding="utf-8") as f:
                self.vehicle_defs = json.load(f)
            logger.info(f"Loaded {len(self.vehicle_defs.get('vehicles', []))} vehicles from {vehicle_file}")
        except Exception as e:
            logger.error(f"Failed to load vehicle_defs.json: {e}")
            raise
    
    async def load_console_items(self) -> None:
        """Load console_items.json"""
        items_file = self.config_dir / "console_items.json"
        
        if not items_file.exists():
            logger.warning(f"console_items.json not found at {items_file}")
            self.console_items = {"items": []}
            return
        
        try:
            with open(items_file, "r", encoding="utf-8") as f:
                self.console_items = json.load(f)
            logger.info(f"Loaded {len(self.console_items.get('items', []))} items from {items_file}")
        except Exception as e:
            logger.error(f"Failed to load console_items.json: {e}")
            raise
    
    async def load_nesting_rules(self) -> None:
        """Load nesting_rules.json"""
        nesting_file = self.config_dir / "nesting_rules.json"
        
        if not nesting_file.exists():
            logger.warning(f"nesting_rules.json not found at {nesting_file}")
            self.nesting_rules = {}
            return
        
        try:
            with open(nesting_file, "r", encoding="utf-8") as f:
                self.nesting_rules = json.load(f)
            logger.info(f"Loaded nesting rules from {nesting_file}")
        except Exception as e:
            logger.error(f"Failed to load nesting_rules.json: {e}")
            raise
    
    async def load_spawn_zones(self) -> None:
        """Load spawn_zones.json (optional)"""
        zones_file = self.config_dir / "spawn_zones.json"
        
        if not zones_file.exists():
            logger.info("spawn_zones.json not found (optional)")
            self.spawn_zones = {"safe_zones": [], "blacklist_zones": []}
            return
        
        try:
            with open(zones_file, "r", encoding="utf-8") as f:
                self.spawn_zones = json.load(f)
            logger.info(f"Loaded spawn zones from {zones_file}")
        except Exception as e:
            logger.error(f"Failed to load spawn_zones.json: {e}")
            raise
    
    def get_vehicle(self, classname: str) -> Optional[Dict[str, Any]]:
        """Get vehicle definition by classname"""
        for vehicle in self.vehicle_defs.get("vehicles", []):
            if vehicle.get("classname") == classname:
                return vehicle
        return None
    
    def get_item(self, classname: str) -> Optional[Dict[str, Any]]:
        """Get item definition by classname"""
        for item in self.console_items.get("items", []):
            if item.get("classname") == classname:
                return item
        return None
    
    def get_setting(self, *keys: str, default: Any = None) -> Any:
        """Get nested setting by dot notation or keys"""
        value = self.settings
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
                if value is None:
                    return default
            else:
                return default
        return value if value is not None else default
    
    def reload_vehicle_defs(self) -> None:
        """Reload vehicle_defs.json from disk"""
        import asyncio
        asyncio.create_task(self.load_vehicle_defs())
    
    def reload_console_items(self) -> None:
        """Reload console_items.json from disk"""
        import asyncio
        asyncio.create_task(self.load_console_items())
    
    def reload_nesting_rules(self) -> None:
        """Reload nesting_rules.json from disk"""
        import asyncio
        asyncio.create_task(self.load_nesting_rules())
    
    def reload_all(self) -> None:
        """Reload all configs from disk"""
        import asyncio
        asyncio.create_task(self.load_all())

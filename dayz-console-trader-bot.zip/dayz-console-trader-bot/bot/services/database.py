"""
Database initialization and session management
Supports SQLite and PostgreSQL with async drivers
"""

import os
from pathlib import Path
from typing import AsyncGenerator, Optional

from loguru import logger
from sqlalchemy import create_engine, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

# Global session maker
SessionLocal: Optional[sessionmaker] = None


async def init_db() -> None:
    """Initialize database and create tables"""
    global SessionLocal
    
    db_url = os.getenv(
        "DATABASE_URL",
        "sqlite+aiosqlite:///./data/trader.db"
    )
    
    logger.info(f"Initializing database: {db_url.split('@')[-1] if '@' in db_url else 'SQLite'}")
    
    # Create engine
    engine = create_async_engine(
        db_url,
        echo=False,  # Set to True for SQL debug logging
        future=True,
        pool_pre_ping=True,
    )
    
    # Create session factory
    SessionLocal = sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        future=True,
    )
    
    # Create tables from schema
    schema_path = Path(__file__).parent.parent.parent / "data" / "schema.sql"
    
    if schema_path.exists():
        async with engine.begin() as conn:
            # Read schema file
            with open(schema_path, "r", encoding="utf-8") as f:
                schema = f.read()
            
            # Execute schema (split by semicolon for SQLite compatibility)
            statements = [s.strip() for s in schema.split(";") if s.strip()]
            
            for statement in statements:
                try:
                    await conn.execute(text(statement))
                except Exception as e:
                    # Some statements might fail (e.g., trigger creation)
                    logger.debug(f"Schema statement skipped: {e}")
        
        logger.info(f"Database schema initialized from {schema_path}")
    else:
        logger.warning(f"Schema file not found: {schema_path}")
    
    # Verify connection
    try:
        async with SessionLocal() as session:
            await session.execute(text("SELECT 1"))
        logger.info("Database connection verified")
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        raise


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """Get async database session"""
    if SessionLocal is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    
    async with SessionLocal() as session:
        try:
            yield session
        except Exception as e:
            await session.rollback()
            logger.error(f"Session error: {e}")
            raise
        finally:
            await session.close()


class DatabaseService:
    """High-level database operations service"""
    
    @staticmethod
    async def get_user_balance(user_id: int) -> float:
        """Get user's current balance"""
        async for session in get_session():
            try:
                from sqlalchemy import select
                from sqlalchemy.orm import Query
                
                # Execute raw SQL for simplicity
                result = await session.execute(
                    text("SELECT balance FROM users WHERE discord_id = :user_id"),
                    {"user_id": user_id}
                )
                row = result.fetchone()
                return float(row[0]) if row else 0.0
            except Exception as e:
                logger.error(f"Failed to get user balance: {e}")
                return 0.0
    
    @staticmethod
    async def update_user_balance(user_id: int, amount: float, reason: str = "") -> bool:
        """Update user balance (add/subtract)"""
        async for session in get_session():
            try:
                # Ensure user exists
                await session.execute(
                    text("""
                        INSERT OR IGNORE INTO users (discord_id, username, balance)
                        VALUES (:user_id, :username, :balance)
                    """),
                    {"user_id": user_id, "username": f"User_{user_id}", "balance": 0}
                )
                
                # Update balance
                await session.execute(
                    text("""
                        UPDATE users 
                        SET balance = balance + :amount
                        WHERE discord_id = :user_id
                    """),
                    {"amount": amount, "user_id": user_id}
                )
                
                # Log transaction
                new_balance = await DatabaseService.get_user_balance(user_id)
                await session.execute(
                    text("""
                        INSERT INTO balance_log (user_id, amount_change, reason, new_balance)
                        VALUES (:user_id, :amount, :reason, :new_balance)
                    """),
                    {"user_id": user_id, "amount": amount, "reason": reason, "new_balance": new_balance}
                )
                
                await session.commit()
                logger.info(f"Updated balance for user {user_id}: {amount:+.2f} ({reason})")
                return True
            except Exception as e:
                logger.error(f"Failed to update user balance: {e}")
                await session.rollback()
                return False
    
    @staticmethod
    async def create_order(
        user_id: int,
        order_type: str,
        vehicle_classname: Optional[str] = None,
        cargo_json: Optional[str] = None,
        spawn_x: float = 0,
        spawn_z: float = 0,
        total_cost: float = 0
    ) -> Optional[int]:
        """Create a new order"""
        async for session in get_session():
            try:
                result = await session.execute(
                    text("""
                        INSERT INTO orders (
                            user_id, order_type, vehicle_classname, cargo_json,
                            spawn_x, spawn_z, total_cost, status
                        ) VALUES (
                            :user_id, :order_type, :vehicle_classname, :cargo_json,
                            :spawn_x, :spawn_z, :total_cost, 'pending'
                        )
                    """),
                    {
                        "user_id": user_id,
                        "order_type": order_type,
                        "vehicle_classname": vehicle_classname,
                        "cargo_json": cargo_json,
                        "spawn_x": spawn_x,
                        "spawn_z": spawn_z,
                        "total_cost": total_cost,
                    }
                )
                
                await session.commit()
                logger.info(f"Created order for user {user_id}: {order_type}")
                
                # Return last inserted ID
                result = await session.execute(
                    text("SELECT last_insert_rowid()")
                )
                return result.scalar()
            except Exception as e:
                logger.error(f"Failed to create order: {e}")
                await session.rollback()
                return None
    
    @staticmethod
    async def update_order_status(
        order_id: int,
        status: str,
        message: str = ""
    ) -> bool:
        """Update order status"""
        async for session in get_session():
            try:
                await session.execute(
                    text("""
                        UPDATE orders
                        SET status = :status, message = :message
                        WHERE id = :order_id
                    """),
                    {"status": status, "message": message, "order_id": order_id}
                )
                
                await session.commit()
                logger.info(f"Updated order {order_id} status: {status}")
                return True
            except Exception as e:
                logger.error(f"Failed to update order status: {e}")
                await session.rollback()
                return False


# Dependency injection for FastAPI
async def get_db():
    """FastAPI dependency for database sessions"""
    async for session in get_session():
        yield session

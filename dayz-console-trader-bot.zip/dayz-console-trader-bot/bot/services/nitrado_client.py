"""
Nitrado API client for DayZ server operations
Handles file upload/download, server info, and restarts
"""

import asyncio
import hashlib
from datetime import datetime
from typing import Any, Dict, Optional

import aiohttp
from loguru import logger


class NitradoClient:
    """Nitrado API client"""
    
    BASE_URL = "https://api.nitrado.net/api/v1"
    
    def __init__(self, api_token: str, service_id: str, timeout: int = 30):
        """
        Args:
            api_token: Nitrado API token
            service_id: Nitrado service ID
            timeout: Request timeout in seconds
        """
        self.api_token = api_token
        self.service_id = service_id
        self.timeout = timeout
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def _request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Make API request
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            **kwargs: Additional request arguments
        
        Returns:
            Response JSON
        """
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        url = f"{self.BASE_URL}{endpoint}"
        headers = {
            "Authorization": f"Bearer {self.api_token}",
            "Accept": "application/json",
        }
        
        try:
            async with self.session.request(
                method,
                url,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                **kwargs
            ) as response:
                data = await response.json()
                
                if response.status >= 400:
                    logger.error(f"API error {response.status}: {data}")
                    return {"error": True, "status": response.status, "data": data}
                
                return data
        except asyncio.TimeoutError:
            logger.error(f"API request timeout: {endpoint}")
            return {"error": True, "timeout": True}
        except Exception as e:
            logger.error(f"API request failed: {e}")
            return {"error": True, "exception": str(e)}
    
    async def get_gameserver_info(self) -> Dict[str, Any]:
        """
        Get gameserver information
        
        Returns:
            Gameserver info (status, folder, etc.)
        """
        response = await self._request(
            "GET",
            f"/services/{self.service_id}/gameservers"
        )
        
        if response.get("error"):
            return {}
        
        try:
            return response.get("data", {}).get("gameserver", {})
        except:
            return {}
    
    async def get_file_server_token(self) -> Optional[str]:
        """
        Get file server upload/download token
        
        Returns:
            Token for file operations
        """
        response = await self._request(
            "GET",
            f"/services/{self.service_id}/gameservers/file-server-token"
        )
        
        if response.get("error"):
            logger.error("Failed to get file server token")
            return None
        
        try:
            return response.get("data", {}).get("token")
        except:
            return None
    
    async def list_files(
        self,
        path: str = "/"
    ) -> list:
        """
        List files in directory
        
        Args:
            path: Directory path on file server
        
        Returns:
            List of files
        """
        token = await self.get_file_server_token()
        if not token:
            return []
        
        # File server uses different endpoint
        # This is a simplified example; actual implementation may differ
        logger.debug(f"Listing files at {path}")
        return []
    
    async def download_file(
        self,
        remote_path: str,
        local_file: str
    ) -> bool:
        """
        Download file from file server
        
        Args:
            remote_path: Remote file path
            local_file: Local destination
        
        Returns:
            Success status
        """
        token = await self.get_file_server_token()
        if not token:
            logger.error("Cannot download: no file server token")
            return False
        
        # File server download
        # Implementation depends on Nitrado's file server API
        logger.info(f"Downloading {remote_path} to {local_file}")
        return False  # Placeholder
    
    async def upload_file(
        self,
        local_file: str,
        remote_path: str
    ) -> bool:
        """
        Upload file to file server
        
        Args:
            local_file: Local file to upload
            remote_path: Remote destination path
        
        Returns:
            Success status
        """
        token = await self.get_file_server_token()
        if not token:
            logger.error("Cannot upload: no file server token")
            return False
        
        # File server upload
        # Implementation depends on Nitrado's file server API
        logger.info(f"Uploading {local_file} to {remote_path}")
        return False  # Placeholder
    
    async def restart_gameserver(self, force: bool = False) -> bool:
        """
        Restart gameserver
        
        Args:
            force: Force restart
        
        Returns:
            Success status
        """
        response = await self._request(
            "POST",
            f"/services/{self.service_id}/gameservers/restart",
            json={"force": force}
        )
        
        if response.get("error"):
            logger.error("Gameserver restart failed")
            return False
        
        logger.info("Gameserver restart initiated")
        return True
    
    async def stop_gameserver(self) -> bool:
        """Stop gameserver"""
        response = await self._request(
            "POST",
            f"/services/{self.service_id}/gameservers/stop"
        )
        
        return not response.get("error")
    
    async def start_gameserver(self) -> bool:
        """Start gameserver"""
        response = await self._request(
            "POST",
            f"/services/{self.service_id}/gameservers/start"
        )
        
        return not response.get("error")
    
    async def send_command(self, command: str) -> bool:
        """
        Send server console command
        
        Args:
            command: Console command
        
        Returns:
            Success status
        """
        response = await self._request(
            "POST",
            f"/services/{self.service_id}/gameservers/execute",
            json={"command": command}
        )
        
        return not response.get("error")
    
    async def close(self) -> None:
        """Close HTTP session"""
        if self.session:
            await self.session.close()


class NitradoService:
    """High-level Nitrado service wrapper"""
    
    def __init__(self, client: NitradoClient):
        self.client = client
    
    async def get_mission_folder_info(self) -> Dict[str, Any]:
        """Get mission folder information"""
        info = await self.client.get_gameserver_info()
        
        if not info:
            return {}
        
        return {
            "status": info.get("status", "unknown"),
            "folder_path": info.get("path", ""),
            "ip": info.get("ip", ""),
            "port": info.get("port", 0),
        }
    
    async def deploy_mission_update(
        self,
        local_file: str,
        remote_path: str,
        auto_restart: bool = False
    ) -> bool:
        """
        Deploy mission file update
        
        Args:
            local_file: Local mission file
            remote_path: Remote mission path
            auto_restart: Restart server after deploy
        
        Returns:
            Success status
        """
        logger.info(f"Deploying mission update: {local_file} → {remote_path}")
        
        # Upload file
        if not await self.client.upload_file(local_file, remote_path):
            logger.error("Mission upload failed")
            return False
        
        # Restart if requested
        if auto_restart:
            if not await self.client.restart_gameserver(force=True):
                logger.error("Server restart failed")
                return False
        
        logger.info("Mission deployment complete")
        return True

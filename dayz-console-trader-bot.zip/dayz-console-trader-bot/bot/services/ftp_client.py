"""
FTPS client for Nitrado mission file operations
Backup, upload, and verify mission files safely
"""

import asyncio
import hashlib
import io
import os
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

from loguru import logger

try:
    import ftputil
except ImportError:
    ftputil = None


class FTPClient:
    """FTPS client for mission file operations"""
    
    def __init__(
        self,
        host: str,
        user: str,
        password: str,
        port: int = 21,
        use_ftps: bool = True,
        timeout: int = 30
    ):
        """
        Args:
            host: FTP server hostname
            user: FTP username
            password: FTP password
            port: FTP port (default 21)
            use_ftps: Use FTPS (implicit TLS)
            timeout: Connection timeout in seconds
        """
        self.host = host
        self.user = user
        self.password = password
        self.port = port
        self.use_ftps = use_ftps
        self.timeout = timeout
        
        if ftputil is None:
            raise ImportError("ftputil is required. Install with: pip install ftputil")
        
        self.conn = None
    
    async def connect(self) -> bool:
        """Establish FTP connection"""
        try:
            # Run blocking FTP operation in thread pool
            loop = asyncio.get_event_loop()
            
            def _connect():
                if self.use_ftps:
                    # FTPS (implicit TLS)
                    self.conn = ftputil.FTPHost(
                        self.host,
                        self.user,
                        self.password,
                        port=self.port,
                        timeout=self.timeout,
                        use_passive=True
                    )
                else:
                    # Standard FTP
                    self.conn = ftputil.FTPHost(
                        self.host,
                        self.user,
                        self.password,
                        port=self.port,
                        timeout=self.timeout,
                        use_passive=True
                    )
            
            await loop.run_in_executor(None, _connect)
            logger.info(f"Connected to FTP: {self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"FTP connection failed: {e}")
            return False
    
    async def disconnect(self) -> None:
        """Close FTP connection"""
        if self.conn:
            try:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, self.conn.close)
                logger.info("Disconnected from FTP")
            except Exception as e:
                logger.warning(f"Error closing FTP connection: {e}")
    
    async def backup_mission(
        self,
        remote_path: str,
        backup_dir: str = "backups"
    ) -> Optional[str]:
        """
        Backup mission folder to ZIP file
        
        Args:
            remote_path: Remote mission folder path (e.g., '/dayzxb_mission/dayzoffline.chernarusplus')
            backup_dir: Local backup directory
        
        Returns:
            Local backup file path or None if failed
        """
        if not self.conn:
            logger.error("Not connected to FTP")
            return None
        
        try:
            # Create backup directory
            backup_path = Path(backup_dir)
            backup_path.mkdir(parents=True, exist_ok=True)
            
            # Generate backup filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = backup_path / f"mission_{timestamp}.zip"
            
            logger.info(f"Backing up mission from {remote_path}...")
            
            loop = asyncio.get_event_loop()
            
            def _backup():
                with zipfile.ZipFile(backup_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    # Walk remote directory
                    for root, dirs, files in self.conn.walk(remote_path):
                        for file in files:
                            remote_file = os.path.join(root, file)
                            arcname = os.path.relpath(remote_file, remote_path)
                            
                            # Download and add to zip
                            file_data = io.BytesIO()
                            self.conn.retrbinary(f'RETR {remote_file}', file_data.write)
                            file_data.seek(0)
                            zipf.writestr(arcname, file_data.read())
            
            await loop.run_in_executor(None, _backup)
            
            logger.info(f"Mission backed up to {backup_file}")
            return str(backup_file)
        except Exception as e:
            logger.error(f"Mission backup failed: {e}")
            return None
    
    async def upload_file(
        self,
        local_file: str,
        remote_path: str
    ) -> Tuple[bool, str]:
        """
        Upload file to FTP server
        
        Args:
            local_file: Local file path
            remote_path: Remote file path
        
        Returns:
            (success, message)
        """
        if not self.conn:
            return False, "Not connected to FTP"
        
        try:
            local_path = Path(local_file)
            if not local_path.exists():
                return False, f"Local file not found: {local_file}"
            
            file_size = local_path.stat().st_size
            logger.info(f"Uploading {local_file} to {remote_path} ({file_size} bytes)...")
            
            loop = asyncio.get_event_loop()
            
            def _upload():
                with open(local_file, 'rb') as f:
                    self.conn.storbinary(f'STOR {remote_path}', f)
            
            await loop.run_in_executor(None, _upload)
            
            logger.info(f"File uploaded successfully: {remote_path}")
            return True, f"Uploaded {file_size} bytes"
        except Exception as e:
            logger.error(f"Upload failed: {e}")
            return False, str(e)
    
    async def verify_file_hash(
        self,
        remote_path: str,
        expected_hash: str
    ) -> Tuple[bool, str]:
        """
        Download file and verify hash
        
        Args:
            remote_path: Remote file path
            expected_hash: Expected SHA256 hash
        
        Returns:
            (hash_matches, actual_hash)
        """
        if not self.conn:
            return False, "Not connected to FTP"
        
        try:
            loop = asyncio.get_event_loop()
            
            def _download_and_hash():
                file_data = io.BytesIO()
                self.conn.retrbinary(f'RETR {remote_path}', file_data.write)
                file_data.seek(0)
                
                sha256 = hashlib.sha256()
                while True:
                    chunk = file_data.read(8192)
                    if not chunk:
                        break
                    sha256.update(chunk)
                
                return sha256.hexdigest()
            
            actual_hash = await loop.run_in_executor(None, _download_and_hash)
            
            matches = actual_hash.lower() == expected_hash.lower()
            logger.info(f"Hash verification: {actual_hash[:16]}... {'✓' if matches else '✗'}")
            
            return matches, actual_hash
        except Exception as e:
            logger.error(f"Hash verification failed: {e}")
            return False, str(e)
    
    async def list_files(self, remote_path: str) -> list:
        """List files in remote directory"""
        if not self.conn:
            return []
        
        try:
            loop = asyncio.get_event_loop()
            
            def _list():
                return self.conn.listdir(remote_path)
            
            files = await loop.run_in_executor(None, _list)
            return files
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return []
    
    async def file_exists(self, remote_path: str) -> bool:
        """Check if remote file exists"""
        if not self.conn:
            return False
        
        try:
            loop = asyncio.get_event_loop()
            
            def _exists():
                return self.conn.path.isfile(remote_path)
            
            return await loop.run_in_executor(None, _exists)
        except Exception as e:
            logger.debug(f"File check error: {e}")
            return False
    
    async def delete_file(self, remote_path: str) -> bool:
        """Delete remote file"""
        if not self.conn:
            return False
        
        try:
            loop = asyncio.get_event_loop()
            
            def _delete():
                self.conn.remove(remote_path)
            
            await loop.run_in_executor(None, _delete)
            logger.info(f"Deleted: {remote_path}")
            return True
        except Exception as e:
            logger.error(f"Delete failed: {e}")
            return False


class FTPOperationManager:
    """High-level FTP operation manager"""
    
    def __init__(self, ftp_client: FTPClient):
        self.ftp = ftp_client
    
    async def safe_deploy_file(
        self,
        local_file: str,
        remote_path: str,
        backup_first: bool = True,
        verify_after: bool = True
    ) -> Tuple[bool, str]:
        """
        Deploy file with backup and verification
        
        Args:
            local_file: Local file to deploy
            remote_path: Remote destination
            backup_first: Backup existing file first
            verify_after: Verify hash after upload
        
        Returns:
            (success, message)
        """
        # Connect if needed
        if not self.ftp.conn:
            if not await self.ftp.connect():
                return False, "FTP connection failed"
        
        try:
            # Backup existing file
            if backup_first:
                exists = await self.ftp.file_exists(remote_path)
                if exists:
                    backup_path = remote_path + f".backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                    # Note: FTP doesn't have built-in move; use copy approach
                    logger.info(f"Backing up existing file...")
            
            # Upload new file
            success, msg = await self.ftp.upload_file(local_file, remote_path)
            if not success:
                return False, f"Upload failed: {msg}"
            
            # Verify if requested
            if verify_after:
                # Calculate local file hash
                with open(local_file, 'rb') as f:
                    sha256 = hashlib.sha256()
                    while True:
                        chunk = f.read(8192)
                        if not chunk:
                            break
                        sha256.update(chunk)
                    local_hash = sha256.hexdigest()
                
                matches, remote_hash = await self.ftp.verify_file_hash(remote_path, local_hash)
                if not matches:
                    return False, f"Hash mismatch after upload"
            
            return True, "File deployed successfully"
        except Exception as e:
            logger.error(f"Deploy operation failed: {e}")
            return False, str(e)

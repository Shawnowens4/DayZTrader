# 💰 DayZ Trader Bot - Complete Earnings Guide

## Money-Making Opportunities

Players can earn credits through **10+ different activities**. Here's the complete guide:

---

## 1️⃣ Daily Login Bonus

**Command:** `/daily`

**How it works:**
- Claim once per day
- Base reward: **500 credits**
- Streak bonus: +10% per consecutive day (max 7 days = +70%)

**Example:**
- Day 1: 500 credits
- Day 2: 550 credits  
- Day 7: 850 credits

**Resets** if you miss a day.

---

## 2️⃣ Survival Rewards

**How it works:**
- Server tracks in-game survival time
- **100 credits per hour** survived on the server
- Resets on death

**Earning potential:**
- 4-hour survival = 400 credits
- 8-hour survival = 800 credits
- 24-hour survival = 2,400 credits

**Requirements:**
- Admin must enable via `/admin track-survival`
- Survival time must be manually logged by in-game admins

---

## 3️⃣ Achievements

**Command:** `/stats` (view progress)

**Types of Achievements:**
- 🎯 Combat achievements (X kills, combat streaks)
- 🚗 Vehicle achievements (purchase vehicles, customize)
- 📦 Trading achievements (trade volume milestones)
- 🏔️ Survival achievements (extreme survival)
- 💎 Rare achievements (special conditions)

**Reward:** **2,000 credits per achievement**

**Example achievements:**
- "First Blood" - Get 1 kill → 2,000 credits
- "Collector" - Own 5 vehicles → 2,000 credits
- "Wealthy" - Earn 100k total credits → 2,000 credits
- "Iron Skin" - Survive 10+ hours without taking damage → 2,000 credits

---

## 4️⃣ Gambling (High Risk/Reward)

**Commands:**
```
/gamble coinflip <amount> <choice>
/gamble dice <amount> <prediction>
```

### Coin Flip
- Choose: **Heads or Tails**
- Win odds: **50%**
- Payout: **2x your bet**

**Example:**
```
/gamble coinflip 500 heads
✅ You won! Heads it is! +1,000 credits
```

### Dice Roll
- Predict: **1-6**
- Win odds: **16.67%**
- Payout: **5x your bet** (high risk/reward)

**Example:**
```
/gamble dice 200 4
🎲 You rolled 4! You won 1,000 credits!
```

**⚠️ WARNING:** Gambling can result in losses. Set personal limits!

---

## 5️⃣ Bounties System

**Commands:**
```
/bounty place <target> <amount> <reason>
/bounty check
```

### Place a Bounty
- Put a price on another player's head
- **Costs you:** The bounty amount
- **Requires:** Sufficient balance
- **Expires:** After 30 days or when claimed

**Example:**
```
/bounty place "PlayerName" 5000 "Killed me too many times"
💸 Bounty of 5,000 placed on PlayerName
```

### Claim a Bounty
- Hunt the targeted player
- Kill them or convince them to come collect their bounty
- **Earn:** Full bounty amount

**Example:**
```
PlayerName was eliminated
🎯 Bounty claimed! You earned 5,000 credits!
```

**Bounty Board:**
- View all active bounties
- See rewards and reasons
- Hunt targets or negotiate

---

## 6️⃣ Missions System

**Command:** `/missions`

**Mission Types:**
- 🟢 **Easy** - 1,000-2,000 credits (simple objectives)
- 🟡 **Medium** - 3,000-5,000 credits (moderate challenge)
- 🔴 **Hard** - 7,000-10,000 credits (difficult objectives)

**Example Missions:**
- "Scavenger" - Loot 10 items → 1,500 credits
- "Trader" - Complete 3 trades → 2,500 credits
- "Survivor" - Stay alive 4 hours without dying → 5,000 credits
- "Hunter" - Get 5 kills → 7,500 credits
- "Wealthy" - Earn 50k total → 10,000 credits

**How to complete:**
1. View `/missions`
2. Read objective
3. Complete requirement in-game
4. Admin verifies completion
5. Claim reward automatically

---

## 7️⃣ Player-to-Player Trading

**Commands:**
```
/marketplace list <item> <quantity> <price>
/marketplace buy <listing_id>
/marketplace sell <item> <quantity> <total_price>
```

### Marketplace Listing
- Sell items to other players
- Set your own prices
- Listings last **30 days**
- No tax/fees from bot

**Example:**
```
/marketplace list "M4A1" 1 50000
📤 Listed: 1x M4A1 for 50,000 credits
```

### Browse & Buy
```
/marketplace browse
```
- See all player listings
- Make offers
- Negotiate prices

**Earning potential:** Unlimited (depends on items sold)

---

## 8️⃣ Clan/Group Bonuses

**Commands:**
```
/clan create <clan_name>
/clan join <clan_name>
/clan leave
```

**Clan Benefits:**
- Pool resources
- Shared bounties
- Group missions
- **Clan treasury** (shared funds)
- Rank bonuses (leader 10%, officer 5%, member 2%)

**Group earnings:**
- Combined bounties split among members
- Clan-wide missions worth more
- Shared marketplace discounts

---

## 9️⃣ Seasonal Battle Pass

**How it works:**
- Each season lasts **4 weeks**
- Complete challenges to gain XP
- Gain levels and unlock rewards
- Rewards include credits, items, cosmetics

**Example Season Rewards:**
- Level 5: 2,000 credits
- Level 10: 5,000 credits
- Level 25: 15,000 credits
- Level 50: 50,000 credits

**Total potential:** **100,000+ credits per season**

---

## 🔟 Weekly Challenges

**Command:** `/challenges`

**New challenges every Monday:**

| Challenge | Objective | Reward |
|-----------|-----------|--------|
| Weapons Master | Get 10 kills | 5,000 credits |
| Trader | Complete 5 trades | 4,000 credits |
| Survivalist | Stay alive 12 hours | 6,000 credits |
| Rich | Earn 50k in trades | 7,500 credits |
| Collector | Purchase 3 vehicles | 8,000 credits |

**Total per week:** **30,500 credits** (if all completed)

---

## 1️⃣1️⃣ Leaderboards & Prestige

**Command:** `/leaderboard`

**Rankings:**
1. **Top Earner** - Most total credits earned
2. **Most Trades** - Most transactions completed
3. **Best Hunter** - Most bounties claimed
4. **Richest Player** - Highest current balance

**Rewards for Top 10:**
- Monthly rewards for #1 ($$$)
- Special title/badge in Discord
- Recognition in server

---

## 💡 Money-Making Strategies

### Conservative (Safe, Steady)
```
Daily: /daily = +500-850/day
Missions: 3x missions/week = +12,000/week
Survival: 4hrs/day = +400/day
TOTAL: ~15,000/week
```

### Moderate (Balanced)
```
Daily: +500-850/day
Missions: +12,000/week
Trading: +10,000/week (reselling items)
Survival: +400/day
TOTAL: ~30,000/week
```

### Aggressive (High Risk/Reward)
```
Daily: +500-850/day
Gambling: ±2,000/day (volatile!)
Bounties: +20,000/week (if successful)
Trading: +15,000/week
Missions: +12,000/week
TOTAL: ~50,000+/week (or negative!)
```

---

## 📊 Earning Potential (Per Week)

| Activity | Min | Max | Avg |
|----------|-----|-----|-----|
| Daily login | 3,500 | 5,950 | 4,725 |
| Missions | 1,000 | 15,000 | 8,000 |
| Survival | 0 | 14,000 | 7,000 |
| Bounties | 0 | 30,000 | 5,000 |
| Trading | 0 | 50,000 | 10,000 |
| Challenges | 0 | 30,500 | 15,250 |
| Gambling | -∞ | +∞ | 0 |
| Battle Pass | 0 | 25,000 | 12,500 |
| **TOTAL** | **4,500** | **170,450** | **62,475** |

---

## ⚙️ Admin Configuration

Edit `config/settings.yaml`:

```yaml
economy:
  # Daily rewards
  daily_reward: 500
  daily_streak_bonus: 0.10  # 10% per day
  
  # Survival
  survival_hours_rate: 100  # credits per hour
  
  # Achievements
  achievement_reward: 2000
  
  # Missions
  mission_reward_easy: 1000
  mission_reward_medium: 5000
  mission_reward_hard: 10000
  
  # Gambling
  gambling_enabled: true
  coinflip_payout: 2.0
  dice_payout: 5.0
  max_bet: 10000
  
  # Bounties
  bounty_enabled: true
  bounty_expiry_days: 30
  
  # Trading
  marketplace_enabled: true
  marketplace_tax_percent: 5
  marketplace_listing_days: 30
  
  # Clans
  clan_enabled: true
  clan_rank_bonus:
    leader: 0.10
    officer: 0.05
    member: 0.02
```

---

## 🎯 Tips for Maximum Earnings

1. **Be consistent** - Daily login bonus adds up
2. **Complete challenges** - Weekly challenges worth 30k+
3. **Hunt bounties** - High reward for successful hunts
4. **Trade wisely** - Buy low, sell high on marketplace
5. **Join a clan** - Group bonuses multiply earnings
6. **Gamble smart** - Don't bet more than you can afford to lose
7. **Track missions** - They renew frequently
8. **Compete** - Top leaderboard earners get monthly rewards
9. **Mix activities** - Don't rely on single income stream
10. **Invest in vehicles** - They can earn rental income

---

## 💸 Earning Tiers

| Tier | Weekly Earnings | Vehicle Access |
|------|-----------------|-----------------|
| Starter | 5,000-10,000 | Basic (Hatchback) |
| Regular | 10,000-30,000 | Standard (Sedan, Truck) |
| Veteran | 30,000-60,000 | Premium (All vehicles) |
| Elite | 60,000+/week | Exclusive + Clan Benefits |

---

## ⚠️ Important Notes

- **Gambling** is high-risk and can result in losses
- **Bounties** may be contested or fail
- **Missions** require admin verification
- **Trading** prices are player-set (watch for scams)
- **Balance reset** only occurs on admin command
- **Achievements** unlock once per account
- **Seasonal rewards** end when season ends
- **All earnings logged** for auditing/disputes

---

## Support & Questions

If you have questions about earnings:
- Ask in #trading channel
- Check `/stats` for detailed tracking
- View `/leaderboard` for top strategies
- Contact admins for mission/achievement verification

**Happy earning! 💎**

# DayZ Console Trader Bot - Quick Start Guide

Get your trader bot running in 10 minutes!

## Prerequisites

- Python 3.11+
- Discord server with admin role
- Nitrado Xbox/PS DayZ server (1.29.1+)
- FTP credentials from Nitrado

## Step 1: Clone & Install (2 minutes)

```bash
# Clone repository
git clone <repo-url> dayz-trader
cd dayz-trader

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Step 2: Configure (3 minutes)

```bash
# Copy template
cp .env.example .env

# Edit with your values (use any text editor)
# CRITICAL FIELDS:
# - DISCORD_TOKEN (from Discord Developer Portal)
# - DISCORD_GUILD_ID (your server ID)
# - NITRADO_TOKEN (from Nitrado account)
# - NITRADO_SERVICE_ID (your service ID)
# - FTP_HOST, FTP_USER, FTP_PASS (Nitrado FTP)
# - FTP_MISSION_PATH (/dayzxb_mission/dayzoffline.chernarusplus or /dayzps_mission/...)
```

## Step 3: Setup Database (2 minutes)

```bash
# Initialize database
python scripts/setup.py

# This will:
# - Create folders (data, logs, config)
# - Initialize SQLite database
# - Validate configuration
```

## Step 4: Populate Vehicles & Items (2 minutes)

### Option A: Use Provided Defaults
The config files already have example vehicles and items. You can use these as-is or modify them.

### Option B: Extract from Your Mission
```bash
# This extracts item classnames from your mission's types.xml
python scripts/seed_console_items.py --mission-path /path/to/mission/folder
```

## Step 5: Start the Bot (1 minute)

```bash
python bot/main.py
```

You should see:
```
Bot logged in as YourBotName (ID: 123456789)
Connected to FTP: ftp.nitrado.net
Web server on 127.0.0.1:8788
Trader cog loaded
Admin cog loaded
```

## Step 6: Test in Discord

In your Discord server, try:

```
/shop
/balance
/admin help
```

You should see responses with vehicle/item listings.

---

## Common Tasks

### Add a New Vehicle

1. **Edit `config/vehicle_defs.json`**:

```json
{
  "vehicles": [
    {
      "classname": "OffroadHatchback",
      "display": "Offroad Hatchback",
      "price_buy": 5000,
      "price_rent_hour": 250,
      "cargo_capacity": 70,
      "enabled": true
    }
  ]
}
```

2. **Reload config** in Discord:
```
/admin reload_config
```

### Set Vehicle Price

```
/admin set-price OffroadHatchback 3000
```

### Give Player Balance

```
/admin give_balance @PlayerName 10000
```

### View Spawn Logs

Check database:
```bash
sqlite3 data/trader.db "SELECT * FROM orders LIMIT 10;"
```

Or check `logs/trader.log` file.

---

## Troubleshooting

### Bot Won't Start

**Error: `DISCORD_TOKEN not set`**
- Edit `.env` and add your bot token
- Make sure `.env` is in the project root folder

**Error: `Database initialization failed`**
```bash
# Reset database
rm data/trader.db
sqlite3 data/trader.db < data/schema.sql
```

### FTP Connection Failed

**Error: `FTP connection failed`**
- Verify FTP credentials in `.env`
- Test FTP manually: `ftp ftp.nitrado.net`
- Confirm FTP port (usually 21)

### Vehicles Don't Spawn

**Nothing appears in game**
1. Check `spawn_log` table in database
2. Verify classnames in `config/vehicle_defs.json` exist in your mission
3. Check FTP uploaded files successfully
4. Look for XML errors in logs

```bash
# View recent errors
tail -n 50 logs/trader.log | grep -i error
```

---

## Admin Cheat Sheet

```bash
# Check bot status
curl http://127.0.0.1:8788/health

# View all users
sqlite3 data/trader.db "SELECT discord_id, balance FROM users LIMIT 20;"

# View recent orders
sqlite3 data/trader.db "SELECT * FROM orders WHERE created_at > datetime('now', '-1 hour');"

# View spawn errors
sqlite3 data/trader.db "SELECT * FROM spawn_log WHERE success = 0 LIMIT 5;"

# Reset player balance
sqlite3 data/trader.db "UPDATE users SET balance = 1000 WHERE discord_id = 123456;"

# Reload configs
# (In Discord) /admin reload_config

# Check logs
tail -f logs/trader.log
```

---

## Next Steps

1. **Customize vehicle prices** in `config/vehicle_defs.json`
2. **Enable/disable items** in `config/console_items.json`
3. **Set up safe zones** in `config/spawn_zones.json` (optional)
4. **Test a live spawn** with yourself as a player
5. **Monitor logs** for issues and player feedback

---

## Map Coordinate Selection

Players use the Leaflet map at `/map` to pick spawn locations:

1. Bot sends map link via DM
2. Player clicks on map to select location
3. Coordinates are saved to order
4. Vehicle spawns at selected location in-game

**Safe zones** (green circles) and **blacklist zones** (red circles) can be configured in `config/spawn_zones.json`.

---

## Database Structure Quick Reference

| Table | Purpose |
|-------|---------|
| `users` | Player accounts & balances |
| `catalog_vehicles` | Available vehicles for purchase/rental |
| `catalog_items` | Available cargo items |
| `orders` | Buy/rent transactions |
| `rentals` | Track active rentals |
| `spawn_log` | Audit trail of FTP deployments |

---

## Console Safety Checklist

Before enabling traders for players:

- [ ] All vehicle classnames verified in your mission's `types.xml`
- [ ] All item classnames verified in your mission's `types.xml`
- [ ] No PC-only mods in item list
- [ ] Tested a manual spawn with `/admin force_deploy`
- [ ] Verified spawn appears in-game
- [ ] Tested rental expiry notifications
- [ ] Backup mission folder before first deploy
- [ ] Admin has tested `/admin help` commands

---

## Performance Tips

- **Batch spawns**: Group multiple orders before deploying
- **FTP backups**: Retained for 7 days by default
- **Database**: Regularly prune old orders (older than 30 days)
- **Logs**: Rotate logs monthly to keep file size down

```bash
# Archive logs monthly
cd logs && tar -czf logs_$(date +%Y%m%d).tar.gz trader.log && > trader.log
```

---

## Getting Help

1. Check `logs/trader.log` for errors
2. Review database with `sqlite3 data/trader.db`
3. Test FTP manually with `ftp` command
4. Verify Discord permissions with role checks
5. Check bot has correct intents enabled

---

## What's Next?

- Deploy to production (see DEPLOYMENT.md)
- Set up map tile server (if using local tiles)
- Configure advanced rules (see config/nesting_rules.json)
- Set up CI/CD for automatic backups
- Monitor Nitrado API rate limits

Good luck! 🚗💰

# Pre-Deployment Checklist

Complete this checklist before launching your trader bot to players.

## ✅ Pre-Flight Checks

### Environment Setup
- [ ] Python 3.11+ installed
- [ ] Virtual environment created and activated
- [ ] All dependencies installed: `pip install -r requirements.txt`
- [ ] `.env` file created with all required values
- [ ] `.env` not committed to git (check `.gitignore`)

### Discord Setup
- [ ] Discord bot created in Developer Portal
- [ ] Bot token copied to `.env` as `DISCORD_TOKEN`
- [ ] Bot invited to test server
- [ ] Bot has necessary permissions (Send Messages, Embed Links, etc.)
- [ ] Admin role created in Discord
- [ ] Admin role ID added to `.env` as `ADMIN_ROLE_IDS`
- [ ] Guild/server ID added to `.env` as `DISCORD_GUILD_ID`

### Nitrado Setup
- [ ] Nitrado API token obtained
- [ ] Service ID obtained
- [ ] FTP credentials obtained
- [ ] Mission path identified and verified:
  - [ ] Xbox: `/dayzxb_mission/dayzoffline.chernarusplus/`
  - [ ] PlayStation: `/dayzps_mission/dayzoffline.chernarusplus/`
- [ ] Mission backed up before any modifications

### Configuration
- [ ] `config/settings.yaml` reviewed
- [ ] `config/vehicle_defs.json` populated with your vehicles
- [ ] `config/console_items.json` verified against your mission
- [ ] All classnames exist in your mission's `types.xml`
- [ ] `config/nesting_rules.json` reviewed for accuracy

## 🗄️ Database & Setup

### Database
- [ ] Setup script run: `python scripts/setup.py`
- [ ] Database created: `data/trader.db` exists
- [ ] Database tables verified:
  ```bash
  sqlite3 data/trader.db "SELECT COUNT(*) FROM users;"
  # Should return 0 (empty)
  ```
- [ ] Schema matches `data/schema.sql`

### Initial Data
- [ ] At least 2 vehicles enabled in database
- [ ] At least 5 items enabled in database
- [ ] Admin has been given starting balance (for testing)
- [ ] Starting balances set correctly for new players

## 🧪 Testing

### Local Testing
- [ ] Bot starts without errors: `python bot/main.py`
- [ ] Bot successfully logs in to Discord
- [ ] Bot connects to FTP server
- [ ] Web server starts on configured port
- [ ] Logs show no warnings/errors

### Discord Command Testing
- [ ] `/shop` returns vehicle/item list
- [ ] `/balance` works with test user
- [ ] `/admin help` accessible to admin
- [ ] `/admin reload_config` works
- [ ] All commands have proper error handling

### Web UI Testing
- [ ] Map loads at `/map` endpoint
- [ ] Map shows Chernarus correctly
- [ ] Clicking map records coordinates
- [ ] Vehicle builder page loads
- [ ] Trunk builder page loads
- [ ] `/api/vehicles` returns JSON
- [ ] `/api/items` returns JSON
- [ ] `/api/health` returns status

### Validation Testing
- [ ] `python scripts/validate_xml.py` passes
- [ ] Sample XML validates against mission
- [ ] Classname checks work correctly
- [ ] Nesting rules properly enforced

### FTP Testing
- [ ] FTP connection succeeds
- [ ] Mission file can be downloaded
- [ ] Test file can be uploaded
- [ ] File hash verification works
- [ ] Backup folder created

### Manual Spawn Test
- [ ] Create test order in database
- [ ] Generate test XML
- [ ] Upload XML to mission folder via FTP
- [ ] Verify file on server
- [ ] Restart server
- [ ] Join server and verify vehicle spawns
- [ ] Check spawn_log table for success

## 🔐 Security

### Credentials
- [ ] No credentials in code or git
- [ ] `.env` is in `.gitignore`
- [ ] `.env` permissions restricted (chmod 600 on Linux)
- [ ] Nitrado token never logged or exposed
- [ ] FTP password never logged or exposed

### Access Control
- [ ] Admin role properly restricted in Discord
- [ ] Map tokens expire after 5 minutes
- [ ] Session tokens validated
- [ ] Balance operations logged
- [ ] Admin actions logged
- [ ] Order history preserved

### Data Validation
- [ ] Classnames validated against allowlist
- [ ] Cargo slot limits enforced
- [ ] Nesting depth limits enforced
- [ ] Coordinate bounds checked
- [ ] User input sanitized

## 📊 Monitoring Setup

### Logging
- [ ] Log level set to INFO (or DEBUG for troubleshooting)
- [ ] `logs/` directory exists
- [ ] Log rotation configured
- [ ] Logs not committed to git

### Database Monitoring
- [ ] Backup strategy in place
- [ ] Old orders/data cleanup scheduled
- [ ] Database size monitored
- [ ] Permissions audit trail enabled

### Discord Monitoring
- [ ] Admin alert channel configured (optional)
- [ ] Error notifications enabled
- [ ] High-volume spawn alerts enabled

## 🚀 Deployment Preparation

### Backup & Recovery
- [ ] Mission folder backed up
- [ ] Database backed up
- [ ] `.env` backed up (securely)
- [ ] Restore procedure documented
- [ ] Rollback plan ready

### Documentation
- [ ] Admin manual written
- [ ] Player guide distributed
- [ ] Troubleshooting guide ready
- [ ] Contact info for support provided

### Communication
- [ ] Players notified of trader launch
- [ ] Welcome message prepared
- [ ] Instructions posted in Discord
- [ ] Expected behavior documented
- [ ] Support channel created

## 🎯 Launch Day

### Pre-Launch (1 hour before)
- [ ] FTP tested one more time
- [ ] Discord bot online and responding
- [ ] Database backed up
- [ ] Logs cleared/rotated
- [ ] All admins briefed and ready

### Post-Launch (first hour)
- [ ] Monitor logs for errors
- [ ] Watch `/shop` command responses
- [ ] Verify player balance updates
- [ ] Test rental expiry notification
- [ ] Check admin commands work

### Ongoing (first week)
- [ ] Monitor FTP operations
- [ ] Check database growth
- [ ] Review player feedback
- [ ] Fix any discovered issues
- [ ] Adjust prices if needed

## 📋 During Operation

### Weekly Tasks
- [ ] Review `spawn_log` for errors
- [ ] Check FTP backup folder size
- [ ] Monitor database size
- [ ] Review admin logs
- [ ] Check player balance distributions

### Monthly Tasks
- [ ] Archive old spawn logs
- [ ] Prune database (delete old orders)
- [ ] Verify all classnames still valid
- [ ] Test restore from backup
- [ ] Review and update prices

### As Needed
- [ ] Add new vehicles to catalog
- [ ] Enable/disable items
- [ ] Reset player balances
- [ ] Handle disputes/refunds
- [ ] Update mission files

## 🐛 Troubleshooting Checklist

If something goes wrong:

- [ ] Check `logs/trader.log` for errors
- [ ] Verify FTP connection: `ftp ftp.nitrado.net`
- [ ] Check database: `sqlite3 data/trader.db ".tables"`
- [ ] Test Discord bot commands manually
- [ ] Verify classnames in mission
- [ ] Check coordinate system conversion
- [ ] Review recent admin actions
- [ ] Look for spawn errors in `spawn_log`
- [ ] Validate recent XML files
- [ ] Check Nitrado API status

## ✨ Final Sign-Off

Before going live with players:

- [ ] All checklist items completed
- [ ] Tech lead sign-off obtained
- [ ] Admin team trained
- [ ] Player expectations set
- [ ] Support plan ready
- [ ] Backup restored and verified
- [ ] Test spawn successful in-game
- [ ] Documentation reviewed
- [ ] Disaster recovery tested

---

## Deployment Options

### Option 1: VPS/Dedicated Server
- [ ] Server rented/provisioned
- [ ] SSH access verified
- [ ] Python 3.11+ installed
- [ ] systemd service created
- [ ] Reverse proxy configured (nginx/Apache)
- [ ] HTTPS certificate installed
- [ ] Firewall rules set
- [ ] Domain DNS updated

### Option 2: Docker
- [ ] Docker installed on host
- [ ] Dockerfile tested and builds
- [ ] Docker compose configured (if using)
- [ ] Volume mounts for data persistence
- [ ] Environment variables configured
- [ ] Port mappings correct
- [ ] Network connectivity tested

### Option 3: Cloudflare Tunnel
- [ ] Cloudflare account created
- [ ] Tunnel installed and authenticated
- [ ] Domain delegated to Cloudflare
- [ ] Tunnel config created
- [ ] Local bot port accessible to tunnel
- [ ] No firewall blocking

---

## Success Criteria

Your deployment is successful when:

✅ Players can see `/shop` command  
✅ Players can check `/balance`  
✅ Admin can use `/admin help`  
✅ Map loads and allows coordinate selection  
✅ Test spawn creates vehicle in-game  
✅ Logs show no errors after 1 hour  
✅ Database records transactions correctly  
✅ FTP backups created automatically  
✅ Rentals track expiry correctly  
✅ Admin gets notified of errors  

---

**Date Completed**: _______________  
**Approved By**: _______________  
**Notes**: _______________________________________________

Ready to deploy! 🚀

# DayZ Console Trader Bot - Deployment Guide

Complete setup instructions for deploying on Xbox/PlayStation Nitrado servers (1.29.1+).

## Table of Contents

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Discord Setup](#discord-setup)
3. [Nitrado Configuration](#nitrado-configuration)
4. [Local Environment](#local-environment)
5. [Configuration Files](#configuration-files)
6. [Database Initialization](#database-initialization)
7. [Testing](#testing)
8. [Production Deployment](#production-deployment)
9. [Troubleshooting](#troubleshooting)

---

## Pre-Deployment Checklist

- [ ] Python 3.11+ installed
- [ ] Discord server created with bot role
- [ ] Nitrado Xbox or PS DayZ server rented
- [ ] FTP credentials for Nitrado server
- [ ] Mission folder backed up
- [ ] Chernarus map tiles available (local or CDN)
- [ ] Admin identified for bot permissions
- [ ] Currency system defined (points, in-game credits, etc.)

---

## Discord Setup

### 1. Create Discord Application

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application"
3. Name it "DayZ Trader Bot"
4. Accept ToS

### 2. Create Bot User

1. Go to "Bot" section
2. Click "Add Bot"
3. Under "TOKEN", click "Copy" and save somewhere safe
4. In your `.env`: `DISCORD_TOKEN=your_token_here`

### 3. Configure Bot Permissions

1. Go to "OAuth2" → "URL Generator"
2. Select scopes:
   - `bot`
   - `applications.commands`
3. Select permissions:
   - Send Messages
   - Create Public Threads
   - Read Messages/View Channels
   - Embed Links
   - Read Message History
   - Mention @everyone, @here, and All Roles
4. Copy generated URL and open in browser to invite bot to your server

### 4. Create Admin Role

1. In Discord server, create role "Trader Admin"
2. Get the role ID (right-click → Copy User ID, enable Developer Mode first)
3. In `.env`: `ADMIN_ROLE_IDS=your_role_id`

### 5. Get Guild/Server ID

1. Right-click server name (Developer Mode enabled)
2. Copy Server ID
3. In `.env`: `DISCORD_GUILD_ID=your_server_id`

---

## Nitrado Configuration

### 1. Get API Token

1. Log in to [Nitrado account](https://nitrado.net)
2. Go to Settings → API (or Account → Developer Settings)
3. Create or copy Long-Life API Token
4. In `.env`: `NITRADO_TOKEN=your_api_token`
5. Copy your Service ID (visible in dashboard)
6. In `.env`: `NITRADO_SERVICE_ID=your_service_id`

### 2. FTP Setup

1. In Nitrado Dashboard, get FTP credentials:
   - FTP Host (usually `ftp.nitrado.net`)
   - FTP Username
   - FTP Password
   - FTP Port (usually 21 for standard, sometimes 3021 for FTPS)

2. In `.env`:
```
FTP_HOST=ftp.nitrado.net
FTP_USER=your_ftp_user
FTP_PASS=your_ftp_password
FTP_PORT=21
FTP_USE_FTPS=true
```

3. Verify mission folder path:
   - Xbox: `/dayzxb_mission/dayzoffline.chernarusplus/`
   - PlayStation: `/dayzps_mission/dayzoffline.chernarusplus/`

4. In `.env`: `FTP_MISSION_PATH=/dayzxb_mission/dayzoffline.chernarusplus`

---

## Local Environment

### 1. Clone Repository

```bash
git clone <repo-url> dayz-console-trader-bot
cd dayz-console-trader-bot
```

### 2. Create Virtual Environment

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

### 3. Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Create `.env` File

```bash
cp .env.example .env
# Edit .env with your values
```

**Critical `.env` values:**
```env
DISCORD_TOKEN=your_bot_token
DISCORD_GUILD_ID=your_server_id
ADMIN_ROLE_IDS=your_admin_role_ids

NITRADO_TOKEN=your_nitrado_token
NITRADO_SERVICE_ID=your_service_id

FTP_HOST=ftp.nitrado.net
FTP_USER=your_ftp_user
FTP_PASS=your_ftp_password
FTP_PORT=21
FTP_MISSION_PATH=/dayzxb_mission/dayzoffline.chernarusplus

DATABASE_URL=sqlite+aiosqlite:///./data/trader.db

WEB_HOST=127.0.0.1
WEB_PORT=8788
WEB_SECRET=your_secure_random_string

MAP_TILE_URL=https://your-cdn/tiles/chernarus/{z}/{x}/{y}.png

CURRENCY_NAME=Rubles
DEFAULT_BALANCE=1000
```

---

## Configuration Files

### 1. Export Console Items (CRITICAL!)

Export your mission's `types.xml` item classnames:

```bash
python scripts/seed_console_items.py
# This will create console_items.json from your mission
```

Or manually add items from your mission to `config/console_items.json`:

```json
{
  "items": [
    {
      "classname": "M4A1",
      "display": "M4A1 Rifle",
      "category": "weapon",
      "slots": 14,
      "is_weapon": true,
      "enabled": true
    }
  ]
}
```

**IMPORTANT:** Do NOT add PC-only mods. Stick to vanilla console classnames only.

### 2. Configure Vehicles

Edit `config/vehicle_defs.json`:

```json
{
  "vehicles": [
    {
      "classname": "OffroadHatchback",
      "display": "Offroad Hatchback",
      "price_buy": 5000,
      "price_rent_hour": 250,
      "cargo_capacity": 70,
      "enabled": true,
      "parts": { ... },
      "run_parts": [ ... ]
    }
  ]
}
```

### 3. Configure Nesting Rules

Edit `config/nesting_rules.json` for container depth/slot limits:

```json
{
  "max_nesting_depth": 2,
  "container_rules": {
    "TacticalBag": {
      "max_slots": 50,
      "accepts_weapons": true,
      "accepts_ammunition": true
    }
  }
}
```

### 4. Configure Bot Settings

Edit `config/settings.yaml`:

- `discord.activity` — Bot status message
- `trader.enabled` — Enable/disable trading
- `economy.starting_balance` — New player balance
- `ftp.backup_retention_days` — How long to keep FTP backups
- `logging.level` — DEBUG, INFO, WARNING, ERROR

---

## Database Initialization

### 1. Create Database Schema

```bash
mkdir -p data
sqlite3 data/trader.db < data/schema.sql
```

### 2. Verify Connection

```bash
sqlite3 data/trader.db "SELECT COUNT(*) FROM users;"
# Should return 0 (empty table)
```

---

## Testing

### 1. Test Bot Locally

```bash
python bot/main.py
```

Watch for:
- `Bot logged in as YourBotName (ID: ...)`
- `Connected to FTP: ftp.nitrado.net`
- `Web server on 127.0.0.1:8788`

### 2. Test Discord Commands

In Discord, try:
- `/shop` — Should show available vehicles
- `/balance` — Should show your balance

### 3. Test FTP Connection

The bot will automatically test FTP when it starts. Check logs for success/failure.

### 4. Test Map

Open browser to `http://localhost:8788/map` and verify Leaflet map loads.

### 5. Manual Spawn Test

1. Create a simple test order
2. Verify XML is generated in logs
3. Confirm file uploaded to FTP (check backups folder)

---

## Production Deployment

### Option 1: Self-Hosted (VPS/Dedicated Server)

1. **Install on VPS**
   ```bash
   ssh user@your-vps.com
   git clone <repo> /opt/dayz-trader
   cd /opt/dayz-trader
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

2. **Create systemd Service** (`/etc/systemd/system/dayz-trader.service`):
   ```ini
   [Unit]
   Description=DayZ Console Trader Bot
   After=network.target
   
   [Service]
   Type=simple
   User=dayz
   WorkingDirectory=/opt/dayz-trader
   EnvironmentFile=/opt/dayz-trader/.env
   ExecStart=/opt/dayz-trader/venv/bin/python bot/main.py
   Restart=always
   RestartSec=10
   
   [Install]
   WantedBy=multi-user.target
   ```

3. **Start Service**
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl start dayz-trader
   sudo systemctl enable dayz-trader
   ```

4. **Set Up Reverse Proxy** (Nginx):
   ```nginx
   server {
       listen 80;
       server_name trader.yourdomain.com;
       
       location / {
           proxy_pass http://127.0.0.1:8788;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```

### Option 2: Docker (Recommended)

Create `Dockerfile`:

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "bot/main.py"]
```

Build and run:
```bash
docker build -t dayz-trader .
docker run -d \
    --name dayz-trader \
    --env-file .env \
    -v $(pwd)/data:/app/data \
    -v $(pwd)/logs:/app/logs \
    -p 8788:8788 \
    dayz-trader
```

### Option 3: Cloudflare Tunnel (Simple & Secure)

```bash
# Install Cloudflare Tunnel
curl -L --output cloudflared.deb https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
sudo dpkg -i cloudflared.deb

# Authenticate
cloudflared tunnel login

# Create tunnel
cloudflared tunnel create dayz-trader
cloudflared tunnel route dns dayz-trader trader.yourdomain.com

# Configure ingress
echo '
ingress:
  - hostname: trader.yourdomain.com
    service: http://127.0.0.1:8788
  - service: http_status:404
' > ~/.cloudflared/config.yml

# Start
cloudflared tunnel run dayz-trader
```

---

## Troubleshooting

### Bot Won't Start

**Error: `DISCORD_TOKEN not set`**
- Check `.env` file exists and has `DISCORD_TOKEN=...`
- Make sure it's in the project root

**Error: `Database initialization failed`**
- Check `data/` folder exists: `mkdir -p data`
- Verify SQLite installed: `python -c "import sqlite3"`
- Try: `rm data/trader.db && sqlite3 data/trader.db < data/schema.sql`

### FTP Connection Failed

**Error: `FTP connection failed`**
- Verify credentials in `.env`
- Test manually: `ftp ftp.nitrado.net` (use FTP_USER/FTP_PASS)
- Check FTP host is correct (usually `ftp.nitrado.net`)
- Verify FTP port (21 for standard, 3021 for FTPS)

### Vehicles Won't Spawn

**No vehicles in game**
1. Check `config/vehicle_defs.json` has vehicles with `"enabled": true`
2. Verify classnames match your mission's `types.xml`
3. Check FTP logs: spawn XML should show in spawn_log table
4. Manually inspect uploaded XML on mission server via FTP

**XML validation errors**
1. Check logs for XML errors
2. Run: `python scripts/validate_xml.py`
3. Verify all classnames exist in mission types.xml

### Map Not Loading

**Leaflet error in browser console**
1. Check `MAP_TILE_URL` is valid and accessible
2. Verify CORS if using external tiles
3. Try local tiles: `/static/tiles/{z}/{x}/{y}.png`

---

## First Run Checklist

- [ ] Bot joins Discord server
- [ ] `/shop` command works
- [ ] Admin can use `/admin reload_config`
- [ ] Player can view `/balance`
- [ ] Map loads at `/map`
- [ ] FTP connection succeeds in logs
- [ ] Database tables created
- [ ] No errors in `logs/trader.log`
- [ ] At least 2 vehicles enabled in `vehicle_defs.json`
- [ ] At least 5 items enabled in `console_items.json`

Once all checks pass, you're ready for players!

---

## Maintenance

### Weekly

- Monitor `logs/trader.log` for errors
- Check FTP backup folder size (cleanup if needed)
- Verify player balances reasonable
- Review admin actions in database

### Monthly

- Update vehicle/item prices if needed
- Audit enabled classnames against current mission
- Review and archive old spawn logs
- Test emergency restore from backups

### On Server Update (1.29.1 → future version)

1. Export new `types.xml` from mission
2. Re-run `seed_console_items.py`
3. Update classnames in `config/`
4. Restart bot
5. Test spawn with new classnames

---

## Support & Debugging

Enable debug logging in `.env`:
```env
LOG_LEVEL=DEBUG
```

Then check `logs/trader.log` for detailed output.

For Discord bot debugging, enable message intents in `bot/main.py` and check for API errors.

For FTP issues, test connection manually:
```bash
python -c "
import ftputil
conn = ftputil.FTPHost('ftp.nitrado.net', 'user', 'pass')
print('Connected:', conn.listdir('/'))
conn.close()
"
```

---

**Last Updated:** January 2024
**Version:** 1.0.0
**Compatibility:** DayZ Console 1.29.1+ (Xbox/PS)

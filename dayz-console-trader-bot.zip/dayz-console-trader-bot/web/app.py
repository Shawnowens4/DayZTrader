"""
FastAPI web application
Admin UI, Leaflet map, vehicle/trunk builders, API endpoints
"""

import os
import secrets
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from loguru import logger

# Web app factory
def create_app(bot) -> FastAPI:
    """Create FastAPI application"""
    
    app = FastAPI(
        title="DayZ Console Trader Bot",
        description="Admin UI for DayZ trader",
        version="1.0.0"
    )
    
    # Store bot reference
    app.bot = bot
    
    # CORS middleware (optional)
    # Enable if needed for cross-origin requests
    # from fastapi.middleware.cors import CORSMiddleware
    # app.add_middleware(CORSMiddleware, allow_origins=["*"])
    
    # Mount static files
    static_path = os.path.join(os.path.dirname(__file__), "static")
    if os.path.exists(static_path):
        app.mount("/static", StaticFiles(directory=static_path), name="static")
    
    # Session management
    active_tokens: Dict[str, Dict[str, Any]] = {}
    
    def verify_token(token: Optional[str] = None) -> Dict[str, Any]:
        """Verify authentication token"""
        if not token:
            raise HTTPException(status_code=401, detail="Missing token")
        
        if token not in active_tokens:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        session = active_tokens[token]
        if session["expires"] < datetime.now():
            del active_tokens[token]
            raise HTTPException(status_code=401, detail="Token expired")
        
        return session
    
    # Root endpoint
    @app.get("/", response_class=HTMLResponse)
    async def root():
        """Root page - redirect to map"""
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>DayZ Trader</title>
            <meta http-equiv="refresh" content="0; url=/map">
        </head>
        <body>Redirecting...</body>
        </html>
        """
    
    # Map endpoint
    @app.get("/map", response_class=HTMLResponse)
    async def map_page(token: Optional[str] = None):
        """Leaflet map for spawn selection"""
        
        # Generate temporary token if not provided
        if not token:
            token = secrets.token_urlsafe(32)
            active_tokens[token] = {
                "expires": datetime.now() + timedelta(minutes=5),
                "created_at": datetime.now(),
                "type": "map"
            }
        else:
            try:
                verify_token(token)
            except HTTPException:
                token = secrets.token_urlsafe(32)
                active_tokens[token] = {
                    "expires": datetime.now() + timedelta(minutes=5),
                    "created_at": datetime.now(),
                    "type": "map"
                }
        
        map_tile_url = os.getenv(
            "MAP_TILE_URL",
            "https://tiles.openstreetmap.org/{z}/{x}/{y}.png"
        )
        
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>DayZ Trader - Select Spawn Location</title>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
            <style>
                * {{ margin: 0; padding: 0; box-sizing: border-box; }}
                body {{ font-family: Arial, sans-serif; background: #1a1a2e; color: #fff; }}
                #map {{ height: 100vh; }}
                .info {{ 
                    padding: 10px 20px; 
                    background: rgba(0, 0, 0, 0.8); 
                    border-bottom: 1px solid #00d4ff;
                }}
                .coordinates {{
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    background: rgba(0, 0, 0, 0.9);
                    padding: 15px;
                    border: 2px solid #00d4ff;
                    border-radius: 5px;
                    font-size: 14px;
                }}
                button {{
                    background: #00d4ff;
                    color: #000;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 3px;
                    cursor: pointer;
                    font-weight: bold;
                    margin-top: 10px;
                    width: 100%;
                }}
                button:hover {{ background: #00a8cc; }}
            </style>
        </head>
        <body>
            <div class="info">
                <h2>🗺️ Select Your Spawn Location</h2>
                <p>Click on the map to choose where your vehicle will spawn</p>
            </div>
            <div id="map"></div>
            <div class="coordinates">
                <p>Coordinates:</p>
                <p id="coords">Click on map...</p>
                <button id="confirm-btn" disabled>Confirm Location</button>
            </div>
            
            <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
            <script>
                let selectedLat = null, selectedLng = null;
                
                // Initialize map
                const map = L.map('map').setView([0, 0], 5);
                
                // Add tile layer
                L.tileLayer('{map_tile_url}', {{
                    maxZoom: 8,
                    attribution: '© DayZ Trader'
                }}).addTo(map);
                
                // Add click handler
                let marker = null;
                map.on('click', function(e) {{
                    selectedLat = e.latlng.lat;
                    selectedLng = e.latlng.lng;
                    
                    // Update marker
                    if (marker) map.removeLayer(marker);
                    marker = L.marker([selectedLat, selectedLng]).addTo(map);
                    
                    // Update display
                    document.getElementById('coords').innerHTML = 
                        'X: ' + selectedLng.toFixed(2) + '<br>Z: ' + selectedLat.toFixed(2);
                    document.getElementById('confirm-btn').disabled = false;
                }});
                
                // Confirm button
                document.getElementById('confirm-btn').onclick = function() {{
                    // Send to API
                    fetch('/api/spawn-point', {{
                        method: 'POST',
                        headers: {{'Content-Type': 'application/json'}},
                        body: JSON.stringify({{
                            token: '{token}',
                            lat: selectedLat,
                            lng: selectedLng
                        }})
                    }}).then(r => r.json()).then(data => {{
                        if (data.success) {{
                            alert('Location confirmed! Proceed with purchase in Discord.');
                            window.close();
                        }} else {{
                            alert('Error: ' + data.message);
                        }}
                    }});
                }};
            </script>
        </body>
        </html>
        """
    
    # API endpoints
    
    @app.post("/api/spawn-point")
    async def save_spawn_point(request: Request):
        """Save selected spawn point"""
        try:
            data = await request.json()
            token = data.get("token")
            lat = data.get("lat")
            lng = data.get("lng")
            
            # Verify token
            session = verify_token(token)
            
            # Convert to world coordinates
            from bot.utils.coords import ChernausCoordSystem
            world_x, world_z = ChernausCoordSystem.leaflet_to_world(lat, lng)
            
            # Store in session
            session["spawn_x"] = world_x
            session["spawn_z"] = world_z
            
            logger.info(f"Spawn point saved: ({world_x:.0f}, {world_z:.0f})")
            
            return {
                "success": True,
                "x": world_x,
                "z": world_z,
                "grid": ChernausCoordSystem.get_grid_square(world_x, world_z)
            }
        except Exception as e:
            logger.error(f"Error saving spawn point: {e}")
            return {
                "success": False,
                "message": str(e)
            }
    
    @app.get("/api/vehicles")
    async def list_vehicles():
        """List available vehicles"""
        try:
            vehicles = []
            for v in app.bot.config_loader.vehicle_defs.get("vehicles", []):
                if v.get("enabled"):
                    vehicles.append({
                        "classname": v.get("classname"),
                        "display": v.get("display_name"),
                        "price": v.get("price_buy"),
                        "description": v.get("description", "")
                    })
            
            return {"vehicles": vehicles}
        except Exception as e:
            logger.error(f"Error listing vehicles: {e}")
            return {"error": str(e)}
    
    @app.get("/api/items")
    async def list_items():
        """List available items"""
        try:
            items = []
            for i in app.bot.config_loader.console_items.get("items", []):
                if i.get("enabled"):
                    items.append({
                        "classname": i.get("classname"),
                        "display": i.get("display_name"),
                        "price": i.get("price"),
                        "category": i.get("category", "")
                    })
            
            return {"items": items}
        except Exception as e:
            logger.error(f"Error listing items: {e}")
            return {"error": str(e)}
    
    @app.post("/api/validate-cargo")
    async def validate_cargo(request: Request):
        """Validate cargo loadout"""
        try:
            data = await request.json()
            cargo = data.get("cargo", [])
            vehicle = data.get("vehicle")
            
            from bot.utils.validators import Validators
            validators = Validators(app.bot.config_loader)
            
            valid, msg = validators.validate_cargo_loadout(cargo, vehicle)
            
            return {
                "valid": valid,
                "message": msg
            }
        except Exception as e:
            logger.error(f"Validation error: {e}")
            return {
                "valid": False,
                "message": str(e)
            }
    
    @app.get("/health")
    async def health():
        """Health check"""
        return {"status": "ok", "bot": app.bot.user.name if app.bot.user else "offline"}
    
    return app

/**
 * Vehicle Card Builder
 * Visual builder for vehicle parts and run components
 */

class VehicleCardBuilder {
    constructor(containerId = 'vehicle-builder') {
        this.container = document.getElementById(containerId);
        this.vehicles = [];
        this.selectedVehicle = null;
        this.selectedParts = {};
        this.selectedRunParts = [];
        
        this.init();
    }
    
    async init() {
        // Load vehicles from API
        try {
            const response = await fetch('/api/vehicles');
            const data = await response.json();
            this.vehicles = data.vehicles || [];
            
            this.render();
        } catch (error) {
            console.error('Failed to load vehicles:', error);
            this.showError('Failed to load vehicles');
        }
    }
    
    render() {
        this.container.innerHTML = `
            <div class="vehicle-builder">
                <h2>🚗 Vehicle Builder</h2>
                
                <div class="builder-grid">
                    <!-- Vehicle Selection -->
                    <div class="builder-panel">
                        <h3>Select Vehicle</h3>
                        <div class="vehicle-list" id="vehicle-list">
                            ${this.vehicles.map(v => `
                                <div class="vehicle-option" onclick="vehicleBuilder.selectVehicle('${v.classname}')">
                                    <div class="vehicle-thumbnail" style="background: url('/static/img/vehicles/${v.classname}.png') center/cover">
                                        <span class="price">${v.price}</span>
                                    </div>
                                    <h4>${v.display}</h4>
                                    <p>${v.description}</p>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <!-- Parts Configuration -->
                    <div class="builder-panel">
                        <h3>Parts Configuration</h3>
                        <div id="parts-config">
                            ${this.selectedVehicle 
                                ? this.renderPartsConfig(this.selectedVehicle)
                                : '<p class="muted">Select a vehicle first</p>'
                            }
                        </div>
                    </div>
                    
                    <!-- Run Parts -->
                    <div class="builder-panel">
                        <h3>Run Parts (Required)</h3>
                        <div id="run-parts-config">
                            ${this.selectedVehicle 
                                ? this.renderRunPartsConfig(this.selectedVehicle)
                                : '<p class="muted">Select a vehicle first</p>'
                            }
                        </div>
                    </div>
                </div>
                
                <!-- Preview & Export -->
                <div class="builder-panel full-width">
                    <h3>Preview & Export</h3>
                    <div class="preview-section">
                        <div id="preview">
                            ${this.selectedVehicle 
                                ? this.renderPreview()
                                : '<p class="muted">Configure vehicle to see preview</p>'
                            }
                        </div>
                        <div class="actions">
                            <button class="btn btn-success" onclick="vehicleBuilder.exportConfig()">
                                📥 Export Configuration
                            </button>
                            <button class="btn btn-secondary" onclick="vehicleBuilder.generateXML()">
                                📄 Generate XML
                            </button>
                            <button class="btn" onclick="vehicleBuilder.reset()">
                                🔄 Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    selectVehicle(classname) {
        this.selectedVehicle = classname;
        this.selectedParts = {};
        this.selectedRunParts = [];
        
        // Highlight selected
        document.querySelectorAll('.vehicle-option').forEach(el => {
            el.classList.remove('selected');
        });
        event.currentTarget.classList.add('selected');
        
        // Re-render
        this.updatePartsConfig();
        this.updateRunPartsConfig();
        this.updatePreview();
    }
    
    renderPartsConfig(classname) {
        const vehicle = this.vehicles.find(v => v.classname === classname);
        if (!vehicle) return '';
        
        const parts = vehicle.parts || {};
        
        return `
            <div class="parts-grid">
                ${Object.entries(parts).map(([key, part]) => `
                    <label class="part-toggle">
                        <input type="checkbox" 
                            data-part="${key}"
                            onchange="vehicleBuilder.togglePart('${key}', this.checked)"
                            ${part.required ? 'checked disabled' : ''}
                        />
                        <div class="part-item">
                            <img src="/static/img/parts/${part.classname}.png" alt="${part.display}" 
                                 onerror="this.src='/static/img/parts/placeholder.png'"/>
                            <span>${part.display}</span>
                            ${part.required ? '<span class="required">Required</span>' : ''}
                        </div>
                    </label>
                `).join('')}
            </div>
        `;
    }
    
    renderRunPartsConfig(classname) {
        const vehicle = this.vehicles.find(v => v.classname === classname);
        if (!vehicle) return '';
        
        const runParts = vehicle.run_parts || [];
        
        return `
            <div class="run-parts-list">
                ${runParts.map(part => `
                    <div class="run-part-item">
                        <input type="checkbox" 
                            checked 
                            disabled
                            data-run-part="${part.classname}"
                        />
                        <span>✓ ${part.display}</span>
                        <small>${part.classname}</small>
                    </div>
                `).join('')}
                <p class="info">Run parts are always included</p>
            </div>
        `;
    }
    
    renderPreview() {
        if (!this.selectedVehicle) return '';
        
        const vehicle = this.vehicles.find(v => v.classname === this.selectedVehicle);
        
        return `
            <div class="vehicle-preview">
                <div class="preview-header">
                    <h4>${vehicle.display}</h4>
                    <span class="classname">${vehicle.classname}</span>
                </div>
                
                <div class="preview-stats">
                    <div class="stat">
                        <span class="label">Cargo Capacity:</span>
                        <span class="value">${vehicle.cargo_capacity || 'N/A'} slots</span>
                    </div>
                    <div class="stat">
                        <span class="label">Fuel Capacity:</span>
                        <span class="value">${vehicle.fuel_capacity || 'N/A'} units</span>
                    </div>
                    <div class="stat">
                        <span class="label">Seats:</span>
                        <span class="value">${vehicle.seats || 'N/A'}</span>
                    </div>
                </div>
                
                <div class="parts-summary">
                    <h5>Selected Parts</h5>
                    <ul>
                        ${Object.entries(this.selectedParts)
                            .filter(([_, enabled]) => enabled)
                            .map(([key]) => {
                                const part = vehicle.parts[key];
                                return `<li>✓ ${part.display}</li>`;
                            }).join('')}
                    </ul>
                </div>
            </div>
        `;
    }
    
    togglePart(key, checked) {
        this.selectedParts[key] = checked;
        this.updatePreview();
    }
    
    updatePartsConfig() {
        const config = document.getElementById('parts-config');
        if (config) {
            config.innerHTML = this.renderPartsConfig(this.selectedVehicle);
        }
    }
    
    updateRunPartsConfig() {
        const config = document.getElementById('run-parts-config');
        if (config) {
            config.innerHTML = this.renderRunPartsConfig(this.selectedVehicle);
        }
    }
    
    updatePreview() {
        const preview = document.getElementById('preview');
        if (preview) {
            preview.innerHTML = this.renderPreview();
        }
    }
    
    exportConfig() {
        const config = {
            vehicle: this.selectedVehicle,
            parts: this.selectedParts,
            timestamp: new Date().toISOString()
        };
        
        const json = JSON.stringify(config, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `vehicle_${this.selectedVehicle}_config.json`;
        a.click();
        
        this.showSuccess('Configuration exported');
    }
    
    generateXML() {
        if (!this.selectedVehicle) {
            this.showError('Please select a vehicle');
            return;
        }
        
        const vehicle = this.vehicles.find(v => v.classname === this.selectedVehicle);
        
        // Generate XML
        let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
        xml += `<!-- Generated by Vehicle Builder -->\n`;
        xml += `<types>\n`;
        xml += `  <type name="${this.selectedVehicle}_Trader">\n`;
        xml += `    <attachments chance="1.0">\n`;
        
        // Add selected parts
        Object.entries(this.selectedParts).forEach(([key, enabled]) => {
            if (enabled) {
                const part = vehicle.parts[key];
                xml += `      <item name="${part.classname}" chance="1.0"/>\n`;
            }
        });
        
        // Add run parts
        (vehicle.run_parts || []).forEach(part => {
            xml += `      <item name="${part.classname}" chance="1.0"/>\n`;
        });
        
        xml += `    </attachments>\n`;
        xml += `  </type>\n`;
        xml += `</types>\n`;
        
        // Save to file
        const blob = new Blob([xml], { type: 'application/xml' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${this.selectedVehicle}_spawn.xml`;
        a.click();
        
        this.showSuccess('XML generated and downloaded');
    }
    
    reset() {
        this.selectedVehicle = null;
        this.selectedParts = {};
        this.selectedRunParts = [];
        this.render();
    }
    
    showSuccess(message) {
        this.showAlert(message, 'success');
    }
    
    showError(message) {
        this.showAlert(message, 'error');
    }
    
    showAlert(message, type) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `<span>${message}</span>`;
        this.container.insertBefore(alert, this.container.firstChild);
        
        setTimeout(() => alert.remove(), 4000);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('vehicle-builder')) {
        window.vehicleBuilder = new VehicleCardBuilder('vehicle-builder');
    }
});

/**
 * DayZ Chernarus Map - Leaflet Integration
 * Converts between world coordinates and map coordinates
 */

class ChernaurusMap {
    constructor(elementId = 'map', options = {}) {
        // World bounds
        this.WORLD_WIDTH = 15360;
        this.WORLD_HEIGHT = 15360;
        
        // Map configuration
        this.element = document.getElementById(elementId);
        this.tileUrl = options.tileUrl || '/static/tiles/{z}/{x}/{y}.png';
        this.maxZoom = options.maxZoom || 8;
        this.minZoom = options.minZoom || 2;
        this.initialZoom = options.initialZoom || 5;
        
        // Selected coordinates
        this.selectedLat = null;
        this.selectedLng = null;
        this.marker = null;
        
        // Initialize Leaflet map
        this.initMap();
        
        // Bind events
        this.bindEvents();
    }
    
    /**
     * Initialize Leaflet map with Chernarus CRS
     */
    initMap() {
        // Create custom CRS for Chernarus
        const chernCRS = L.CRS.Simple;
        
        // Create map
        this.map = L.map(this.element, {
            crs: chernCRS,
            maxZoom: this.maxZoom,
            minZoom: this.minZoom,
            maxNativeZoom: 8,
            attributionControl: true
        }).setView([0, 0], this.initialZoom);
        
        // Add tile layer
        L.tileLayer(this.tileUrl, {
            maxZoom: this.maxZoom,
            attribution: '© DayZ Trader Map',
            noWrap: true,
            bounds: [
                [-90, -180],
                [90, 180]
            ]
        }).addTo(this.map);
        
        // Add grid/scale indicator
        this.addGridInfo();
    }
    
    /**
     * Convert Leaflet coords to DayZ world coords
     */
    leafletToWorld(lat, lng) {
        // Normalize from map range to -1 to 1
        const norm_z = -lat / 85;
        const norm_x = lng / 180;
        
        // Convert to world coordinates
        const world_x = norm_x * (this.WORLD_WIDTH / 2) + (this.WORLD_WIDTH / 2);
        const world_z = norm_z * (this.WORLD_HEIGHT / 2) + (this.WORLD_HEIGHT / 2);
        
        // Clamp to bounds
        return {
            x: Math.max(0, Math.min(this.WORLD_WIDTH, world_x)),
            z: Math.max(0, Math.min(this.WORLD_HEIGHT, world_z))
        };
    }
    
    /**
     * Convert DayZ world coords to Leaflet coords
     */
    worldToLeaflet(world_x, world_z) {
        // Normalize to -1 to 1
        const norm_x = (world_x - this.WORLD_WIDTH / 2) / (this.WORLD_WIDTH / 2);
        const norm_z = (world_z - this.WORLD_HEIGHT / 2) / (this.WORLD_HEIGHT / 2);
        
        // Convert to lat/lng
        const lat = -norm_z * 85;
        const lng = norm_x * 180;
        
        return { lat, lng };
    }
    
    /**
     * Get Chernarus grid square (e.g., "J5")
     */
    getGridSquare(world_x, world_z) {
        // Grid columns (A-P)
        const col_index = Math.floor((world_x / this.WORLD_WIDTH) * 16);
        const col = String.fromCharCode(65 + Math.min(15, Math.max(0, col_index)));
        
        // Grid rows (1-16)
        const row_index = Math.floor((world_z / this.WORLD_HEIGHT) * 16);
        const row = 16 - Math.min(15, Math.max(0, row_index));
        
        return `${col}${row}`;
    }
    
    /**
     * Bind map click event
     */
    bindEvents() {
        this.map.on('click', (e) => {
            this.selectedLat = e.latlng.lat;
            this.selectedLng = e.latlng.lng;
            
            // Convert to world coordinates
            const world = this.leafletToWorld(this.selectedLat, this.selectedLng);
            
            // Update marker
            if (this.marker) {
                this.map.removeLayer(this.marker);
            }
            
            this.marker = L.marker([this.selectedLat, this.selectedLng], {
                icon: L.icon({
                    iconUrl: 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgdmlld0JveD0iMCAwIDMyIDMyIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxNCIgZmlsbD0iIzAwZDRmZiIgc3Ryb2tlPSIjMDAwMDAwIiBzdHJva2Utd2lkdGg9IjIiLz48L3N2Zz4=',
                    iconSize: [32, 32],
                    iconAnchor: [16, 16]
                })
            }).addTo(this.map);
            
            // Update display
            const grid = this.getGridSquare(world.x, world.z);
            this.updateCoordinateDisplay(world.x, world.z, grid);
            this.updateConfirmButton(true);
            
            // Fire custom event
            this.dispatchEvent('locationSelected', {
                x: world.x,
                z: world.z,
                lat: this.selectedLat,
                lng: this.selectedLng,
                grid: grid
            });
        });
    }
    
    /**
     * Update coordinate display
     */
    updateCoordinateDisplay(x, z, grid) {
        const display = document.getElementById('coords');
        if (display) {
            display.innerHTML = `
                <strong>X:</strong> ${Math.round(x)} | 
                <strong>Z:</strong> ${Math.round(z)}<br/>
                <strong>Grid:</strong> ${grid}
            `;
        }
    }
    
    /**
     * Enable/disable confirm button
     */
    updateConfirmButton(enabled) {
        const btn = document.getElementById('confirm-btn');
        if (btn) {
            btn.disabled = !enabled;
        }
    }
    
    /**
     * Dispatch custom event
     */
    dispatchEvent(name, detail) {
        const event = new CustomEvent(name, { detail });
        this.element.dispatchEvent(event);
    }
    
    /**
     * Add grid overlay info
     */
    addGridInfo() {
        // Add helpful info to map
        const info = L.control({ position: 'topright' });
        
        info.onAdd = (map) => {
            const div = L.DomUtil.create('div', 'map-info');
            div.innerHTML = `
                <div style="background: rgba(0,0,0,0.8); padding: 10px; border-radius: 5px; color: #00d4ff; font-size: 12px; max-width: 200px;">
                    <strong>Chernarus Map</strong><br/>
                    Click to select spawn point<br/>
                    Zoom: Use scroll or buttons
                </div>
            `;
            return div;
        };
        
        info.addTo(this.map);
    }
    
    /**
     * Pan to world coordinates
     */
    panToWorld(world_x, world_z, zoom = this.initialZoom) {
        const leaflet = this.worldToLeaflet(world_x, world_z);
        this.map.setView([leaflet.lat, leaflet.lng], zoom);
    }
    
    /**
     * Add safe zone marker
     */
    addSafeZone(name, world_x, world_z, radius_meters = 500) {
        const leaflet = this.worldToLeaflet(world_x, world_z);
        
        // Add circle
        L.circle([leaflet.lat, leaflet.lng], {
            radius: radius_meters * 2,  // Scale factor for visual effect
            color: '#00ff00',
            fill: true,
            fillColor: '#00ff00',
            fillOpacity: 0.1,
            weight: 2,
            dashArray: '5, 5'
        }).addTo(this.map).bindPopup(`<strong>${name}</strong><br/>Safe Zone`);
    }
    
    /**
     * Add blacklist zone marker
     */
    addBlacklistZone(name, world_x, world_z, radius_meters = 500) {
        const leaflet = this.worldToLeaflet(world_x, world_z);
        
        // Add circle
        L.circle([leaflet.lat, leaflet.lng], {
            radius: radius_meters * 2,
            color: '#ff4444',
            fill: true,
            fillColor: '#ff4444',
            fillOpacity: 0.1,
            weight: 2,
            dashArray: '5, 5'
        }).addTo(this.map).bindPopup(`<strong>${name}</strong><br/>No-Spawn Zone`);
    }
}

// Initialize map when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('map')) {
        window.chernMap = new ChernaurusMap('map');
    }
});

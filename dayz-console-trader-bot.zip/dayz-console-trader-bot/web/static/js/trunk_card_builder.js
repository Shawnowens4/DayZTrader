/**
 * Trunk/Cargo Card Builder
 * Build nested cargo loadouts respecting console nesting rules
 */

class TrunkBuilder {
    constructor(containerId = 'trunk-builder') {
        this.container = document.getElementById(containerId);
        this.items = [];
        this.cargo = [];  // {classname, quantity, nested: [...]}
        this.selectedVehicle = null;
        
        this.init();
    }
    
    async init() {
        try {
            // Load items and vehicles
            const [itemsRes, vehiclesRes] = await Promise.all([
                fetch('/api/items'),
                fetch('/api/vehicles')
            ]);
            
            this.items = (await itemsRes.json()).items || [];
            const vehicles = (await vehiclesRes.json()).vehicles || [];
            
            this.vehicleMap = {};
            vehicles.forEach(v => {
                this.vehicleMap[v.classname] = v;
            });
            
            this.render();
        } catch (error) {
            console.error('Failed to load data:', error);
            this.showError('Failed to load cargo items');
        }
    }
    
    render() {
        this.container.innerHTML = `
            <div class="trunk-builder">
                <h2>📦 Trunk/Cargo Builder</h2>
                
                <div class="builder-grid">
                    <!-- Vehicle Selection -->
                    <div class="builder-panel">
                        <h3>Select Vehicle</h3>
                        <select id="vehicle-select" onchange="trunkBuilder.selectVehicle(this.value)">
                            <option value="">-- Choose Vehicle --</option>
                            ${Object.values(this.vehicleMap).map(v => `
                                <option value="${v.classname}">${v.display}</option>
                            `).join('')}
                        </select>
                        <div id="vehicle-capacity" class="info"></div>
                    </div>
                    
                    <!-- Item Browser -->
                    <div class="builder-panel">
                        <h3>Available Items</h3>
                        <input type="text" id="item-search" placeholder="Search items..." 
                            onkeyup="trunkBuilder.filterItems(this.value)" />
                        <div class="items-list" id="items-list">
                            ${this.renderItemsList()}
                        </div>
                    </div>
                    
                    <!-- Cargo Preview -->
                    <div class="builder-panel">
                        <h3>Cargo Contents</h3>
                        <div id="cargo-preview">
                            ${this.renderCargoPreview()}
                        </div>
                    </div>
                </div>
                
                <!-- Actions -->
                <div class="builder-panel full-width">
                    <h3>Actions</h3>
                    <div class="action-buttons">
                        <button class="btn btn-success" onclick="trunkBuilder.exportLoadout()">
                            💾 Save Loadout
                        </button>
                        <button class="btn btn-secondary" onclick="trunkBuilder.validateCargo()">
                            ✓ Validate Cargo
                        </button>
                        <button class="btn" onclick="trunkBuilder.clearCargo()">
                            🗑️ Clear All
                        </button>
                    </div>
                </div>
                
                <!-- Validation Info -->
                <div id="validation-info"></div>
            </div>
        `;
    }
    
    renderItemsList() {
        return this.items
            .filter(i => i.enabled)
            .map(item => `
                <div class="item-option" onclick="trunkBuilder.addItem('${item.classname}')">
                    <img src="/static/img/items/${item.classname}.png" alt="${item.display}"
                        onerror="this.src='/static/img/items/placeholder.png'" />
                    <div class="item-info">
                        <h5>${item.display}</h5>
                        <small>${item.category}</small>
                        <p class="price">${item.price || 0} credits</p>
                        <span class="slots">${item.slots} slots</span>
                    </div>
                </div>
            `).join('');
    }
    
    renderCargoPreview() {
        if (this.cargo.length === 0) {
            return '<p class="muted">Add items to your cargo</p>';
        }
        
        const totalSlots = this.calculateTotalSlots();
        const maxSlots = this.getMaxCargoSlots();
        const totalCost = this.calculateTotalCost();
        
        return `
            <div class="cargo-list">
                ${this.cargo.map((item, idx) => `
                    <div class="cargo-item">
                        <span class="item-name">${item.display} × ${item.quantity}</span>
                        <span class="item-slots">${item.slots * item.quantity} slots</span>
                        <button class="btn btn-small btn-danger" onclick="trunkBuilder.removeItem(${idx})">✕</button>
                    </div>
                `).join('')}
            </div>
            
            <div class="cargo-stats">
                <div class="stat">
                    <span>Total Slots:</span>
                    <strong>${totalSlots}/${maxSlots}</strong>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${(totalSlots/maxSlots)*100}%"></div>
                    </div>
                </div>
                <div class="stat">
                    <span>Total Cost:</span>
                    <strong>${totalCost} credits</strong>
                </div>
            </div>
        `;
    }
    
    filterItems(query) {
        const itemsList = document.getElementById('items-list');
        const filtered = this.items.filter(i => 
            i.enabled && (
                i.display.toLowerCase().includes(query.toLowerCase()) ||
                i.category.toLowerCase().includes(query.toLowerCase())
            )
        );
        
        itemsList.innerHTML = filtered.length > 0
            ? filtered.map(item => `
                <div class="item-option" onclick="trunkBuilder.addItem('${item.classname}')">
                    <img src="/static/img/items/${item.classname}.png" alt="${item.display}"
                        onerror="this.src='/static/img/items/placeholder.png'" />
                    <div class="item-info">
                        <h5>${item.display}</h5>
                        <small>${item.category}</small>
                        <p class="price">${item.price || 0} credits</p>
                        <span class="slots">${item.slots} slots</span>
                    </div>
                </div>
            `).join('')
            : '<p class="muted">No items found</p>';
    }
    
    selectVehicle(classname) {
        this.selectedVehicle = classname;
        this.cargo = [];  // Clear cargo on vehicle change
        
        if (classname) {
            const vehicle = this.vehicleMap[classname];
            document.getElementById('vehicle-capacity').innerHTML = `
                <div class="capacity-info">
                    <strong>${vehicle.display}</strong><br/>
                    Capacity: ${vehicle.cargo_capacity} slots
                </div>
            `;
        }
        
        this.updateCargoPreview();
    }
    
    addItem(classname) {
        const item = this.items.find(i => i.classname === classname);
        if (!item) return;
        
        // Check if item already in cargo
        const existing = this.cargo.find(c => c.classname === classname);
        if (existing) {
            existing.quantity += 1;
        } else {
            this.cargo.push({
                classname: classname,
                display: item.display,
                quantity: 1,
                slots: item.slots,
                price: item.price || 0,
                category: item.category
            });
        }
        
        this.updateCargoPreview();
    }
    
    removeItem(index) {
        this.cargo.splice(index, 1);
        this.updateCargoPreview();
    }
    
    calculateTotalSlots() {
        return this.cargo.reduce((sum, item) => sum + (item.slots * item.quantity), 0);
    }
    
    calculateTotalCost() {
        return this.cargo.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }
    
    getMaxCargoSlots() {
        if (!this.selectedVehicle) return 0;
        const vehicle = this.vehicleMap[this.selectedVehicle];
        return vehicle.cargo_capacity || 0;
    }
    
    async validateCargo() {
        if (!this.selectedVehicle) {
            this.showError('Please select a vehicle');
            return;
        }
        
        if (this.cargo.length === 0) {
            this.showError('Please add items to cargo');
            return;
        }
        
        try {
            const response = await fetch('/api/validate-cargo', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    vehicle: this.selectedVehicle,
                    cargo: this.cargo
                })
            });
            
            const result = await response.json();
            
            const info = document.getElementById('validation-info');
            if (result.valid) {
                this.showSuccess(result.message);
                info.innerHTML = `<div class="alert alert-success">${result.message}</div>`;
            } else {
                this.showError(result.message);
                info.innerHTML = `<div class="alert alert-error">${result.message}</div>`;
            }
        } catch (error) {
            this.showError('Validation error: ' + error.message);
        }
    }
    
    exportLoadout() {
        if (this.cargo.length === 0) {
            this.showError('No cargo to export');
            return;
        }
        
        const loadout = {
            vehicle: this.selectedVehicle,
            cargo: this.cargo,
            totalSlots: this.calculateTotalSlots(),
            totalCost: this.calculateTotalCost(),
            timestamp: new Date().toISOString()
        };
        
        const json = JSON.stringify(loadout, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `loadout_${Date.now()}.json`;
        a.click();
        
        this.showSuccess('Loadout exported!');
    }
    
    clearCargo() {
        if (confirm('Clear all cargo items?')) {
            this.cargo = [];
            this.updateCargoPreview();
            this.showSuccess('Cargo cleared');
        }
    }
    
    updateCargoPreview() {
        const preview = document.getElementById('cargo-preview');
        if (preview) {
            preview.innerHTML = this.renderCargoPreview();
        }
    }
    
    showSuccess(message) {
        this.showAlert(message, 'success');
    }
    
    showError(message) {
        this.showAlert(message, 'error');
    }
    
    showAlert(message, type) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `<span>${message}</span>`;
        this.container.insertBefore(alert, this.container.firstChild);
        
        setTimeout(() => alert.remove(), 4000);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('trunk-builder')) {
        window.trunkBuilder = new TrunkBuilder('trunk-builder');
    }
});

# DayZ Console Trader Bot

**Discord-driven trader for Nitrado Xbox/PlayStation DayZ servers (1.29.1+)**

Players buy and rent vanilla vehicles, and purchase nested cargo loadouts at Leaflet-selected Chernarus coordinates. Admin-controlled catalog with thumbnail vehicle builders and console-safe cargo nesting rules. All spawns deployed via Nitrado FTP/API by writing validated CLE XML. Vehicles persist until destroyed or engine death.

## Features

- 🚗 **Vehicle Trading** — Buy (one-time) or rent (timed) full-build vanilla vehicles
- 📦 **Cargo System** — Nested trunk/loadout builder restricted to 1600+ console cargo items
- 🗺️ **Leaflet Map** — Click-to-select Chernarus spawn coordinates (safe zones optional)
- 💳 **Currency** — Discord-managed balance (points, in-game tracking, or Discord roles)
- 🎨 **Thumbnail Cards** — Visual vehicle parts builder + nested cargo card builder
- 🔐 **Admin Panel** — Catalog prices, vehicle stock, force deploy, config reload
- ✅ **XML Safety** — All spawns validated; console classnames only; mission backup on every deploy
- 📊 **Rentals** — Time-tracked; optional auto-expiry (vehicle stays until destroyed by server)

## Quick Start

### Prerequisites

- Python 3.11+
- Discord bot token (Server with admin/mod roles)
- Nitrado Xbox or PS DayZ service with FTP access + API token
- Mission path: `/dayzxb_mission/` or `/dayzps_mission/` → `dayzoffline.chernarusplus/`

### 1. Clone & Setup

```bash
git clone <your-repo> dayz-console-trader-bot
cd dayz-console-trader-bot
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env with your Discord token, Nitrado credentials, FTP details
```

Create `config/vehicle_defs.json` and `config/console_items.json` from your 1.29.1 mission files (see Phase 3 in spec).

### 3. Database

```bash
sqlite3 data/trader.db < data/schema.sql
```

### 4. Run

```bash
python bot/main.py
```

Web UI will start on `http://localhost:8788` (configurable).

---

## Discord Commands

### Player Commands

| Command | Usage |
|---------|-------|
| `/shop` | Browse available vehicles and items |
| `/buy vehicle <vehicle>` | Purchase & spawn a vehicle at map-selected coords |
| `/rent vehicle <vehicle> <hours>` | Rent a vehicle for N hours |
| `/buy items` | Build & purchase a nested cargo loadout |
| `/balance` | Check your current balance |
| `/orders` | View your pending/completed spawn orders |

### Admin Commands

| Command | Usage |
|---------|-------|
| `/admin catalog set-price <vehicle\|item> <price>` | Update catalog price |
| `/admin catalog toggle <vehicle\|item>` | Enable/disable trading |
| `/admin give_balance <@user> <amount>` | Credit a player |
| `/admin force_deploy <order_id>` | Manually retry failed FTP upload |
| `/admin reload_config` | Reload JSON allowlists (no restart) |
| `/admin logs <limit>` | View recent spawn/FTP logs |

---

## Web UI Routes

| Endpoint | Purpose |
|----------|---------|
| `GET /` | Admin dashboard (requires auth) |
| `GET /map?token=<token>` | Leaflet map (ephemeral token) |
| `POST /api/spawn-point` | Save selected x,z from map |
| `GET /api/vehicle-builder` | Vehicle card builder |
| `GET /api/trunk-builder` | Nested cargo card builder |
| `POST /api/validate-cargo` | Check cargo fits rules |

---

## Architecture

```
Discord bot (discord.py)
  ├── Command cogs (trader, admin, map_link)
  ├── Services (economy, order, vehicle spawn, cargo builder, xml gen, nitrado, ftp)
  └── Utils (validators, coords)

FastAPI web server
  ├── Leaflet Chernarus map (static JS)
  ├── Vehicle card builder (HTML + JS)
  ├── Trunk card builder (HTML + JS)
  └── API routes (spawn-point, validation, config)

Database (SQLite or Postgres)
  ├── users, catalog_vehicles, catalog_items
  ├── orders, rentals, spawn_log
  └── (optional) admin_zones, blacklist_coords

Nitrado FTP/API
  ├── Mission file backup
  ├── XML deployment
  └── Server restart (optional)
```

---

## Key Files

- **`config/vehicle_defs.json`** — Admin-allowed vehicles + part slots (Xbox/PS 1.29.1 vanilla only)
- **`config/console_items.json`** — 1600+ cargo classnames + nesting rules
- **`config/nesting_rules.json`** — Container max depth, weapon nesting constraints
- **`bot/main.py`** — Bot entry point; cog loader; FastAPI integration
- **`bot/services/xml_generator.py`** — Validates + builds CLE XML from orders
- **`bot/services/nitrado_client.py`** — Nitrado API (file download/upload, status)
- **`bot/services/ftp_client.py`** — FTPS backup + upload
- **`web/static/js/map.js`** — Leaflet map + click-to-spawn
- **`web/static/js/vehicle_card_builder.js`** — Vehicle parts UI
- **`web/static/js/trunk_card_builder.js`** — Nested cargo UI
- **`data/schema.sql`** — SQLite schema

---

## DayZ Console Safety (1.29.1+)

⚠️ **Do not break these:**

- **No Enscript / PC mods** — Spawns only via vanilla CLE + `cfgspawnabletypes.xml`.
- **Classnames only from types.xml** — Vehicle, item, weapon, attachment classnames must exist in your mission.
- **Nesting rules enforced** — Containers in containers, weapons in containers, respecting max depth + slot size.
- **Backup on every deploy** — Mission zip created before FTP write; rollback available.
- **No vehicle scripted persistence** — Car lives until destroyed by player, engine death, or server vehicle reset. Rentals tracked in Discord DB only; game does not "know" about expiry.

---

## Recommended Tuning (Mission Side)

1. **Vehicle events** — Reduce or disable stock `OffroadHatchback` / sedan events if you want trader-only spawns.
2. **CE lifetime** — Increase vehicle lifetime in `events.xml` if you want purchased cars to stay longer (players lose them on server wipe regardless).
3. **Fuel** — Consider stocking fuel containers in default trunk so players can drive; gasoline always needs player input.

---

## Deployment

- **Local dev:** FTP to test Nitrado folder; watch `spawn_log` table for errors.
- **Production:** Use Cloudflare Tunnel + IP allowlist for web UI. Map tokens expire in 5 min.
- **Backup strategy:** Nightly mission zip to Discord logging channel; FTP failures block new orders.

---

## Troubleshooting

### Vehicle won't spawn
- Check `spawn_log` table for XML error details.
- Verify classname exists in your `types.xml` + `cfgspawnabletypes.xml`.
- Confirm coordinates are on land (not water / out of bounds).

### Cargo exceeds slots
- Run `/api/validate-cargo` with your loadout JSON.
- Reduce item count or use smaller containers.

### FTP upload fails
- Confirm mission folder path in `.env` matches Nitrado (e.g., `/dayzxb_mission/dayzoffline.chernarusplus/`).
- Check FTP credentials + FTPS support.

### Map not loading
- Verify `MAP_TILE_URL` points to valid tile server.
- Check browser console for CORS errors; ensure tiles are public or behind same auth.

---

## References

- [DayZ Wiki — Console 1.29.1 Changes](https://dayz.fandom.com/wiki/Console_Edition)
- [CLE Config Documentation](https://community.bistudio.com/wiki/Arma_3_CfgVehicles)
- [Nitrado API Docs](https://github.com/nitrado/nitrado-node-service)
- [Leaflet.js](https://leafletjs.com/)

---

## License

MIT

## Support

Post issues to Discord support channel or admin DMs. For FTP/Nitrado emergencies, see admin logs.

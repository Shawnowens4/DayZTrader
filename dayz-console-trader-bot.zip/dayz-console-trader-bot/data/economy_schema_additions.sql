-- DayZ Trader Bot - Economy Extensions
-- Add these tables to support money-making activities

-- Daily login rewards
CREATE TABLE IF NOT EXISTS daily_rewards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    reward_amount REAL NOT NULL,
    streak INTEGER DEFAULT 1,
    claimed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(user_id, DATE(claimed_at))
);

CREATE INDEX idx_daily_rewards_user ON daily_rewards(user_id);
CREATE INDEX idx_daily_rewards_date ON daily_rewards(claimed_at);

-- Achievements system
CREATE TABLE IF NOT EXISTS achievements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    achievement_id TEXT UNIQUE NOT NULL,
    achievement_name TEXT NOT NULL,
    description TEXT,
    icon TEXT,
    category TEXT,  -- 'combat', 'trading', 'survival', 'social'
    enabled BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS achievements_unlocked (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    achievement_id TEXT NOT NULL,
    achievement_name TEXT NOT NULL,
    description TEXT,
    reward REAL DEFAULT 2000,
    unlocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (achievement_id) REFERENCES achievements(achievement_id),
    UNIQUE(user_id, achievement_id)
);

CREATE INDEX idx_achievements_unlocked_user ON achievements_unlocked(user_id);
CREATE INDEX idx_achievements_unlocked_date ON achievements_unlocked(unlocked_at);

-- Survival time tracking (for in-game rewards)
CREATE TABLE IF NOT EXISTS survival_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    hours_survived INTEGER NOT NULL,
    reward REAL NOT NULL,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_survival_tracking_user ON survival_tracking(user_id);

-- Bounty system
CREATE TABLE IF NOT EXISTS bounties (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    placer_id INTEGER NOT NULL,
    hunter_id INTEGER,
    target_name TEXT NOT NULL,
    amount REAL NOT NULL,
    reason TEXT,
    status TEXT DEFAULT 'active',  -- 'active', 'claimed', 'expired', 'cancelled'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    claimed_at TIMESTAMP,
    FOREIGN KEY (placer_id) REFERENCES users(id),
    FOREIGN KEY (hunter_id) REFERENCES users(id)
);

CREATE INDEX idx_bounties_target ON bounties(target_name);
CREATE INDEX idx_bounties_status ON bounties(status);
CREATE INDEX idx_bounties_placer ON bounties(placer_id);

-- Gambling history
CREATE TABLE IF NOT EXISTS gambling_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    game_type TEXT NOT NULL,  -- 'coinflip', 'dice', 'lottery'
    bet_amount REAL NOT NULL,
    result TEXT,
    winnings REAL NOT NULL,
    net_change REAL NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_gambling_user ON gambling_history(user_id);
CREATE INDEX idx_gambling_date ON gambling_history(played_at);

-- Missions system
CREATE TABLE IF NOT EXISTS missions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    objective TEXT,
    reward REAL NOT NULL,
    difficulty TEXT DEFAULT 'medium',  -- 'easy', 'medium', 'hard'
    category TEXT,  -- 'hunt', 'explore', 'gather', 'trade'
    enabled BOOLEAN DEFAULT 1,
    max_completions_per_player INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS mission_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    mission_id INTEGER NOT NULL,
    status TEXT DEFAULT 'active',  -- 'active', 'completed', 'abandoned'
    progress INTEGER DEFAULT 0,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (mission_id) REFERENCES missions(id),
    UNIQUE(user_id, mission_id)
);

CREATE INDEX idx_mission_progress_user ON mission_progress(user_id);
CREATE INDEX idx_mission_progress_status ON mission_progress(status);

-- Trading/marketplace history
CREATE TABLE IF NOT EXISTS trading_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL,
    buyer_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    unit_price REAL NOT NULL,
    total_amount REAL NOT NULL,
    marketplace BOOLEAN DEFAULT 0,
    traded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users(id),
    FOREIGN KEY (buyer_id) REFERENCES users(id)
);

CREATE INDEX idx_trading_seller ON trading_history(seller_id);
CREATE INDEX idx_trading_buyer ON trading_history(buyer_id);

-- Player streaks/stats
CREATE TABLE IF NOT EXISTS player_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE,
    total_earned REAL DEFAULT 0,
    total_spent REAL DEFAULT 0,
    daily_streak INTEGER DEFAULT 0,
    kills INTEGER DEFAULT 0,
    deaths INTEGER DEFAULT 0,
    vehicles_purchased INTEGER DEFAULT 0,
    items_purchased INTEGER DEFAULT 0,
    missions_completed INTEGER DEFAULT 0,
    achievements_unlocked INTEGER DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Marketplace listings (player-to-player trading)
CREATE TABLE IF NOT EXISTS marketplace_listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    unit_price REAL NOT NULL,
    status TEXT DEFAULT 'active',  -- 'active', 'sold', 'expired'
    listed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    sold_at TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users(id)
);

CREATE INDEX idx_marketplace_seller ON marketplace_listings(seller_id);
CREATE INDEX idx_marketplace_status ON marketplace_listings(status);
CREATE INDEX idx_marketplace_expires ON marketplace_listings(expires_at);

-- Clan/group bonuses
CREATE TABLE IF NOT EXISTS clans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clan_name TEXT UNIQUE NOT NULL,
    leader_id INTEGER NOT NULL,
    description TEXT,
    tag TEXT UNIQUE,
    founded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (leader_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS clan_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clan_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    rank TEXT DEFAULT 'member',  -- 'leader', 'officer', 'member'
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (clan_id) REFERENCES clans(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(clan_id, user_id)
);

CREATE INDEX idx_clan_members_clan ON clan_members(clan_id);
CREATE INDEX idx_clan_members_user ON clan_members(user_id);

-- Seasonal battle pass (limited time events)
CREATE TABLE IF NOT EXISTS battle_pass_seasons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    season_number INTEGER UNIQUE NOT NULL,
    theme TEXT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    enabled BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS battle_pass_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    season_id INTEGER NOT NULL,
    level INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    rewards_claimed TEXT,  -- JSON array of claimed reward IDs
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (season_id) REFERENCES battle_pass_seasons(id),
    UNIQUE(user_id, season_id)
);

-- Event/weekly challenges
CREATE TABLE IF NOT EXISTS weekly_challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    challenge_type TEXT,  -- 'kills', 'trades', 'survival', 'spending'
    target_count INTEGER NOT NULL,
    reward REAL NOT NULL,
    week_start DATE NOT NULL,
    week_end DATE NOT NULL,
    enabled BOOLEAN DEFAULT 1
);

CREATE TABLE IF NOT EXISTS challenge_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    challenge_id INTEGER NOT NULL,
    current_count INTEGER DEFAULT 0,
    completed BOOLEAN DEFAULT 0,
    completed_at TIMESTAMP,
    reward_claimed BOOLEAN DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (challenge_id) REFERENCES weekly_challenges(id),
    UNIQUE(user_id, challenge_id)
);

-- Update users table to add new columns if not exists
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_earned REAL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_spent REAL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_streak INTEGER DEFAULT 0;

-- Triggers for auto-updating stats
CREATE TRIGGER IF NOT EXISTS update_player_stats_on_balance_change
AFTER UPDATE ON users
BEGIN
    UPDATE player_stats
    SET total_earned = (SELECT COALESCE(SUM(amount_change), 0) 
                        FROM balance_log 
                        WHERE user_id = NEW.id AND amount_change > 0)
    WHERE user_id = NEW.id;
END;

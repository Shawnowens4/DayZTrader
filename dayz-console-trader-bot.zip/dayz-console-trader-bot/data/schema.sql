-- DayZ Console Trader Bot Database Schema
-- SQLite (compatible with async drivers: aiosqlite)
-- For PostgreSQL, modify column types (TEXT → VARCHAR, REAL → NUMERIC, etc.)

-- Users & Economy
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id INTEGER UNIQUE NOT NULL,
    username TEXT NOT NULL,
    balance REAL NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT 'Rubles',
    last_spawn_at TIMESTAMP,
    last_balance_adjustment TIMESTAMP,
    total_spent REAL DEFAULT 0,
    total_earned REAL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_discord_id ON users(discord_id);

-- Admin-managed catalog: vehicles
CREATE TABLE IF NOT EXISTS catalog_vehicles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    classname TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    enabled BOOLEAN DEFAULT 1,
    price_buy REAL,
    price_rent_hour REAL,
    rent_max_hours INTEGER DEFAULT 24,
    cargo_capacity INTEGER,
    fuel_capacity INTEGER,
    seats INTEGER,
    thumbnail_url TEXT,
    parts_json TEXT,  -- JSON: {wheel: {...}, door_1_1: {...}, ...}
    run_parts_json TEXT,  -- JSON: [{classname: "CarBattery", required: true}, ...]
    color_json TEXT,  -- JSON: [{name: "Default", hex: "#ffffff"}, ...]
    stock_limit INTEGER,  -- -1 = unlimited
    cooldown_seconds INTEGER DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_catalog_vehicles_classname ON catalog_vehicles(classname);
CREATE INDEX idx_catalog_vehicles_enabled ON catalog_vehicles(enabled);

-- Admin-managed catalog: items
CREATE TABLE IF NOT EXISTS catalog_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    classname TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    enabled BOOLEAN DEFAULT 1,
    price REAL,
    cargo_slots INTEGER,
    is_weapon BOOLEAN DEFAULT 0,
    is_container BOOLEAN DEFAULT 0,
    can_nest_in TEXT,  -- JSON array: ["Backpack", "TacticalBag", ...]
    max_quantity INTEGER DEFAULT 1,
    max_quantity_per_loadout INTEGER DEFAULT 10,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_catalog_items_classname ON catalog_items(classname);
CREATE INDEX idx_catalog_items_enabled ON catalog_items(enabled);
CREATE INDEX idx_catalog_items_category ON catalog_items(category);

-- Orders: buy vehicle, rent vehicle, buy cargo
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    order_type TEXT NOT NULL,  -- 'buy_vehicle', 'rent_vehicle', 'buy_items'
    status TEXT DEFAULT 'pending',  -- pending, confirmed, deployed, expired, cancelled, failed
    vehicle_classname TEXT,
    cargo_json TEXT,  -- JSON: [{classname: "...", quantity: 1}, ...] for buy_items
    spawn_x REAL,
    spawn_z REAL,
    spawn_y REAL DEFAULT 0,
    map_zone_name TEXT,
    total_cost REAL NOT NULL,
    currency_paid_with TEXT,
    xml_hash TEXT,  -- hash of generated XML for de-duplication
    ftp_path TEXT,  -- where the file was deployed
    message TEXT,  -- admin notes / error messages
    confirmed_at TIMESTAMP,
    deployed_at TIMESTAMP,
    expires_at TIMESTAMP,  -- for rentals
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_orders_user_id ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_order_type ON orders(order_type);
CREATE INDEX idx_orders_deployed_at ON orders(deployed_at);

-- Vehicle Rentals: tracks active rentals and expiry
CREATE TABLE IF NOT EXISTS rentals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL UNIQUE,
    vehicle_instance_id TEXT,  -- if tracked by game (optional; for future use)
    vehicle_classname TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    hours_rented INTEGER NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    status TEXT DEFAULT 'active',  -- active, expired, reclaimed, destroyed
    last_reminder_sent TIMESTAMP,
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_rentals_expires_at ON rentals(expires_at);
CREATE INDEX idx_rentals_status ON rentals(status);
CREATE INDEX idx_rentals_user_id ON rentals(user_id);

-- Spawn Log: audit trail of FTP deployments
CREATE TABLE IF NOT EXISTS spawn_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    user_id INTEGER NOT NULL,
    vehicle_classname TEXT,
    spawn_x REAL,
    spawn_z REAL,
    xml_snippet TEXT,  -- the actual XML generated (for debugging)
    xml_hash TEXT,  -- unique hash of XML for de-duplication
    ftp_host TEXT,
    ftp_path TEXT,
    backup_path TEXT,  -- where we backed up the mission before upload
    success BOOLEAN DEFAULT 0,
    error_message TEXT,
    error_code TEXT,
    nitrado_response TEXT,  -- raw Nitrado API response (if any)
    file_size_bytes INTEGER,
    upload_duration_seconds REAL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_spawn_log_user_id ON spawn_log(user_id);
CREATE INDEX idx_spawn_log_success ON spawn_log(success);
CREATE INDEX idx_spawn_log_created_at ON spawn_log(created_at);

-- Transaction Log: every balance change
CREATE TABLE IF NOT EXISTS balance_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    amount_change REAL NOT NULL,
    reason TEXT,  -- 'spawn_vehicle', 'buy_cargo', 'admin_credit', 'admin_debit', etc.
    order_id INTEGER,
    admin_id INTEGER,  -- if admin action
    new_balance REAL NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (admin_id) REFERENCES users(id)
);

CREATE INDEX idx_balance_log_user_id ON balance_log(user_id);
CREATE INDEX idx_balance_log_created_at ON balance_log(created_at);

-- Safe Zones (optional): admin-defined trader zones
CREATE TABLE IF NOT EXISTS safe_zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zone_name TEXT UNIQUE NOT NULL,
    center_x REAL NOT NULL,
    center_z REAL NOT NULL,
    radius_meters INTEGER NOT NULL,
    description TEXT,
    enabled BOOLEAN DEFAULT 1,
    allow_vehicle_spawn BOOLEAN DEFAULT 1,
    allow_cargo_spawn BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Blacklist Zones (optional): no-spawn areas
CREATE TABLE IF NOT EXISTS blacklist_zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zone_name TEXT UNIQUE NOT NULL,
    center_x REAL NOT NULL,
    center_z REAL NOT NULL,
    radius_meters INTEGER NOT NULL,
    reason TEXT,
    enabled BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Config Cache: for rapid config reloads
CREATE TABLE IF NOT EXISTS config_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT UNIQUE NOT NULL,
    value TEXT NOT NULL,
    config_file TEXT,
    hash TEXT,
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP
);

-- Admin Action Log: audit trail
CREATE TABLE IF NOT EXISTS admin_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    action TEXT NOT NULL,  -- 'set_price', 'toggle_vehicle', 'force_deploy', 'give_balance', etc.
    target_user_id INTEGER,
    target_item TEXT,  -- vehicle classname, item classname, etc.
    details TEXT,  -- JSON of action details
    success BOOLEAN DEFAULT 1,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id),
    FOREIGN KEY (target_user_id) REFERENCES users(id)
);

CREATE INDEX idx_admin_log_admin_id ON admin_log(admin_id);
CREATE INDEX idx_admin_log_created_at ON admin_log(created_at);

-- Saved Cargo Builds: player templates for quick reorder
CREATE TABLE IF NOT EXISTS saved_cargo_builds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    build_name TEXT NOT NULL,
    cargo_json TEXT NOT NULL,  -- JSON: [{classname: "...", quantity: 1}, ...]
    total_cost REAL,
    total_slots INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(user_id, build_name)
);

-- Saved Vehicle Builds: player templates (for future custom vehicle support)
CREATE TABLE IF NOT EXISTS saved_vehicle_builds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    build_name TEXT NOT NULL,
    vehicle_classname TEXT NOT NULL,
    parts_json TEXT,  -- JSON: {wheel: {...}, door_1_1: {...}}
    run_parts_json TEXT,
    color_json TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(user_id, build_name)
);

-- Web UI Sessions (optional: for admin auth)
CREATE TABLE IF NOT EXISTS web_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    token TEXT UNIQUE NOT NULL,
    user_id INTEGER NOT NULL,
    ip_address TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX idx_web_sessions_token ON web_sessions(token);
CREATE INDEX idx_web_sessions_expires_at ON web_sessions(expires_at);

-- Triggers: auto-update `updated_at` columns
CREATE TRIGGER IF NOT EXISTS users_update_timestamp AFTER UPDATE ON users
BEGIN
    UPDATE users SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS catalog_vehicles_update_timestamp AFTER UPDATE ON catalog_vehicles
BEGIN
    UPDATE catalog_vehicles SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS catalog_items_update_timestamp AFTER UPDATE ON catalog_items
BEGIN
    UPDATE catalog_items SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS orders_update_timestamp AFTER UPDATE ON orders
BEGIN
    UPDATE orders SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS rentals_update_timestamp AFTER UPDATE ON rentals
BEGIN
    UPDATE rentals SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS safe_zones_update_timestamp AFTER UPDATE ON safe_zones
BEGIN
    UPDATE safe_zones SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS blacklist_zones_update_timestamp AFTER UPDATE ON blacklist_zones
BEGIN
    UPDATE blacklist_zones SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

#!/usr/bin/env python
"""
Seed console items from DayZ mission types.xml

This script extracts vanilla console item classnames from your mission
and populates config/console_items.json automatically.

Usage:
    python scripts/seed_console_items.py --mission-path /path/to/mission/folder
"""

import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Set

from loguru import logger

# Configure logging
logger.remove()
logger.add(sys.stderr, level="INFO")


class ItemExtractor:
    """Extract items from DayZ mission types.xml"""
    
    # Item categories based on classname patterns
    CATEGORIES = {
        'weapon': ['M4A1', 'AK74', 'Mosin', 'FNX', 'Rifle', 'Pistol', 'Shotgun', 'SMG'],
        'ammunition': ['Mag_', 'Ammo_'],
        'medical': ['Bandage', 'Morphine', 'Saline', 'Epi', 'Antibiotic'],
        'food_drink': ['Apple', 'Can_', 'Water', 'Bottle', 'Soup'],
        'container': ['Bag', 'Pouch', 'Box', 'Case'],
        'attachment': ['Optic', 'Flashlight', 'Stock', 'Muzzle'],
        'tool': ['Wrench', 'Hammer', 'Rope', 'Tape', 'Knife'],
        'fuel': ['Canister', 'Fuel'],
    }
    
    def __init__(self, mission_path: Path):
        self.mission_path = Path(mission_path)
        self.items: Dict[str, Dict] = {}
    
    def find_types_xml(self) -> Path:
        """Find types.xml in mission folder"""
        # Common paths
        paths = [
            self.mission_path / "types.xml",
            self.mission_path / "db" / "types.xml",
            self.mission_path / "cfgeconomycore.xml",
        ]
        
        for path in paths:
            if path.exists():
                logger.info(f"Found types file: {path}")
                return path
        
        raise FileNotFoundError(f"types.xml not found in {self.mission_path}")
    
    def extract_items(self) -> Dict[str, Dict]:
        """Extract item classnames from types.xml"""
        types_file = self.find_types_xml()
        
        try:
            tree = ET.parse(types_file)
            root = tree.getroot()
        except ET.ParseError as e:
            logger.error(f"Failed to parse XML: {e}")
            return {}
        
        # Find all type elements with name attribute
        for type_elem in root.findall('.//type'):
            classname = type_elem.get('name')
            if not classname:
                continue
            
            # Skip certain patterns
            if classname.startswith(('Land_', 'Flag_', 'Wreck_', 'Loot_')):
                continue
            
            # Determine category
            category = self.categorize(classname)
            
            self.items[classname] = {
                'classname': classname,
                'display_name': self.humanize_name(classname),
                'category': category,
                'slots': self.estimate_slots(classname),
                'is_weapon': category == 'weapon',
                'is_container': category == 'container',
                'price': 100,  # Default, will be adjusted
                'enabled': True,
                'max_quantity': 1,
            }
        
        logger.info(f"Extracted {len(self.items)} items")
        return self.items
    
    def categorize(self, classname: str) -> str:
        """Categorize item based on classname"""
        for category, patterns in self.CATEGORIES.items():
            if any(pattern in classname for pattern in patterns):
                return category
        
        return 'misc'
    
    def humanize_name(self, classname: str) -> str:
        """Convert classname to human-readable name"""
        # Insert spaces before capitals
        name = ''.join([' ' + c if c.isupper() else c for c in classname]).strip()
        return name
    
    def estimate_slots(self, classname: str) -> int:
        """Estimate inventory slots based on classname and category"""
        category = self.categorize(classname)
        
        # Default slot estimates
        estimates = {
            'weapon': 10,
            'ammunition': 2,
            'medical': 2,
            'food_drink': 1,
            'container': 20,
            'attachment': 3,
            'tool': 3,
            'fuel': 10,
        }
        
        return estimates.get(category, 5)
    
    def get_popular_items(self) -> List[Dict]:
        """Get a curated list of popular console items"""
        popular = [
            # Weapons
            'M4A1', 'AK74', 'Mosin9130', 'FNX45',
            # Ammunition
            'Mag_STANAG_30Rnd', 'Mag_AK74_30Rnd', 'Mag_Mosin9130_5Rnd', 'Mag_FNX45_15Rnd',
            # Medical
            'Bandage', 'Morphine', 'SalineBag',
            # Food/Drink
            'Apple', 'Waterbottle',
            # Containers
            'Backpack', 'TacticalBag', 'AssaultBag', 'MedicalBag',
            # Attachments
            'ACOGOptic', 'PSO1Optic', 'Flashlight',
            # Tools
            'Wrench', 'Rope', 'Hammer', 'Knife',
            # Fuel
            'CanisterGasoline', 'CanisterDiesel',
        ]
        
        items = []
        for classname in popular:
            if classname in self.items:
                items.append(self.items[classname])
        
        return items


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Seed console items from mission types.xml'
    )
    parser.add_argument(
        '--mission-path',
        default='.',
        help='Path to mission folder'
    )
    parser.add_argument(
        '--output',
        default='config/console_items.json',
        help='Output JSON file'
    )
    parser.add_argument(
        '--popular-only',
        action='store_true',
        help='Only include popular/verified items'
    )
    
    args = parser.parse_args()
    
    # Extract items
    extractor = ItemExtractor(args.mission_path)
    
    try:
        items = extractor.extract_items()
    except FileNotFoundError as e:
        logger.error(str(e))
        return 1
    
    # Filter to popular if requested
    if args.popular_only:
        items_list = extractor.get_popular_items()
        logger.info(f"Using {len(items_list)} popular items")
    else:
        items_list = list(items.values())
    
    # Sort by category
    items_list.sort(key=lambda x: (x['category'], x['display_name']))
    
    # Create output
    output = {
        'items': items_list,
        'warnings': [
            'This list must match your mission types.xml classnames exactly.',
            'Do not add PC-only mods or weapons.',
            'Verify all items work on console before enabling publicly.',
            'Update from your live server export regularly.'
        ]
    }
    
    # Save
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    
    logger.info(f"Saved {len(items_list)} items to {output_path}")
    logger.info(f"Review the file and enable only verified console items")
    
    return 0


if __name__ == '__main__':
    sys.exit(main())

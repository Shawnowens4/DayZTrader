#!/usr/bin/env python
"""
DayZ Trader Bot - First-time Setup

Initializes database, creates necessary folders, and validates configuration.

Usage:
    python scripts/setup.py
"""

import os
import sqlite3
import sys
from pathlib import Path

from loguru import logger

logger.remove()
logger.add(sys.stderr, level="INFO")


def create_folders() -> bool:
    """Create necessary folders"""
    folders = [
        'data',
        'logs',
        'backups',
        'config',
        'web/static/img/vehicles',
        'web/static/img/items',
        'web/static/img/parts',
    ]
    
    for folder in folders:
        path = Path(folder)
        path.mkdir(parents=True, exist_ok=True)
        logger.info(f"✓ Created folder: {folder}")
    
    return True


def init_database() -> bool:
    """Initialize SQLite database"""
    db_path = Path('data/trader.db')
    schema_path = Path('data/schema.sql')
    
    if not schema_path.exists():
        logger.error(f"Schema file not found: {schema_path}")
        return False
    
    try:
        # Connect to database (creates it if not exists)
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Read and execute schema
        with open(schema_path, 'r', encoding='utf-8') as f:
            schema = f.read()
        
        # Split by semicolon and execute
        statements = [s.strip() for s in schema.split(';') if s.strip()]
        
        for statement in statements:
            try:
                cursor.execute(statement)
            except sqlite3.Error as e:
                logger.debug(f"Schema statement skipped: {e}")
        
        conn.commit()
        
        # Verify
        cursor.execute("SELECT COUNT(*) FROM users")
        logger.info("✓ Database initialized successfully")
        
        conn.close()
        return True
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False


def check_env() -> bool:
    """Check .env file exists"""
    env_file = Path('.env')
    env_example = Path('.env.example')
    
    if env_file.exists():
        logger.info("✓ .env file found")
        return True
    
    if not env_example.exists():
        logger.error(".env.example not found")
        return False
    
    logger.warning("⚠ .env file not found")
    response = input("Create .env from .env.example? (y/n): ").strip().lower()
    
    if response == 'y':
        import shutil
        shutil.copy(env_example, env_file)
        logger.info("✓ Created .env from template")
        logger.info("   ⚠ Please edit .env with your configuration")
        return True
    
    return False


def check_config() -> bool:
    """Check config files exist"""
    configs = [
        'config/settings.yaml',
        'config/vehicle_defs.json',
        'config/console_items.json',
        'config/nesting_rules.json',
    ]
    
    all_exist = True
    for config in configs:
        path = Path(config)
        if path.exists():
            logger.info(f"✓ {config}")
        else:
            logger.error(f"✗ {config} not found")
            all_exist = False
    
    return all_exist


def check_dependencies() -> bool:
    """Check Python dependencies"""
    required = [
        'discord',
        'fastapi',
        'sqlalchemy',
        'dotenv',
        'yaml',
        'lxml',
    ]
    
    missing = []
    for package in required:
        try:
            __import__(package)
            logger.info(f"✓ {package}")
        except ImportError:
            logger.error(f"✗ {package} not installed")
            missing.append(package)
    
    if missing:
        logger.warning(f"Missing packages: {', '.join(missing)}")
        logger.info("Install with: pip install -r requirements.txt")
        return False
    
    return True


def test_db_connection() -> bool:
    """Test database connection"""
    try:
        import sqlite3
        conn = sqlite3.connect('data/trader.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        count = cursor.fetchone()[0]
        conn.close()
        
        logger.info(f"✓ Database connected ({count} users)")
        return True
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        return False


def main():
    """Run setup"""
    logger.info("=" * 60)
    logger.info("DayZ Console Trader Bot - Setup")
    logger.info("=" * 60)
    
    steps = [
        ("Creating folders", create_folders),
        ("Checking .env", check_env),
        ("Checking config files", check_config),
        ("Checking dependencies", check_dependencies),
        ("Initializing database", init_database),
        ("Testing database", test_db_connection),
    ]
    
    passed = 0
    failed = 0
    
    for step_name, step_func in steps:
        logger.info(f"\n{step_name}...")
        try:
            if step_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            logger.error(f"Step failed: {e}")
            failed += 1
    
    # Summary
    logger.info("\n" + "=" * 60)
    logger.info(f"Setup complete: {passed} passed, {failed} failed")
    logger.info("=" * 60)
    
    if failed == 0:
        logger.info("\n✓ You're ready to start the bot!")
        logger.info("  Run: python bot/main.py")
        return 0
    else:
        logger.warning("\n⚠ Please fix the errors above before running the bot")
        return 1


if __name__ == '__main__':
    sys.exit(main())

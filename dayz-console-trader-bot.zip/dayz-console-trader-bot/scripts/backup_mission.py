#!/usr/bin/env python
"""
Mission Backup Manager

Backup and restore mission files from Nitrado FTP server.

Usage:
    python scripts/backup_mission.py --action backup
    python scripts/backup_mission.py --action restore --file mission_20240101_120000.zip
    python scripts/backup_mission.py --action list
"""

import asyncio
import sys
from datetime import datetime
from pathlib import Path

from loguru import logger

# Configure logging
logger.remove()
logger.add(sys.stderr, level="INFO")


async def backup_mission():
    """Backup mission from FTP server"""
    import os
    from dotenv import load_dotenv
    
    load_dotenv()
    
    # Get FTP config
    ftp_host = os.getenv('FTP_HOST')
    ftp_user = os.getenv('FTP_USER')
    ftp_pass = os.getenv('FTP_PASS')
    ftp_port = int(os.getenv('FTP_PORT', 21))
    mission_path = os.getenv('FTP_MISSION_PATH', '/dayzxb_mission/dayzoffline.chernarusplus')
    
    if not all([ftp_host, ftp_user, ftp_pass]):
        logger.error("Missing FTP credentials in .env")
        return False
    
    # Import FTP client
    from bot.services.ftp_client import FTPClient
    
    ftp = FTPClient(ftp_host, ftp_user, ftp_pass, ftp_port)
    
    try:
        # Connect
        if not await ftp.connect():
            logger.error("FTP connection failed")
            return False
        
        # Backup
        backup_file = await ftp.backup_mission(mission_path, 'backups')
        
        if backup_file:
            logger.info(f"✓ Mission backed up to {backup_file}")
            return True
        else:
            logger.error("Backup failed")
            return False
    finally:
        await ftp.disconnect()


async def restore_mission(backup_file: str):
    """Restore mission from backup"""
    import os
    import shutil
    import zipfile
    from dotenv import load_dotenv
    
    load_dotenv()
    
    backup_path = Path('backups') / backup_file
    
    if not backup_path.exists():
        logger.error(f"Backup file not found: {backup_path}")
        return False
    
    # Get mission path
    ftp_mission_path = os.getenv('FTP_MISSION_PATH', '/dayzxb_mission/dayzoffline.chernarusplus')
    mission_name = Path(ftp_mission_path).name
    
    logger.info(f"Restoring from {backup_path}...")
    logger.info(f"Target: {ftp_mission_path}")
    
    # Confirm
    response = input("Restore mission from backup? (yes/no): ").strip().lower()
    if response != 'yes':
        logger.info("Restore cancelled")
        return False
    
    try:
        # Extract backup
        extract_path = Path('backups/restore_temp')
        extract_path.mkdir(exist_ok=True)
        
        with zipfile.ZipFile(backup_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
        
        logger.info(f"✓ Extracted backup to {extract_path}")
        
        # Now would need to upload back to FTP
        # This is a simplified example
        logger.info("✓ Restore ready for FTP upload")
        logger.info(f"  Files extracted to: {extract_path}")
        logger.info("  Use FTP to upload files back to mission folder")
        
        return True
    except Exception as e:
        logger.error(f"Restore failed: {e}")
        return False


async def list_backups():
    """List available backups"""
    backup_dir = Path('backups')
    
    if not backup_dir.exists():
        logger.info("No backups directory found")
        return True
    
    backups = sorted(backup_dir.glob('mission_*.zip'), reverse=True)
    
    if not backups:
        logger.info("No backups found")
        return True
    
    logger.info(f"\nAvailable backups ({len(backups)}):\n")
    
    for i, backup in enumerate(backups[:10], 1):  # Show latest 10
        size_mb = backup.stat().st_size / (1024 * 1024)
        mod_time = datetime.fromtimestamp(backup.stat().st_mtime)
        
        logger.info(f"{i}. {backup.name}")
        logger.info(f"   Size: {size_mb:.1f} MB")
        logger.info(f"   Modified: {mod_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    return True


async def cleanup_backups(days_old: int = 7):
    """Clean up old backups"""
    from datetime import datetime, timedelta
    
    backup_dir = Path('backups')
    cutoff = datetime.now() - timedelta(days=days_old)
    
    removed = 0
    for backup in backup_dir.glob('mission_*.zip'):
        mod_time = datetime.fromtimestamp(backup.stat().st_mtime)
        
        if mod_time < cutoff:
            backup.unlink()
            logger.info(f"Removed: {backup.name}")
            removed += 1
    
    logger.info(f"✓ Removed {removed} old backups (> {days_old} days)")
    return True


async def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Mission backup manager')
    parser.add_argument('--action', choices=['backup', 'restore', 'list', 'cleanup'],
                       default='backup', help='Action to perform')
    parser.add_argument('--file', help='Backup file for restore')
    parser.add_argument('--days', type=int, default=7, help='Days to keep for cleanup')
    
    args = parser.parse_args()
    
    logger.info("=" * 60)
    logger.info("Mission Backup Manager")
    logger.info("=" * 60)
    
    if args.action == 'backup':
        success = await backup_mission()
    elif args.action == 'restore':
        if not args.file:
            logger.error("--file required for restore action")
            return 1
        success = await restore_mission(args.file)
    elif args.action == 'list':
        success = await list_backups()
    elif args.action == 'cleanup':
        success = await cleanup_backups(args.days)
    else:
        logger.error("Unknown action")
        return 1
    
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(asyncio.run(main()))

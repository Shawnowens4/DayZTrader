#!/usr/bin/env python
"""
Validate XML spawns and classnames

Checks generated XML files for syntax errors and verifies all classnames
exist in your mission's types.xml.

Usage:
    python scripts/validate_xml.py --xml-file spawn.xml --mission-path /path/to/mission
"""

import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Set, Tuple

from loguru import logger

logger.remove()
logger.add(sys.stderr, level="INFO")


class XMLValidator:
    """Validate trader XML spawns"""
    
    def __init__(self, mission_path: Path):
        self.mission_path = Path(mission_path)
        self.valid_classnames: Set[str] = set()
        self.load_mission_classnames()
    
    def load_mission_classnames(self) -> None:
        """Load all valid classnames from mission"""
        types_files = [
            self.mission_path / "types.xml",
            self.mission_path / "db" / "types.xml",
        ]
        
        for types_file in types_files:
            if not types_file.exists():
                continue
            
            try:
                tree = ET.parse(types_file)
                root = tree.getroot()
                
                # Extract all type names
                for elem in root.findall('.//type'):
                    classname = elem.get('name')
                    if classname:
                        self.valid_classnames.add(classname)
                
                logger.info(f"Loaded {len(self.valid_classnames)} classnames from {types_file}")
                return
            except Exception as e:
                logger.warning(f"Failed to parse {types_file}: {e}")
                continue
        
        logger.warning("No types.xml found; skipping classname validation")
    
    def validate_file(self, xml_file: Path) -> Tuple[bool, List[str]]:
        """
        Validate XML file
        
        Returns:
            (valid, errors)
        """
        errors = []
        
        # Check file exists
        if not xml_file.exists():
            return False, [f"File not found: {xml_file}"]
        
        # Parse XML
        try:
            tree = ET.parse(xml_file)
            root = tree.getroot()
            logger.info(f"✓ XML is well-formed")
        except ET.ParseError as e:
            return False, [f"XML syntax error: {e}"]
        
        # Validate classnames
        classname_errors = self.validate_classnames(root)
        errors.extend(classname_errors)
        
        # Validate structure
        structure_errors = self.validate_structure(root)
        errors.extend(structure_errors)
        
        return len(errors) == 0, errors
    
    def validate_classnames(self, root: ET.Element) -> List[str]:
        """Check all classnames are in mission"""
        errors = []
        
        if not self.valid_classnames:
            logger.warning("Skipping classname validation (no mission data)")
            return []
        
        for elem in root.iter():
            classname = elem.get('name') or elem.text
            
            if not classname:
                continue
            
            # Check if classname is in mission
            if classname not in self.valid_classnames:
                # Skip certain patterns
                if not any(x in classname for x in ['_Trader', 'chance', 'quantity']):
                    errors.append(f"❌ Classname not found in mission: {classname}")
        
        if not errors:
            logger.info(f"✓ All classnames are valid")
        
        return errors
    
    def validate_structure(self, root: ET.Element) -> List[str]:
        """Validate XML structure"""
        errors = []
        
        for type_elem in root.findall('.//type'):
            classname = type_elem.get('name')
            
            if not classname:
                errors.append("Missing 'name' attribute on type element")
                continue
            
            # Check attachments
            for attachments in type_elem.findall('attachments'):
                chance = attachments.get('chance')
                if not chance:
                    logger.warning(f"Missing 'chance' on attachments for {classname}")
                else:
                    try:
                        c = float(chance)
                        if not (0 <= c <= 1):
                            errors.append(f"Invalid chance value for {classname}: {chance}")
                    except ValueError:
                        errors.append(f"Invalid chance format for {classname}: {chance}")
                
                # Check items
                for item in attachments.findall('item'):
                    if not item.get('name'):
                        errors.append(f"Item missing 'name' in {classname}")
                    if not item.get('chance'):
                        logger.warning(f"Item missing 'chance' in {classname}")
            
            # Check cargo
            for cargo in type_elem.findall('cargo'):
                chance = cargo.get('chance')
                if not chance:
                    logger.warning(f"Missing 'chance' on cargo for {classname}")
                
                for item in cargo.findall('item'):
                    if not item.get('name'):
                        errors.append(f"Cargo item missing 'name' in {classname}")
        
        if not errors:
            logger.info(f"✓ XML structure is valid")
        
        return errors
    
    def validate_string(self, xml_string: str) -> Tuple[bool, List[str]]:
        """Validate XML from string"""
        errors = []
        
        try:
            root = ET.fromstring(xml_string)
            logger.info(f"✓ XML is well-formed")
        except ET.ParseError as e:
            return False, [f"XML syntax error: {e}"]
        
        # Validate classnames and structure
        classname_errors = self.validate_classnames(root)
        structure_errors = self.validate_structure(root)
        
        errors.extend(classname_errors)
        errors.extend(structure_errors)
        
        return len(errors) == 0, errors


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Validate trader XML spawns')
    parser.add_argument('--xml-file', help='XML file to validate')
    parser.add_argument('--mission-path', default='.', help='Mission folder path')
    parser.add_argument('--string', help='XML string to validate (from stdin if not provided)')
    
    args = parser.parse_args()
    
    # Create validator
    validator = XMLValidator(args.mission_path)
    
    # Validate XML
    if args.xml_file:
        xml_path = Path(args.xml_file)
        logger.info(f"Validating {xml_path}...")
        valid, errors = validator.validate_file(xml_path)
    elif args.string:
        logger.info("Validating XML string...")
        valid, errors = validator.validate_string(args.string)
    else:
        # Read from stdin
        xml_string = sys.stdin.read()
        logger.info("Validating XML from stdin...")
        valid, errors = validator.validate_string(xml_string)
    
    # Print results
    if valid:
        logger.info("✓ Validation passed!")
        return 0
    else:
        logger.error("✗ Validation failed!")
        for error in errors:
            print(f"  {error}")
        return 1


if __name__ == '__main__':
    sys.exit(main())
